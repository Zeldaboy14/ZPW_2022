#ifndef LVL2_H
#define LVL2_H

#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3dmodel.h>
#include "../include/enums.h"
#include "../include/types.h"
#include "debug.h"
#include "collision.h"
#include "utils.h"

extern T3DVec3 lvl2Verts[31];

extern int lvl2WallCount;
extern Surface* lvl2Wall;

extern int lvl2SlopeCount;
extern Surface* lvl2Slope;

extern int lvl2FloorCount;
extern Surface* lvl2Floor;

extern int lvl2SurfacesCount;
extern Surface* lvl2Surfaces;

extern T3DMat4FP* lvl2MatFP;
extern T3DModel *modelLvl2;
extern rspq_block_t *dplLvl2;

void lvl2_init(void);

#endif // LVL2_H
