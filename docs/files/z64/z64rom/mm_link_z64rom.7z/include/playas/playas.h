#ifndef __PLAYAS__H__
#define __PLAYAS__H__
#include <uLib.h>
#include "object/0x0014-Adult_Link.h"
#include "object/0x0015-Child_Link.h"

//New Functions
void DrawGauntletDList(PlayState* play, Player* this, s32 limbIndex);
void Player_DrawHookshotReticleNew(PlayState* play, Player* this, f32 arg2);

#endif /* __PLAYAS__H__ */