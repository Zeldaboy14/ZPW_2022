#include <z64hdr.h>
#include "code/z_player_lib.h"
#include "functions.h"
#include "playas/playas.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

u64 WaistBagTexture_ia16[] = {
	0xbcb7bdb7bdbccbc6, 0xbdc2c5c3c4c4c6c6, 0xc8cecfd3c5b1b4b9, 0xbec1c6bec1c3b7bc, 0xa4b4bbafb3b4c2c1, 0xbebdbebdbdbebfbc, 0xb9bfcabebea5a9a5, 0xaaa09aa0b0b7aaac, 
	0xa1a79d9aacb9c1b6, 0xb4b6bbb8b8b8b8a9, 0xa4a9a6959881898b, 0x958e8f8e9d9a9aa5, 0xb9bebbb9bebebbb9, 0xb0b6b7afabafb7ac, 0xa9b4b6b1a998a2a5, 0xb1b4abb4b4afa9b1, 
	0xb3b4b1aaa6a7abb1, 0xa9a8a9acaeabaeb1, 0xbfc8c5c3c0a7acbc, 0xc1beaebeb4aaaeac, 0xb6b7c3bcb6b4b4af, 0xb1a5a1acb4b5b5bb, 0xc1c8c6bebbaaa9b7, 0xbebeb4bcbbbeacb9, 
	0xb1b1b8b1aea5b7c1, 0xc1adaea59f9e9a9b, 0x94949a95a795a0af, 0xbeb9a9b1b9b7a7af, 0xbbb9b6b4afaaafb4, 0xb2bdc1b6b0b3b1a4, 0xa3aab0acac8e8fa0, 0x9aa5a5b1c1c6b0bc, 
	0x9a95939385849aa2, 0xa0aab6b7a8aac0c0, 0xbec9cecbcbb7aaaf, 0xabafa6a7b1aa9a98, 0xc2c3bcb7aeafc6d3, 0xcfc8cbbcb6b1a6aa, 0xb0bcc3c1bdb4b3be, 0xc7c1b0b7c0c1bdc3, 
	0xd4d3dfd8d2d0dad8, 0xc6c6cfc3c7cbc9c8, 0xc1cbcec6c1aaafb4, 0xbcbcb4bccbd3cbd8, 0xa6a5aca79a9da5a2, 0x8fa0ada5b6b7b5ae, 0xa8b1a79da79d9da0, 0x9da59895a0a59dac, 
	0xc1c3c2b9a6a5afa9, 0xa2a9aca09fa1aab5, 0xc1c7c8c3bdb4aeb1, 0xaebcb6b4bcb7b3be, 0xc7c1c0c1b4a7bcbf, 0xb2b1b2b3b8b8b7b6, 0xb5b4b7b9bbbeb3b7, 0xbbc8c1becbcbc5c8, 
	0xc1c6c2beb1aab3b6, 0xb1b9c0bfb9b0abab, 0xa9aab2bebeb1aebe, 0xb8c3c7c6d5d0c6c6, 0xa5a5a09a8e819094, 0x8f949a96a1acbbbd, 0xc2bdc3c2bbafa6aa, 0xabb7abb1afa09da0, 
	0xb8c1b1aaaeaca9b7, 0xbdb7c0afacb3abae, 0xa7afaea89d9a9dac, 0xa9aa97a5a4acacb9, 0xc1c3c0b9b8b9bec6, 0xc0b9cbcbc0bfb3b6, 0xb2b0b4b9b9beb9be, 0xb4b9aeaca5b1abc1, 
	0xbeb9b7afa0a5abac, 0xaebcc3c1b9b4b1b2, 0xb4bac5c7c7bebcc6, 0xbcc3bbc1bdbcb8c3, 0xb7aab3b7acaaa09d, 0x9aa2a5a5a4a9b2b5, 0xb1b5b8b2aca09fa0, 0xa6aaa1acb0b9bbb9, 
	0xdfd3cdceb6acaea5, 0xa6a7b1a5a09dacb7, 0xb6adafbdc4c0bec5, 0xc6cbb0bcbbc8cdce, 0xe2d5cac8c2bebdb4, 0xabacb0acafa7a7b2, 0xb3babebfbfc0bdca, 0xd1d0b6bec0c8c1d3, 
	0xd3d3cac8c6c1c1c3, 0xbec6cbd0c8cccdc9, 0xc8c9cbcbcccac8c9, 0xc8c6c7d0cbd3c2cb, 0xc7cbcdd3cac8d3d3, 0xcedddacbcbcfcbc7, 0xc4bdc2c6c8c5c8c3, 0xc4a5a7b7b1c1c0c1, 
	0xa5a0a9a29d9aa09d, 0x928b938e8f8b9ca3, 0xa6aaa7b1b2a9a0a4, 0x9d9a939aa4afa6a2, 0x8a8e8f8984899290, 0x9497999e9b9ca2a8, 0xabaec1beb4aaa7ac, 0xa5a0a5a5a2a58d90, 
	0xc2c6c5c8c3dac8c8, 0xc7a9a4a39e9fa19b, 0x999eb4b1a9a2a6aa, 0xb0afa9bcc1c6c3c1, 0xafaaabb1a6a7a2a0, 0xa2b3b9b7b6b4bac2, 0xc7cbd4dfd5cbcbce, 0xcfd3bec1b8b9abaf, 
	0xa79da2a0aca7a6a5, 0xa2abb1b1b5b0acaa, 0xa9a5b0b7b9b4a9b7, 0xb9b4b6b1a9a7a0a7, 0xaeb1a59a98988f8e, 0x838f8083757e9ea3, 0xaeafc1cecac3bebe, 0xbebebdc3bbb9b0af, 
	0x98a29d9a8f8e8e84, 0x8d99a1a99aa0a4a7, 0xa5a5a7b1b0afaca7, 0x959a9a9d8fa08a8e, 0xabb7bcc3b8c1c1c3, 0xbcbb868a898b8782, 0x828b8f9595988d8e, 0x9aa09da7a2a5a2a0, 
	
};

Vtx gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_vtx_cull[8] = {
	{{{124, -487, -859},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{124, -487, -267},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{124, 274, -267},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{124, 274, -859},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{829, -487, -859},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{829, -487, -267},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{829, 274, -267},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{829, 274, -859},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
};

Vtx gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_vtx_0[25] = {
	{{{124, -108, -471},0, {-16, 93},{0x82, 0x0, 0x12, 0xFF}}},
	{{{183, 161, -488},0, {-365, 248},{0xA1, 0x53, 0xF, 0xFF}}},
	{{{150, -107, -593},0, {-16, 296},{0x85, 0x0, 0xDF, 0xFF}}},
	{{{183, -377, -492},0, {333, 248},{0xA1, 0xAC, 0xD, 0xFF}}},
	{{{201, -110, -267},0, {1008, 270},{0xB5, 0x0, 0x67, 0xFF}}},
	{{{516, -431, -361},0, {794, 481},{0x17, 0x99, 0x47, 0xFF}}},
	{{{449, -487, -658},0, {375, 477},{0xF7, 0x83, 0xEB, 0xFF}}},
	{{{417, -374, -798},0, {171, 480},{0xDC, 0xAB, 0xA9, 0xFF}}},
	{{{711, -375, -716},0, {333, 716},{0x53, 0xA9, 0xD5, 0xFF}}},
	{{{590, -105, -859},0, {-16, 605},{0x38, 0x0, 0x8E, 0xFF}}},
	{{{819, -106, -739},0, {-16, 880},{0x73, 0x0, 0xCA, 0xFF}}},
	{{{711, 163, -712},0, {-365, 716},{0x53, 0x57, 0xD6, 0xFF}}},
	{{{829, -108, -430},0, {-1040, 698},{0x75, 0x0, 0x32, 0xFF}}},
	{{{829, -108, -430},0, {1008, 698},{0x75, 0x0, 0x32, 0xFF}}},
	{{{529, -109, -301},0, {1008, 481},{0x22, 0x0, 0x7A, 0xFF}}},
	{{{516, 213, -356},0, {1222, 481},{0x17, 0x66, 0x49, 0xFF}}},
	{{{711, 163, -712},0, {1683, 716},{0x53, 0x57, 0xD6, 0xFF}}},
	{{{449, 274, -652},0, {1641, 477},{0xF7, 0x7D, 0xED, 0xFF}}},
	{{{417, 163, -793},0, {1845, 480},{0xDC, 0x57, 0xAA, 0xFF}}},
	{{{590, -105, -859},0, {2032, 605},{0x38, 0x0, 0x8E, 0xFF}}},
	{{{403, -105, -854},0, {2032, 481},{0xC8, 0x0, 0x8E, 0xFF}}},
	{{{417, -374, -798},0, {2219, 480},{0xDC, 0xAB, 0xA9, 0xFF}}},
	{{{150, -107, -593},0, {2032, 296},{0x85, 0x0, 0xDF, 0xFF}}},
	{{{183, -377, -492},0, {2381, 248},{0xA1, 0xAC, 0xD, 0xFF}}},
	{{{183, 161, -488},0, {1683, 248},{0xA1, 0x53, 0xF, 0xFF}}},
};

Gfx gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_tri_0[] = {
	gsSPVertex(gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_vtx_0 + 0, 25, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 3, 5, 4, 0),
	gsSP2Triangles(3, 6, 5, 0, 3, 7, 6, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(10, 8, 9, 0, 10, 9, 11, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 8, 0),
	gsSP2Triangles(13, 5, 8, 0, 13, 14, 5, 0),
	gsSP2Triangles(13, 15, 14, 0, 16, 15, 13, 0),
	gsSP2Triangles(16, 17, 15, 0, 16, 18, 17, 0),
	gsSP2Triangles(19, 18, 16, 0, 19, 20, 18, 0),
	gsSP2Triangles(19, 21, 20, 0, 22, 20, 21, 0),
	gsSP2Triangles(22, 21, 23, 0, 22, 18, 20, 0),
	gsSP2Triangles(24, 18, 22, 0, 24, 17, 18, 0),
	gsSP2Triangles(24, 15, 17, 0, 4, 15, 24, 0),
	gsSP2Triangles(0, 4, 24, 0, 4, 14, 15, 0),
	gsSP2Triangles(4, 5, 14, 0, 8, 5, 6, 0),
	gsSPEndDisplayList(),
};

Gfx mat_gLinkChildWaistBagDL_f3d_material_001_layerOpaque[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
	gsSPSetGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
	gsSPClearGeometryMode(G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
	gsSPSetOtherMode(G_SETOTHERMODE_H, 4, 20, G_AD_NOISE | G_CD_MAGICSQ | G_CK_NONE | G_TC_FILT | G_TF_BILERP | G_TL_TILE | G_TD_CLAMP | G_TP_PERSP | G_CYC_2CYCLE | G_PM_NPRIMITIVE),
	gsSPSetOtherMode(G_SETOTHERMODE_L, 0, 32, G_AC_NONE | G_ZS_PIXEL | G_RM_FOG_SHADE_A | G_RM_AA_ZB_OPA_SURF2),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureLUT(G_TT_NONE),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, WaistBagTexture_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsDPSetPrimColor(0, 0, 97, 96, 53, 255),
	gsSPEndDisplayList(),
};

Gfx gLinkChildWaistBagDL[] = {
	gsSPClearGeometryMode(G_LIGHTING),
	gsSPVertex(gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_vtx_cull + 0, 8, 0),
	gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
	gsSPCullDisplayList(0, 7),
	gsSPDisplayList(mat_gLinkChildWaistBagDL_f3d_material_001_layerOpaque),
	gsSPDisplayList(gLinkChildWaistBagDL_bombbag_mesh_layer_Opaque_tri_0),
	gsSPEndDisplayList(),
};

Vtx gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_vtx_cull[8] = {
	{{{43, -485, -1061},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{43, -485, -346},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{43, 465, -346},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{43, 465, -1061},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{931, -485, -1061},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{931, -485, -346},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{931, 465, -346},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
	{{{931, 465, -1061},0, {-16, -16},{0x0, 0x0, 0x0, 0x0}}},
};

Vtx gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_vtx_0[25] = {
	{{{43, -7, -607},0, {-16, 93},{0x81, 0x0, 0x9, 0xFF}}},
	{{{117, 329, -632},0, {-365, 248},{0xA1, 0x54, 0x6, 0xFF}}},
	{{{85, -10, -757},0, {-16, 296},{0x88, 0x0, 0xD7, 0xFF}}},
	{{{118, -343, -620},0, {333, 248},{0xA0, 0xAD, 0x9, 0xFF}}},
	{{{122, -2, -346},0, {1008, 270},{0xAF, 0x1, 0x61, 0xFF}}},
	{{{521, -405, -428},0, {794, 481},{0x12, 0x9C, 0x4C, 0xFF}}},
	{{{462, -485, -800},0, {375, 477},{0xF8, 0x83, 0xEE, 0xFF}}},
	{{{434, -349, -981},0, {171, 480},{0xE2, 0xA8, 0xA9, 0xFF}}},
	{{{794, -347, -855},0, {333, 716},{0x55, 0xA9, 0xDD, 0xFF}}},
	{{{655, -15, -1052},0, {-16, 605},{0x40, 0xFE, 0x92, 0xFF}}},
	{{{931, -11, -883},0, {-16, 880},{0x76, 0x0, 0xD2, 0xFF}}},
	{{{793, 325, -868},0, {-365, 716},{0x55, 0x56, 0xDA, 0xFF}}},
	{{{918, -4, -498},0, {-1040, 698},{0x71, 0x1, 0x3A, 0xFF}}},
	{{{918, -4, -498},0, {1008, 698},{0x71, 0x1, 0x3A, 0xFF}}},
	{{{533, -2, -361},0, {1008, 481},{0x1A, 0x2, 0x7C, 0xFF}}},
	{{{521, 399, -443},0, {1222, 481},{0x12, 0x67, 0x48, 0xFF}}},
	{{{793, 325, -868},0, {1683, 716},{0x55, 0x56, 0xDA, 0xFF}}},
	{{{462, 465, -818},0, {1641, 477},{0xF8, 0x7D, 0xE9, 0xFF}}},
	{{{434, 322, -994},0, {1845, 480},{0xE2, 0x54, 0xA5, 0xFF}}},
	{{{655, -15, -1052},0, {2032, 605},{0x40, 0xFE, 0x92, 0xFF}}},
	{{{422, -15, -1061},0, {2032, 481},{0xD0, 0xFE, 0x8A, 0xFF}}},
	{{{434, -349, -981},0, {2219, 480},{0xE2, 0xA8, 0xA9, 0xFF}}},
	{{{85, -10, -757},0, {2032, 296},{0x88, 0x0, 0xD7, 0xFF}}},
	{{{118, -343, -620},0, {2381, 248},{0xA0, 0xAD, 0x9, 0xFF}}},
	{{{117, 329, -632},0, {1683, 248},{0xA1, 0x54, 0x6, 0xFF}}},
};

Gfx gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_tri_0[] = {
	gsSPVertex(gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_vtx_0 + 0, 25, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 3, 5, 4, 0),
	gsSP2Triangles(3, 6, 5, 0, 3, 7, 6, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(10, 8, 9, 0, 10, 9, 11, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 8, 0),
	gsSP2Triangles(13, 5, 8, 0, 13, 14, 5, 0),
	gsSP2Triangles(13, 15, 14, 0, 16, 15, 13, 0),
	gsSP2Triangles(16, 17, 15, 0, 16, 18, 17, 0),
	gsSP2Triangles(19, 18, 16, 0, 19, 20, 18, 0),
	gsSP2Triangles(19, 21, 20, 0, 22, 20, 21, 0),
	gsSP2Triangles(22, 21, 23, 0, 22, 18, 20, 0),
	gsSP2Triangles(24, 18, 22, 0, 24, 17, 18, 0),
	gsSP2Triangles(24, 15, 17, 0, 4, 15, 24, 0),
	gsSP2Triangles(0, 4, 24, 0, 4, 14, 15, 0),
	gsSP2Triangles(4, 5, 14, 0, 8, 5, 6, 0),
	gsSPEndDisplayList(),
};

Gfx mat_gLinkBoyWaistBagDL_f3d_material_001_layerOpaque[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
	gsSPSetGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
	gsSPClearGeometryMode(G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
	gsSPSetOtherMode(G_SETOTHERMODE_H, 4, 20, G_AD_NOISE | G_CD_MAGICSQ | G_CK_NONE | G_TC_FILT | G_TF_BILERP | G_TL_TILE | G_TD_CLAMP | G_TP_PERSP | G_CYC_2CYCLE | G_PM_NPRIMITIVE),
	gsSPSetOtherMode(G_SETOTHERMODE_L, 0, 32, G_AC_NONE | G_ZS_PIXEL | G_RM_FOG_SHADE_A | G_RM_AA_ZB_OPA_SURF2),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureLUT(G_TT_NONE),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, WaistBagTexture_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsDPSetPrimColor(0, 0, 97, 96, 53, 255),
	gsSPEndDisplayList(),
};

Gfx gLinkBoyWaistBagDL[] = {
	gsSPClearGeometryMode(G_LIGHTING),
	gsSPVertex(gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_vtx_cull + 0, 8, 0),
	gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
	gsSPCullDisplayList(0, 7),
	gsSPDisplayList(mat_gLinkBoyWaistBagDL_f3d_material_001_layerOpaque),
	gsSPDisplayList(gLinkBoyWaistBagDL_bombbag_mesh_layer_Opaque_tri_0),
	gsSPEndDisplayList(),
};

Asm_VanillaHook(Player_DrawImpl);
void Player_DrawImpl(PlayState* play, void** skeleton, Vec3s* jointTable, s32 dListCount, s32 lod, s32 tunic, s32 boots,
                     s32 face, OverrideLimbDrawOpa overrideLimbDraw, PostLimbDrawOpa postLimbDraw, void* data) {
    Color_RGB8* color;
    s32 eyeIndex = (jointTable[22].x & 0xF) - 1;
    s32 mouthIndex = (jointTable[22].x >> 4) - 1;

        //Adult
    Gfx* hackAdultBootDLists[] = {
        gPlayAsDl_Adult_Boot2L,
        gPlayAsDl_Adult_Boot3L, 
        gPlayAsDl_Adult_Boot2R,
        gPlayAsDl_Adult_Boot3R,
    };

    //Child
    Gfx* hackChildBootDLists[] = {
        gPlayAsDl_Child_Boot2L,
        gPlayAsDl_Child_Boot3L,
        gPlayAsDl_Child_Boot2R,
        gPlayAsDl_Child_Boot3R,
    };

    OPEN_DISPS(play->state.gfxCtx, "../z_player_lib.c", 1721);

    if (eyeIndex < 0) {
        eyeIndex = sEyeMouthIndices[face][0];
    }

#ifndef AVOID_UB
    gSPSegment(POLY_OPA_DISP++, 0x08, SEGMENTED_TO_VIRTUAL(sEyeTextures[eyeIndex]));
#else
    gSPSegment(POLY_OPA_DISP++, 0x08, SEGMENTED_TO_VIRTUAL(sEyeTextures[gSaveContext.linkAge][eyeIndex]));
#endif

    if (mouthIndex < 0) {
        mouthIndex = sEyeMouthIndices[face][1];
    }

#ifndef AVOID_UB
    gSPSegment(POLY_OPA_DISP++, 0x09, SEGMENTED_TO_VIRTUAL(sMouthTextures[mouthIndex]));
#else
    gSPSegment(POLY_OPA_DISP++, 0x09, SEGMENTED_TO_VIRTUAL(sMouthTextures[gSaveContext.linkAge][mouthIndex]));
#endif
    color = &sTunicColors[tunic];
    gDPSetEnvColor(POLY_OPA_DISP++, color->r, color->g, color->b, 0);

    sDListsLodOffset = lod * 2;
    SkelAnime_DrawFlexLod(play, skeleton, jointTable, dListCount, overrideLimbDraw, postLimbDraw, data, lod);
	
    if ((overrideLimbDraw != Player_OverrideLimbDrawGameplayFirstPerson) && (overrideLimbDraw != Player_OverrideLimbDrawGameplay_80090440) &&
        (gSaveContext.gameMode != 3)) {
        Player* player = GET_PLAYER(play);
	
			// Space World Bomb Bag
			if (player->heldItemActionParam == PLAYER_AP_BOMB || player->heldItemActionParam == PLAYER_AP_BOMBCHU) {
				Gfx* bagDlist = (LINK_IS_ADULT) ? gLinkBoyWaistBagDL : gLinkChildWaistBagDL;

				gSPDisplayList(POLY_OPA_DISP++, bagDlist);
			}
    }

    if ((overrideLimbDraw != Player_OverrideLimbDrawGameplayFirstPerson) &&
        (overrideLimbDraw != Player_OverrideLimbDrawGameplay_80090440) &&
        (gSaveContext.gameMode != GAMEMODE_END_CREDITS)) {

        if (boots != PLAYER_BOOTS_KOKIRI) {
            Gfx** bootDListsToUse = LINK_IS_ADULT ? hackAdultBootDLists : hackChildBootDLists;

            gSPDisplayList(POLY_OPA_DISP++, bootDListsToUse[boots - 1]);
            gSPDisplayList(POLY_OPA_DISP++, bootDListsToUse[boots + 1]);
        }
    }
    CLOSE_DISPS(play->state.gfxCtx, "../z_player_lib.c", 1803);
}