#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3dmodel.h>
#include "../include/enums.h"
#include "../include/globals.h"
#include "../include/types.h"
#include "collision.h"
#include "debug.h"
#include "levels.h"
#include "lvl1.h"
#include "map.h"
#include "utils.h"
#include "test_level.h"
#include "lvl2.h"


Level levels[MAX_LEVELS];
int currLevel = 1;
int prevLevel = 0;

void level_init(Level* level) {
    level->floorCount = 0;
    level->floors = NULL;
    level->slopeCount = 0;
    level->slopes = NULL;
    level->wallCount = 0;
    level->walls = NULL;
    level->totalSurfaceCount = 0;
    level->surfaces = NULL;
    level->matFP = NULL;
    level->model = NULL;
    level->dpl = NULL;
}

void level_load(int currLevel) {
    level_free(&levels[currLevel]);
    if(currLevel == 0){
        test_level_init();
        levels[currLevel].floorCount = testLevelFloorCount;
        levels[currLevel].floors = testLevelFloor;
        levels[currLevel].slopeCount = testLevelSlopeCount;
        levels[currLevel].slopes = testLevelSlope;
        levels[currLevel].wallCount = testLevelWallCount;
        levels[currLevel].walls = testLevelWall;
        levels[currLevel].totalSurfaceCount = testLevelSurfacesCount;
        levels[currLevel].surfaces = testLevelSurfaces;
        levels[currLevel].matFP = testLevelMatFP;
        levels[currLevel].model = modelTestLevel;
        levels[currLevel].dpl = dplTestLevel;
        levels[currLevel].numWarps = 1;
        levels[currLevel].warp[0].door = false;
        levels[currLevel].warp[0].pos = (T3DVec3){{226.0f,600.0f,-226.0f}};
        T3DVec3 warpPos = levels[currLevel].warp[0].pos;
        levels[currLevel].warp[0].radius = 64.0f;
        float warpRadius = levels[currLevel].warp[0].radius;
        levels[currLevel].warp[0].radius = levels[currLevel].warp[0].radius;
        levels[currLevel].warp[0].hitbox.shape.type = SHAPE_BOX;
        levels[currLevel].warp[0].hitbox.shape.aabb = (AABB){{{warpPos.v[0] - warpRadius, warpPos.v[1] - warpRadius, warpPos.v[2] - warpRadius}},
                                                        {{warpPos.v[0] + warpRadius, warpPos.v[1] + warpRadius, warpPos.v[2] + warpRadius}}};
        levels[currLevel].warp[0].exit = 1;
        levels[currLevel].warp[0].spawnpos = (T3DVec3){{0,50,0}};
    }
    if(currLevel == 1){
        lvl1_init();
        levels[currLevel].floorCount = lvl1FloorCount;
        levels[currLevel].floors = lvl1Floor;
        levels[currLevel].slopeCount = lvl1SlopeCount;
        levels[currLevel].slopes = lvl1Slope;
        levels[currLevel].wallCount = lvl1WallCount;
        levels[currLevel].walls = lvl1Wall;
        levels[currLevel].totalSurfaceCount = lvl1SurfacesCount;
        levels[currLevel].surfaces = lvl1Surfaces;
        levels[currLevel].matFP = lvl1MatFP;
        levels[currLevel].model = modelLvl1;
        levels[currLevel].dpl = dplLvl1;
        levels[currLevel].numWarps = 1;
        levels[currLevel].warp[0].door = true;
        levels[currLevel].warp[0].pos = (T3DVec3){{-120.0f,50.0f,-180.0f}};
        levels[currLevel].warp[0].radius = 8.0f;
        levels[currLevel].warp[0].hitbox.shape.type = SHAPE_SPHERE;
        levels[currLevel].warp[0].hitbox.shape.sphere = (Sphere){levels[currLevel].warp[0].pos,levels[currLevel].warp[0].radius};
        levels[currLevel].warp[0].exit = 2;
        levels[currLevel].warp[0].spawnpos = (T3DVec3){{-120.0f,50.0f,-160.0f}};
    }
     if(currLevel == 2){
        lvl2_init();
        levels[currLevel].floorCount = lvl2FloorCount;
        levels[currLevel].floors = lvl2Floor;
        levels[currLevel].slopeCount = lvl2SlopeCount;
        levels[currLevel].slopes = lvl2Slope;
        levels[currLevel].wallCount = lvl2WallCount;
        levels[currLevel].walls = lvl2Wall;
        levels[currLevel].totalSurfaceCount = lvl2SurfacesCount;
        levels[currLevel].surfaces = lvl2Surfaces;
        levels[currLevel].matFP = lvl2MatFP;
        levels[currLevel].model = modelLvl2;
        levels[currLevel].dpl = dplLvl2;
        levels[currLevel].numWarps = 1;
        levels[currLevel].warp[0].door = true;
        levels[currLevel].warp[0].pos = (T3DVec3){{-120.0f,50.0f,-180.0f}};
        levels[currLevel].warp[0].radius = 8.0f;
        levels[currLevel].warp[0].hitbox.shape.type = SHAPE_SPHERE;
        levels[currLevel].warp[0].hitbox.shape.sphere = (Sphere){levels[currLevel].warp[0].pos,levels[currLevel].warp[0].radius};
        levels[currLevel].warp[0].exit = 1;
        levels[currLevel].warp[0].spawnpos = (T3DVec3){{-120.0f,50.0f,-200.0f}};
    }
}

void level_free(Level* level) {
    if (level->floors) {
        free(level->floors);
        level->floors = NULL;
    }
    if (level->slopes) {
        free(level->slopes);
        level->slopes = NULL;
    }
    if (level->walls) {
        free(level->walls);
        level->walls = NULL;
    }
    if (level->surfaces) {
        free(level->surfaces);
        level->surfaces = NULL;
    }
    if (level->matFP) {
        free_uncached(level->matFP);
        level->matFP = NULL;
    }
    if (level->model) {
        t3d_model_free(level->model);
        level->model = NULL;
    }
    if (level->dpl) {
        block_free_safe(level->dpl);
        level->dpl = NULL;
    }
    level_init(level);
}
