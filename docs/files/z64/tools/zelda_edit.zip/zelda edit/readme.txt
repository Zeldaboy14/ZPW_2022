==Zelda: Ocarina of Time Debug ROM Editor 0.x Alpha==

This editor is specifically designed for the Zelda: Ocarina of Time Debugger's ROM. Currently, it will patch up common issues with the stock ROM, and can replace actors in several levels. I plan to add every level in the game, and add a wealth of options that are sure to please anyone interested in Ocarina of Time.. this is my ultimate goal, and I plan it for v1.0. I hope you enjoy what it can currently do. <:)


--Usage--

First of all, you need Microsoft's .NET Framework 2.0 for this to work. If you don't, you'll get an "application failed to start" error. You can download it at http://msdn.microsoft.com/netframework/ .

Second, your ROM needs to be a byteswapped ROM, modified or unmodified doesn't matter, just as long as it's byteswapped to big endian. You can use emul8or's bswap to do this, which you can get at http://www.dextrose.com/files/n64/build_tools/bswap.zip .

That's all that needs to be known. I tested it thoroughly and it should work fine given you keep in mind the above statements.

Enjoy!

-coolisool
 cooliscool@msn.com
 http://www.zso.krahs-emag.com(/forums)
 http://webpages.charter.net/cooliscool