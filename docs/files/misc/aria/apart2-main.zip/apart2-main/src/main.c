#include <libdragon.h>
#include <t3d/t3d.h>
#include "../include/config.h"
#include "../include/enums.h"
#include "../include/globals.h"
#include "../include/types.h"
#include "actors.h"
#include "camera.h"
#include "collision.h"
#include "debug.h"
#include "input.h"
#include "levels.h"
#include "lvl1.h"
#include "map.h"
#include "player.h"
#include "sound.h"
#include "ui.h"
#include "utils.h"
#include "test_level.h"

static sprite_t *background_sprite;
static sprite_t *title_sprite;
static sprite_t *dkd_sprite;
static rspq_block_t* background_block;
int title_end = 0;
// Far Apart: Sequel to Apart, A game about kid named Sirus
// the original game was about a Dragon who started the game going to the suicide forest
// and eventually became the original Dragon King
// Far apart takes place thousands of years into the future where his decendants get wiped ou
// Exept one,
// Aria Hirose. Who escaped genocide at the age of 8.
// She is now 24 and ready to settle the score, And Have closuse recovering the body of her sister Stara.


// Powered by IBE : Itty Bitty Engine, a 3D Game Engine for Tiny3D

void show_start_screen() {
    //holy fuck converting this to rsp code was a fucking nightmeare
    //how many fucking exerimental toolchains are going to default to
    //"the examples are the documentation"
    //the examples: unfathomable branching spagetty code thats not even 50 lines;

    surface_t* disp;
    int start_pressed = 0;
    int timer = 250;

    const char* game_modes[] = {"Story Mode", "Coop Story", "Death Match", "Laggy Match"}; // Array of game modes

    int num_modes = sizeof(game_modes) / sizeof(game_modes[0]);

    sprite_t* title_sprite = sprite_load("rom:/title.rgba16.sprite");
    sprite_t* dkd_sprite = sprite_load("rom:/dkd.rgba16.sprite");


	while (timer > 0){
	disp = display_try_get();
        if (disp) {
            rdpq_attach_clear(disp, NULL); // Clear screen with black background
            rdpq_set_mode_copy(true);
            rdpq_sprite_blit(
                dkd_sprite,
                0, // x postitin
                0, // y position
                NULL
            ); // Draw title screen image
            rdpq_detach_show();
            timer --;
        }
	}

	while (!start_pressed){
    joypad_poll();
    btn[0] = joypad_get_buttons_pressed(JOYPAD_PORT_1);
    btnheld[0] = joypad_get_buttons_held(JOYPAD_PORT_1);

   	if (btn[0].start) {
        numPlayers = current_mode + 1;
        start_pressed = 1;
    }

    disp = display_try_get();
      sound_update_buffer();
    if (disp) {
        rdpq_attach_clear(disp, NULL);
        rdpq_set_mode_copy(true);
        rdpq_sprite_blit(
            title_sprite,
            0, // x postitin
            0, // y position
            NULL
        );

        rdpq_text_printf(
           	&(rdpq_textparms_t){.disable_aa_fix = true, .style_id = STYLE_2,},      // Font settings, this is default
            	37,      // Font ID number
            	98,	    // X position
            	200,    // Y position
            	"press start"
        );

        rdpq_detach_show();
        }
	}

	//lets just reset this for reuse
	start_pressed = 0;

    while (!start_pressed) {
        joypad_poll();
        btn[0] = joypad_get_buttons_pressed(JOYPAD_PORT_1);
        btnheld[0] = joypad_get_buttons_held(JOYPAD_PORT_1);

        // Navigate modes with D-Pad

        if (btn[0].d_up || joypad_get_axis_pressed(JOYPAD_PORT_1, JOYPAD_AXIS_STICK_Y) == 1) {
            current_mode = (current_mode - 1 + num_modes) % num_modes; // Cycle up
        }

        if (btn[0].d_down || joypad_get_axis_pressed(JOYPAD_PORT_1, JOYPAD_AXIS_STICK_Y) == -1) {
            current_mode = (current_mode + 1) % num_modes; // Cycle down
        }

        // Check if Start button is pressed
        if (btn[0].start) {
            numPlayers = current_mode + 1;
            start_pressed = 1;
        }

        disp = display_try_get();
        if (disp) {
            rdpq_attach_clear(disp, NULL);
            rdpq_set_mode_copy(true);
            rdpq_sprite_blit(
                title_sprite,
                0, // x postitin
                0, // y position
                NULL
            ); // Draw title screen image

            // Display current mode
            rdpq_text_printf(
               	NULL,	// Font settings, this is default
               	37,		// Font ID number
               	100,	// X position
               	160,	// Y position
               	"Select Mode:"
           	);
            rdpq_text_printf(
               	NULL,	// Font settings, this is default
               	37,		// Font ID number
               	100,	// X position
               	190,	// Y position
               	game_modes[current_mode]
           	);

            rdpq_detach_show();
            title_end = 1;
        }
    }
}

int main()
{
  debug_init_isviewer();
  debug_init_usblog();
  asset_init_compression(3);
  wav64_init_compression(3);

  dfs_init(DFS_DEFAULT_LOCATION);

  display_init(RESOLUTION_320x240, DEPTH_16_BPP, 3, GAMMA_NONE, FILTERS_RESAMPLE_ANTIALIAS);
  surface_t depthBuffer = surface_alloc(FMT_RGBA16, display_get_width(), display_get_height());

  rdpq_init();
#ifdef DEBUG_RDP
  rdpq_debug_start();
  rdpq_debug_log(true);
#endif // DEBUG_RDP
  input_init();

  sprite_t* background_sprite = sprite_load("rom:/background.rgba16.sprite");

  rspq_block_begin();

      rdpq_set_mode_copy(false);
      rdpq_sprite_blit(background_sprite, 0, 0, &(rdpq_blitparms_t){
          .scale_x = 1, .scale_y = 1,
      });

      // Setup a mode for the rest of the sprites
      rdpq_set_mode_standard();
      rdpq_mode_filter(FILTER_BILINEAR);
      rdpq_mode_alphacompare(1);
      rdpq_mode_dithering(DITHER_SQUARE_SQUARE);
      rdpq_mode_antialias(false);
      rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);

  background_block = rspq_block_end();
  sound_init();
  sound_update_buffer();
  title_theme();
  ui_init();
  if (title_end == 1) goto SKIP_TITLE;
  show_start_screen();
SKIP_TITLE:
    mixer_ch_stop(SFX1);

  t3d_init((T3DInitParams){});

  debug_models_init();

  map_init();
  for (int i = 0; i < MAX_LEVELS; i++) {
    level_init(&levels[i]);
  }
  level_load(currLevel);
  actors_init();
  player_init();
  cam_init();
  xm_init();

  syncPoint = 0;

  for(;;)
  {
    // ======== Update ======== //
    int textureIndex = 0;
    if(btnheld[0].d_down){
      textureIndex = 1;
    } else {
      textureIndex = 0;
    }

    get_jump_time();
    input_update();

    // Simple Pause State
    if (!isPaused){
      actors_update();
      player_update();
      cam_update();
    }

    sound_update_buffer();

    t3d_mat4fp_from_srt_euler(levels[currLevel].matFP, (float[3]){1.0f, 1.0f, 1.0f}, (float[3]){0, 0, 0}, (float[3]){0, 0, 0});

    // Update actor matrices
    for (int c = 0; c < numCrates; ++c) {
      t3d_mat4fp_from_srt_euler(crateMatFP[c],
        (float[3]){2.0f, 2.0f, 2.0f},
        (float[3]){0, 0, 0},
        crates[c]->pos.v
      );
    }


    for (int i = 0; i < numPlayers; ++i) {
          // Calculate blend factor based on current speed
          float animTransPoint = 0.6, blendFactor = (player[i]->currSpeed - 1.0f) / (animTransPoint);
          blendFactor = fminf(fmaxf(blendFactor, 0.0f), 1.0f); // clamp blendFactor between 0 and 1

          // Blend the two movement animations
          if(playerState[i] == PLAYER_RUN && playerState[i] != PLAYER_ATTACK && playerState[i] != PLAYER_ATTACK_START && playerState[i] != PLAYER_ROLL)t3d_skeleton_blend(&playerSkelBlend[i], &playerSkelBlend[i], &playerSkelRun[i], blendFactor);

          // We now blend the movement animation with the idle/attack one
          t3d_skeleton_blend(&playerSkel[i], &playerSkel[i], &playerSkelBlend[i], player[i]->animBlend);
    }


    if(syncPoint)rspq_syncpoint_wait(syncPoint);

    // Now recalc. the matrices, this will cause any model referencing them to use the new pose
    for (int i = 0; i < numPlayers; ++i) {
      t3d_skeleton_update(&playerSkel[i]);
    }

    for (int np = 0; np < numPlayers; ++np) {
      // Update players matrices
      t3d_mat4fp_from_srt_euler(playerMatFP[np],
          player[np]->scale.v,
          (float[3]){0, -player[np]->rot.v[1], 0},
          player[np]->pos.v
        );
    }

    // Update player's extra matrices separately
    for (int p = 0; p < numPlayers; ++p) {

      /*t3d_mat4fp_from_srt_euler(projectileMatFP[p],
        (float[3]){0.5f, 0.5f, 0.5f},
        (float[3]){player[p]->rot.v[0], -player[p]->rot.v[1], player[p]->rot.v[2]},
        player[p]->projectile.pos.v
      );*/

      t3d_mat4fp_from_srt_euler(shadowMatFP[p],
        (float[3]){0.25f, 0.25f, 0.25f},
        (float[3]){player[p]->shadowRot.v[0], 0.0f, -player[p]->shadowRot.v[2]},
        player[p]->shadowPos.v
      );

      t3d_mat4fp_from_srt_euler(playerhitboxMatFP[p],
        (float[3]){1.0f, 1.0f, 1.0f},
        (float[3]){0.0f, 0.0f, 0.0f},
        player[p]->hitbox.center.v
      );

      t3d_mat4fp_from_srt_euler(projectilehitboxMatFP[p],
        (float[3]){(0.0625f * player[p]->projectile.hitbox.radius),
                    (0.0625f * player[p]->projectile.hitbox.radius),
                    (0.0625f * player[p]->projectile.hitbox.radius)},
        (float[3]){0.0f, 0.0f, 0.0f},
        player[p]->projectile.hitbox.center.v
      );

    }


    // ======== Draw (3D) ======== //
    rdpq_attach(display_get(), &depthBuffer);
    rdpq_sync_pipe();
    t3d_frame_start();

    color_t fogColor = T_CYAN;
    rdpq_set_prim_color(CYAN);
    rdpq_mode_fog(RDPQ_FOG_STANDARD);
    rdpq_set_fog_color(fogColor);

    t3d_screen_clear_color(CYAN);
    rspq_block_run(background_block);
    t3d_screen_clear_depth();

    t3d_fog_set_range(128.0f, 512.0f);
    t3d_fog_set_enabled(true);

    t3d_light_set_ambient(colorAmbient);
    t3d_light_set_count(1);

    // Draw viewports
    float fov = T3D_DEG_TO_RAD(45.0f);
    float fov2p = T3D_DEG_TO_RAD(45.5f);
    float fov4p = T3D_DEG_TO_RAD(45.0f);
    float near = 4.0f;
    float lessnear = 6.0f;
    float far = 512.0f;
    float farcoop = 256.0f;
    float fardeathmatch = 128.0f;
    for (int i = 0; i < numPlayers; ++i) {
      rdpq_sync_pipe();
      t3d_frame_start();
      rdpq_set_prim_color(CYAN);
      rdpq_mode_fog(RDPQ_FOG_STANDARD);
      rdpq_set_fog_color(fogColor);
      t3d_screen_clear_depth();
      t3d_fog_set_range(32.0f, 256.0f);
      t3d_fog_set_enabled(true);
      T3DViewport *vp = &player[i]->cam.viewport;
      T3DVec3 CP = player[i]->cam.camPos;
      T3DVec3 CT = player[i]->cam.camTarget;

      // FOV looks off at different window sizes, so adjust
      if (numPlayers == 2){
        t3d_viewport_set_projection(vp, fov2p, lessnear, farcoop);
      }else if (numPlayers == 3){
        t3d_viewport_set_projection(&player[0]->cam.viewport, fov2p, lessnear, fardeathmatch);
        t3d_viewport_set_projection(&player[1]->cam.viewport, fov4p, near, fardeathmatch);
        t3d_viewport_set_projection(&player[2]->cam.viewport, fov4p, near, fardeathmatch);
      } else if (numPlayers == 4){
        t3d_viewport_set_projection(vp, fov4p, near, fardeathmatch);
      } else {
        t3d_viewport_set_projection(vp, fov, near, far);
      }

      t3d_viewport_look_at(vp, &CP, &CT, &up);
      t3d_viewport_attach(vp);
      t3d_light_set_directional(0, colorDir, &lightDirVec);


      // debug render toggle
      if(debug_mode == DEBUG_RENDER_ALL || debug_mode == DEBUG_HIDE_OBJECTS){
        // Run levels block
        //t3d_segment_set(SEGMENT_LEVELS, &testLevelMatFP);

        rspq_block_run(levels[currLevel].dpl);
      }

      if(debug_mode == DEBUG_RENDER_ALL || debug_mode == DEBUG_HIDE_LEVEL){
        // then actors
        for (int c = 0; c < numCrates; ++c) {
          rspq_block_run(dplCrate[c]);
        }

        rdpq_set_lookup_address(1, sprites[textureIndex]->data);
      }

      // then the player blocks
      for (int p = 0; p < numPlayers; ++p) {

      if(numPlayers < 2){
          rspq_block_run(dplShadow[p]);
        }
         // Select Weapon based on index (e.g., from user input)
        switch (player[p]->weaponIndex) {
            case 0:
                    player[p]->isSword = true;
                    break;
            case 1:
                    player[p]->isSword = true;
                    rspq_block_run(dplSword[p]);
                break;
            case 2:
                    player[p]->isSword = true;
                    rspq_block_run(dplSword[p]);
                    rdpq_sync_pipe();
                    rspq_block_run(dplDragona[p]);
                break;
            case 3:
                    player[p]->isSword = false;
                    rspq_block_run(dplBaretta[p]);
                break;
            case 4:
                    player[p]->isSword = false;
                    rspq_block_run(dplRemington[p]);
                break;
        }
        rdpq_sync_pipe();
        switch (player[p]->costumeIndex) {
            case 0:
                    player[p]->isNude = true;
                    rspq_block_run(dplPlayerBody[p]);
                    player[p]->isSpecial ? rspq_block_run(dplPlayerPubicSpecial[p]) : rspq_block_run(dplPlayerPubic[p]);
                break;
            case 1:
                    player[p]->isNude = true;
                    rspq_block_run(dplPlayerSweatpants[p]);
                    //player[p]->isSpecial ? rspq_block_run(dplPlayerPubicSpecial[p]) : rspq_block_run(dplPlayerPubic[p]);
                break;
            case 2:
                    player[p]->isNude = false;
                    rspq_block_run(dplPlayerCasual[p]);
                break;
            case 3:
                    player[p]->isNude = false;
                    rspq_block_run(dplPlayerClothes[p]);
                break;
            case 4:
                    player[p]->isNude = false;
                    rspq_block_run(dplPlayerArmor[p]);
                break;

        }

        rdpq_sync_pipe();

        switch (player[p]->headIndex) {
            case 1:
                  player[p]->isSpecial = false;
                  player[p]->isTrimmed = false;
                  rspq_block_run(dplPlayerHead[p]);
                  rdpq_sync_pipe();
                  rspq_block_run(dplPlayerHair[p]);
                break;
            case 2:
                  player[p]->isSpecial = false;
                  player[p]->isTrimmed = true;
                  rspq_block_run(dplPlayerHead[p]);
                  rdpq_sync_pipe();
                  rspq_block_run(dplPlayerHairShort[p]);
                break;
            case 3:
                  player[p]->isTrimmed = false;
                  player[p]->isSpecial = true;
                  rspq_block_run(dplPlayerHeadSpecial[p]);
                  rdpq_sync_pipe();
                  rspq_block_run(dplPlayerHairSpecial[p]);
                break;
        }
        // checks if your using your special ability
        // horns also come out when being unconfortable (low health)
        // being very confortable (full health)
        // if your nude theres no inbetween your one or the other
        if((player[p]->isSpecial || player[p]->isNude || player[p]->health < 40 || player[p]->health == 200)
                    && player[p]->headIndex > 0){
                    rdpq_sync_pipe();
                    rspq_block_run(dplPlayerSpecial[p]);
        }
      }

      rdpq_sync_pipe();
      // then the player's extra blocks
      for (int d = 0; d < numPlayers; ++d) {
        if(col_debug){
          if(dplFloorTri != NULL && col_floor){
            rspq_block_run(dplFloorTri);
          }
          if(dplSlopeTri != NULL && col_slope){
            rspq_block_run(dplSlopeTri);
          }
          if(dplWallTri != NULL && col_wall){
            rspq_block_run(dplWallTri);
          }
          rspq_block_run(dplPlayerHitBox[d]);
          rspq_block_run(dplProjectileHitBox[d]);
        }
      }

    }

    syncPoint = rspq_syncpoint_new();

    // ======== Draw (UI) ======== //

    int sizeX = display_get_width();
    int sizeY = display_get_height();
    rdpq_sync_pipe();
    rdpq_set_scissor(0, 0, sizeX, sizeY);
    rdpq_set_mode_standard();
    rdpq_set_mode_fill(BLACK);

    // draw thick lines between the screens
    switch (numPlayers){
      case 1:
        break;
      case 2:
        rdpq_fill_rectangle(0, sizeY/2-1, sizeX, sizeY/2+1);
        break;
      case 3:
        rdpq_fill_rectangle(0, sizeY/2-1, sizeX, sizeY/2+1);
        rdpq_fill_rectangle(sizeX/2-1, sizeY/2, sizeX/2+1, sizeY);
        break;
      case 4:
        rdpq_fill_rectangle(0, sizeY/2-1, sizeX, sizeY/2+1);
        rdpq_fill_rectangle(sizeX/2-1, 0, sizeX/2+1, sizeY);
        break;
    }
    ui_update();
    draw_debug_ui();

    rdpq_detach_show();
  }


  // Clean up
  t3d_model_free(modelMap);
  free_uncached(mapMatFP);
  rspq_block_free(dplMap);
  t3d_model_free(modelMesh);
  free_uncached(meshMatFP);
  rspq_block_free(dplMesh);

  t3d_model_free(modelDebugBox);
  t3d_model_free(modelDebugSphere);

  for (int i = 0; i < numPlayers; ++i) {
    t3d_skeleton_destroy(&playerSkel[i]);
    t3d_skeleton_destroy(&playerSkelBlend[i]);
    t3d_skeleton_destroy(&playerSkelRun[i]);

    t3d_anim_destroy(&animIdle[i]);
    t3d_anim_destroy(&animWalk[i]);
    t3d_anim_destroy(&animRun[i]);
    t3d_anim_destroy(&animJump[i]);
    t3d_anim_destroy(&animAttack[i]);
    t3d_anim_destroy(&animFire[i]);
    t3d_anim_destroy(&animFireBig[i]);
    t3d_anim_destroy(&animFall[i]);
    t3d_anim_destroy(&animRoll[i]);

    t3d_model_free(modelPlayer);
    t3d_model_free(modelAriaBody);
    t3d_model_free(modelAriaPubic);
    t3d_model_free(modelAriaSweatpants);
    t3d_model_free(modelAriaCasual);
    t3d_model_free(modelAriaClothes);
    t3d_model_free(modelAriaArmor);
    t3d_model_free(modelAriaHead);
    t3d_model_free(modelAriaHeadShort);
    t3d_model_free(modelAriaHeadSpecial);
    t3d_model_free(modelDragona);
    t3d_model_free(modelDragonaTrue);
    t3d_model_free(modelBaretta);
    t3d_model_free(modelShadow);
    t3d_model_free(modelProjectile);

    free_uncached(playerMatFP[i]);
    free_uncached(shadowMatFP[i]);
    free(player[i]);
    free_uncached(projectileMatFP[i]);
    free_uncached(playerhitboxMatFP[i]);
    free_uncached(projectilehitboxMatFP[i]);

    rspq_block_free(dplPlayerHitBox[i]);
    rspq_block_free(dplProjectileHitBox[i]);
    rspq_block_free(dplShadow[i]);
    //rspq_block_free(dplProjectile[i]);
    //rspq_block_free(dplPlayer[i]);
    rspq_block_free(dplPlayerBody[i]);
    rspq_block_free(dplPlayerPubic[i]);
    rspq_block_free(dplPlayerPubicSpecial[i]);
    rspq_block_free(dplPlayerClothes[i]);
    rspq_block_free(dplPlayerHead[i]);
    rspq_block_free(dplPlayerHeadSpecial[i]);
    rspq_block_free(dplPlayerSpecial[i]);
    rspq_block_free(dplPlayerHairShort[i]);
    rspq_block_free(dplPlayerHair[i]);
    rspq_block_free(dplPlayerHairSpecial[i]);
    rspq_block_free(dplSword[i]);
    rspq_block_free(dplDragona[i]);
    rspq_block_free(dplBaretta[i]);
    rspq_block_free(dplRemington[i]);
  }

  free_octree(boxOctree, true);

  for (int i = 0; i < numCrates; ++i) {
    t3d_model_free(modelCrate);
    free_uncached(crateMatFP[i]);
    rspq_block_free(dplCrate[i]);
  }


  t3d_destroy();
  return 0;
}
