Banjo's Backpack V1.0 is a Banjo Kazooie Setup Editor and Level importer by Brendan "Skill" Nilsson, Adam "Coolboyman" Vierra and Subdrag

For support and information on how to use the program visit rarewarecentral.com