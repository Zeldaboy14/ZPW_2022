#include "uLib.h"
#include "code/z_player_lib.h"
#include "playas/playas.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

Asm_VanillaHook(Player_OverrideLimbDrawGameplayFirstPerson);
s32 Player_OverrideLimbDrawGameplayFirstPerson(PlayState* play, s32 limbIndex, Gfx** dList, Vec3f* pos, Vec3s* rot,
                                               void* thisx) {
    Player* this = (Player*)thisx;

    if (!Player_OverrideLimbDrawGameplayCommon(play, limbIndex, dList, pos, rot, thisx)) {
		if (limbIndex == PLAYER_LIMB_L_FOREARM) {
            *dList = sFirstPersonLeftForearmDLs[(void)0, gSaveContext.linkAge];
        
        } else if (limbIndex == PLAYER_LIMB_L_HAND) {
            *dList = sFirstPersonLeftHandDLs[(void)0, gSaveContext.linkAge];

        //All Ages/ equips for flashing piece of tunic when pausing
        } else if (limbIndex == PLAYER_LIMB_R_SHOULDER) {
            *dList = sFirstPersonRightShoulderDLs[(void)0, gSaveContext.linkAge];
        
        //Bow Right Forearm Adult
        } else if (limbIndex == PLAYER_LIMB_R_FOREARM) {
            *dList = sFirstPersonForearmDLs[(void)0, gSaveContext.linkAge];
        
        //bow/slingshot/hookshot
        } else if (limbIndex == PLAYER_LIMB_R_HAND) {
            
            if (Player_HoldsHookshot(this)){
                if (LINK_IS_ADULT){
                    *dList = gPlayAsLUT_Adult_HookshotFpsHandR; 
                }else{
                    *dList = gPlayAsLUT_Child_HookshotFpsHandR; 
                }

            }else if (this->itemActionParam == PLAYER_AP_SLINGSHOT){
                if (LINK_IS_ADULT){
                    *dList = gPlayAsLUT_Adult_SlingshotFps;
                }else{
                    *dList = gPlayAsLUT_Child_SlingshotFps;
                }
            }else{
                *dList = sFirstPersonRightHandHoldingWeaponDLs[(void)0, gSaveContext.linkAge];
            }
		// Fixs backporting MM's shield code in overridelimbdrawgameplay	
		} else if (limbIndex != PLAYER_LIMB_SHEATH  ) {
			*dList = NULL;
        }
    }

    return false;
}