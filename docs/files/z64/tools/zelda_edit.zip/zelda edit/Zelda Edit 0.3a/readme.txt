Zelda: Ocarina of Time Debug ROM Editor 0.3 Alpha

Changes as of 0.3:

Bugfixes mostly,

[global - fix] Yet another (rare) memory leak. Stupid cause, misplaced EndIf.
[fixes - fix] "Fix 125 GPU Errors" is no longer a workaround but a complete fix. All graphics intact and working perfectly (Nemu/Rice only? Hmm, have to look into that).
[actors - addition] Ability to revert actors to defaults.
[actors - addition] Ability to put actors on 121's pedestal via checkbox. If the box is not checked, the program will revert the actor to the blue warp's default position. Will make a bit more foolproof in the future.

Changes as of 0.2:

Finally came up with a nice hex to string routine, by loading the hex into a byte array and writing it as string. :)

So now, Zelda Edit is capable of two things: Streamlined Actor Hacking (Zora's Domain [untested] and Stalfos Boss Room (121) as of now, via the "function menu"), and ROM Fixes. Still nowhere near my final expectations, but much closer. Also, it now uses internal resources so the app can be ran from any location. Processes should be much faster too - optimized and cleaned up the fixes code quite a lot. I found a nasty memory leak which SHOULD be fixed. If Zelda Edit leaves a zombie-instance taking up ~500MB of RAM, let me know!

Bugfix - Tab order is now correct. Search function being implemented.

--Usage--

First of all, you need Microsoft's .NET Framework 2.0 for this to work. If you don't, you'll get an "application failed to start" error. You can download it at http://msdn.microsoft.com/netframework/ .

Second, your ROM needs to be a byteswapped ROM, modified or unmodified doesn't matter, just as long as it's byteswapped to big endian. You can use emul8or's bswap to do this, which you can get at http://www.dextrose.com/files/n64/build_tools/bswap.zip .

That's all that needs to be known. I tested it thoroughly and it should work fine given you keep in mind the above statements.

Enjoy!

-coolisool
 cooliscool@msn.com
 http://www.zso.krahs-emag.com(/forums)