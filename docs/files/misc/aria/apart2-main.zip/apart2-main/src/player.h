#ifndef PLAYER_H
#define PLAYER_H


#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3danim.h>
#include <t3d/t3dskeleton.h>
#include "../include/config.h"
#include "../include/enums.h"
#include "../include/globals.h"
#include "../include/types.h"
#include "actors.h"
#include "camera.h"
#include "collision.h"
#include "debug.h"
#include "input.h"
#include "levels.h"
#include "map.h"
#include "octree_test.h"
#include "sound.h"
#include "utils.h"
#include "test_level.h"

extern T3DMat4FP* playerMatFP[MAX_PLAYERS];
extern T3DMat4FP* shadowMatFP[MAX_PLAYERS];
extern T3DMat4FP* projectileMatFP[MAX_PLAYERS];
extern T3DMat4FP* playerhitboxMatFP[MAX_PLAYERS];
extern T3DMat4FP* projectilehitboxMatFP[MAX_PLAYERS];
extern T3DModel *modelPlayer;
extern T3DModel *modelAriaHead;
extern T3DModel *modelAriaHeadSpecial;
extern T3DModel *modelAriaHeadShort;
extern T3DModel *modelAriaAnim;
extern T3DModel *modelAriaBody;
extern T3DModel *modelAriaPubic;
extern T3DModel *modelAriaSweatpants;
extern T3DModel *modelAriaCasual;
extern T3DModel *modelAriaClothes;
extern T3DModel *modelAriaArmor;
extern T3DModel *modelBaretta;
extern T3DModel *modelRemington;
extern T3DModel *modelDragona;
extern T3DModel *modelDragonaTrue;
extern T3DModel *modelProjectile;
extern T3DModel *modelShadow;
extern T3DSkeleton playerSkel[MAX_PLAYERS];
extern T3DSkeleton playerSkelBlend[MAX_PLAYERS];
extern T3DSkeleton playerSkelRun[MAX_PLAYERS];
extern T3DAnim animIdle[MAX_PLAYERS];
extern T3DAnim animWalk[MAX_PLAYERS];
extern T3DAnim animRun[MAX_PLAYERS];
extern T3DAnim animJump[MAX_PLAYERS];
extern T3DAnim animAttack[MAX_PLAYERS];
extern T3DAnim animPunch[MAX_PLAYERS];
extern T3DAnim animFire[MAX_PLAYERS];
extern T3DAnim animFireBig[MAX_PLAYERS];
extern T3DAnim animFall[MAX_PLAYERS];
extern T3DAnim animRoll[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHitBox[MAX_PLAYERS];
extern rspq_block_t *dplProjectileHitBox[MAX_PLAYERS];
extern rspq_block_t *dplPlayer[MAX_PLAYERS];
extern rspq_block_t *dplPlayerBody[MAX_PLAYERS];
extern rspq_block_t *dplPlayerPubic[MAX_PLAYERS];
extern rspq_block_t *dplPlayerPubicSpecial[MAX_PLAYERS];
extern rspq_block_t *dplPlayerSweatpants[MAX_PLAYERS];
extern rspq_block_t *dplPlayerCasual[MAX_PLAYERS];
extern rspq_block_t *dplPlayerClothes[MAX_PLAYERS];
extern rspq_block_t *dplPlayerArmor[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHead[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHeadSpecial[MAX_PLAYERS];
extern rspq_block_t *dplPlayerSpecial[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHair[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHairShort[MAX_PLAYERS];
extern rspq_block_t *dplPlayerHairSpecial[MAX_PLAYERS];
extern rspq_block_t *dplSword[MAX_PLAYERS];
extern rspq_block_t *dplDragona[MAX_PLAYERS];
extern rspq_block_t *dplBaretta[MAX_PLAYERS];
extern rspq_block_t *dplRemington[MAX_PLAYERS];
extern rspq_block_t *dplProjectile[MAX_PLAYERS];
extern rspq_block_t *dplShadow[MAX_PLAYERS];
extern rspq_block_t *currentWeapon[MAX_PLAYERS];
extern PlayerParams *player[MAX_PLAYERS];
extern int playerState[MAX_PLAYERS];
extern int airAttackCount;
extern int weaponMax;
extern int costumeMax;
extern int headMax;
extern actioniconid actionicon[MAX_PLAYERS];
// Declaration of switch-based selection functions
extern void selectWeapon(int index);
extern void selectCostume(int index);
extern void selectHead(int index);


void check_player_collisions(PlayerParams *players[], int numPlayers);
void player_init(void);
void check_actor_collisions(Actor **actor, int actorCount, int playerCount);
void check_attack_collisions(Actor **actor, int actorCount, int playerCount);
void player_bounced(PlayerParams *player[], int playerCount) ;
void check_midair_actor_collisions(Actor **actor, int actorCount, int playerCount);
void player_update(void);


#endif // PLAYER_H
