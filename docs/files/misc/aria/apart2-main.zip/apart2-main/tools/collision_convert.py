import sys

SCALE_FACTOR = 64 * 0.3

def parse_obj_file(input_file):
    vertices = []
    triangles = []
    with open(input_file, 'r') as file:
        for line in file:
            if line.startswith('v '):
                parts = line.split()
                x, y, z = map(float, parts[1:4])
                vertices.append((x * SCALE_FACTOR, y * SCALE_FACTOR, z * SCALE_FACTOR))
            elif line.startswith('f '):
                parts = line.split()
                indices = [int(p.split('/')[0]) - 1 for p in parts[1:]]
                if len(indices) == 3:
                    triangles.append(tuple(indices))
    return vertices, triangles

def write_header_file(vertices, triangles, output_file):
    with open(output_file, 'w') as file:
        file.write("#ifndef TRIANGLE_DATA_H\n")
        file.write("#define TRIANGLE_DATA_H\n\n")
        file.write("Triangle triangles[] = {\n")

        for triangle in triangles:
            file.write("    {{\n")
            for idx in triangle:
                x, y, z = vertices[idx]
                file.write(f"        {{ {{ {x:.6f}f, {y:.6f}f, {z:.6f}f }} }},\n")
            file.write("    }},\n")

        file.write("};\n\n")
        file.write("#endif // TRIANGLE_DATA_H\n")

def main():
    if len(sys.argv) != 3:
        print("Usage: python script.py <input.obj> <output.h>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    vertices, triangles = parse_obj_file(input_file)

    if not vertices or not triangles:
        print("Error: No vertices or triangles found in the OBJ file.")
        sys.exit(1)

    write_header_file(vertices, triangles, output_file)

if __name__ == "__main__":
    main()
