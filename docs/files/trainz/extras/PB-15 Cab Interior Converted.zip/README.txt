For those wondering why I've done this, it's to help those who want to make custom cab controls in blender
have a rough template of what to do. This also serves incase you want to use the PB-15 Cab Controls in a custom cab shell
that is not the original PB-15 cab. I did this so it would A: Save others time for those who wanna just use the controls
in a custom shell and B: For those looking into making there own custom cab controls in blender. Enjoy!

		Zeldaboy14 - Owner of Zeldaboy14 Production Works/Co-Owner of Railroad Custom Works