#include "uLib.h"
#include "z64player.h"
#include <z64hdr.h>
#include <playas/playas.h>
#include "code/z_player_lib.h"
#include "assets/objects/object_link_boy/object_link_boy.h"
#include "assets/objects/object_link_child/object_link_child.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

#define PLAYER_MODELGROUP_MASTER 020205

u8 sPauseModelGroupBySword[] = {
    PLAYER_MODELGROUP_SWORD, // PLAYER_SWORD_KOKIRI
    PLAYER_MODELGROUP_MASTER, // PLAYER_SWORD_MASTER
    PLAYER_MODELGROUP_BGS,   // PLAYER_SWORD_BGS
};
