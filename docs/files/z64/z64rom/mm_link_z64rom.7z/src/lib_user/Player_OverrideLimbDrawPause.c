#include <uLib.h>
#include "code/z_player_lib.h"
#include "z64item.h"

#include <z64hdr.h>
#include "playas/playas.h"
#include "code/z_player_lib.h"
#include "uLib.h"
#include "z64camera.h"
#include "z64player.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

// z64ram = 0x80091880
// z64rom = 0xB08A20
// z64next = 0x80091a24

Gfx* gPlayerSheathedSwordsChildPause[] = {
    gPlayAsLUT_Child_SheathedSword, gPlayAsLUT_Child_SheathedSword,
    gPlayAsLUT_Child_SheathedMaster, gPlayAsLUT_Child_SheathedMaster, 
	gPlayAsLUT_Child_SheathedBiggoron, gPlayAsLUT_Child_SheathedBiggoron,
};

Gfx* gPlayerSwordSheathsChildPause[] = {
    gPlayAsLUT_Child_SheathKokiri, gPlayAsLUT_Child_SheathKokiri, 
	gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
    gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
};

Gfx* gPlayerSheathedSwordsAdultPause[] = {
    gPlayAsLUT_Adult_SheathedKokiri, gPlayAsLUT_Adult_SheathedKokiri, gPlayAsLUT_Adult_SheathedSword,
    gPlayAsLUT_Adult_SheathedSword,  gPlayAsLUT_Adult_SheathedBiggoron, gPlayAsLUT_Adult_SheathedBiggoron,
};

Gfx* gPlayerSwordSheathsAdultPause[] = {
    gPlayAsLUT_Adult_SheathKokiri, gPlayAsLUT_Adult_SheathKokiri, gPlayAsLUT_Adult_SheathMaster,
    gPlayAsLUT_Adult_SheathMaster,  gPlayAsLUT_Adult_SheathBiggoron, gPlayAsLUT_Adult_SheathBiggoron,
};

Asm_VanillaHook(Player_OverrideLimbDrawPause);
s32 Player_OverrideLimbDrawPause(PlayState* play, s32 limbIndex, Gfx** dList, Vec3f* pos, Vec3s* rot, void* arg) {
    u8* playerSwordAndShield = arg;
    //! @bug `playerSwordAndShield[0]` can be 0 (`PLAYER_SWORD_NONE`), which indexes `sPauseModelGroupBySword[-1]`.
    //! The result happens to be 0 (`PLAYER_MODELGROUP_0`) in vanilla, but weird values are likely to cause a crash.
    u8 modelGroup = sPauseModelGroupBySword[playerSwordAndShield[0] - PLAYER_SWORD_KOKIRI];
    s32 type;
    s32 dListOffset = 0;
    Gfx** dLists;
	EquipValueSword swordEquipValue;

    //if ((modelGroup == PLAYER_MODELGROUP_SWORD) && !LINK_IS_ADULT &&
    //    (playerSwordAndShield[1] == PLAYER_SHIELD_HYLIAN)) {
    //    modelGroup = PLAYER_MODELGROUP_CHILD_HYLIAN_SHIELD;
    //}

    /*if (limbIndex == PLAYER_LIMB_L_HAND) {
        type = gPlayerModelTypes[modelGroup][PLAYER_MODELGROUPENTRY_LEFT_HAND];
        sLeftHandType = type;
        if ((type == PLAYER_MODELTYPE_LH_BGS) && (gSaveContext.swordHealth <= 0.0f)) {
            //dListOffset = 4;
        }
    } else if (limbIndex == PLAYER_LIMB_R_HAND) {
        type = gPlayerModelTypes[modelGroup][PLAYER_MODELGROUPENTRY_RIGHT_HAND];
        sRightHandType = type;
        if (type == PLAYER_MODELTYPE_RH_SHIELD) {
            dListOffset = playerSwordAndShield[1] * 4;
			//dListOffset = &gPlayerSwordSheathsChildPause[2 * ((swordEquipValue - 1) ^ 0)];
        }
    } else if (limbIndex == PLAYER_LIMB_SHEATH) {
        type = gPlayerModelTypes[modelGroup][PLAYER_MODELGROUPENTRY_SHEATH];
        if ((type == PLAYER_MODELTYPE_SHEATH_18) || (type == PLAYER_MODELTYPE_SHEATH_19)) {
            dListOffset = playerSwordAndShield[1] * 4;
			//dListOffset = &gPlayerSwordSheathsChildPause[2 * ((swordEquipValue - 1) ^ 0)];
		} else {
			dListOffset = &gPlayerSwordSheathsChildPause[2 * ((swordEquipValue - 1) ^ 0)];
        }
    } else if (limbIndex == PLAYER_LIMB_WAIST) {
        type = gPlayerModelTypes[modelGroup][PLAYER_MODELGROUPENTRY_WAIST];
    } else {
        return false;
    }

    dLists = sPlayerDListGroups[type] + ((void)0, gSaveContext.linkAge);
    *dList = *(dLists + dListOffset);
	
    return false;*/
}