#include <uLib.h>
#include "code/z_player_lib.h"
#include "z64item.h"
#include "functions.h"
#include "z64.h"

#include "include/mm_glowingswords.h"
//#include "motion_blur_defines.c"
//#include "include/mm_anim_mat.c"

#include <z64hdr.h>
#include "playas/playas.h"
#include "z64camera.h"
#include "z64player.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

typedef struct PlayerAnimationFrame {
    /* 0x000 */ Vec3s frameTable[PLAYER_LIMB_MAX];
    /* 0x108 */ s16 appearanceInfo; // bitpack containing the face and hands info
} PlayerAnimationFrame; // size = 0x10A

#define PLAYER_STATE3_2000       (1 << 13)
#define GET_LEFT_HAND_INDEX_FROM_JOINT_TABLE(jointTable)   (GET_APPEARANCE_FROM_JOINT_TABLE(jointTable) & 0xF000)
#define GET_APPEARANCE_FROM_JOINT_TABLE(jointTable)           (((PlayerAnimationFrame *)(jointTable))->appearanceInfo)

s32 D_801F59E0;

// z64ram = 0x80090014
// z64rom = 0xB071B4
// z64next = 0x800902F0

Gfx* gPlayerSheathedSwordsChild[] = {
    gPlayAsLUT_Child_SheathedSword, gPlayAsLUT_Child_SheathedSword,
    gPlayAsLUT_Child_SheathedMaster, gPlayAsLUT_Child_SheathedMaster, 
	gPlayAsLUT_Child_SheathedBiggoron, gPlayAsLUT_Child_SheathedBiggoron,
};

Gfx* gPlayerSheathedSwordsChildFlag[] = {
    gPlayAsLUT_Child_SheathedSwordR, gPlayAsLUT_Child_SheathedSwordR,
    gPlayAsLUT_Child_SheathedMaster, gPlayAsLUT_Child_SheathedMaster, 
	gPlayAsLUT_Child_SheathedBiggoron, gPlayAsLUT_Child_SheathedBiggoron,
};

Gfx* gPlayerSwordSheathsChild[] = {
    gPlayAsLUT_Child_SheathKokiri, gPlayAsLUT_Child_SheathKokiri, 
	gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
    gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
};

Gfx* gPlayerSwordSheathsChildFlag[] = {
    gPlayAsLUT_Child_SheathRazor, gPlayAsLUT_Child_SheathRazor, 
	gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
    gPlayAsLUT_Child_SheathMaster, gPlayAsLUT_Child_SheathMaster, 
};

Gfx* gPlayerSheathedSwordsAdult[] = {
    gPlayAsLUT_Adult_SheathedKokiri, gPlayAsLUT_Adult_SheathedKokiri, 
	gPlayAsLUT_Adult_SheathedSword, gPlayAsLUT_Adult_SheathedSword,
	gPlayAsLUT_Adult_SheathedBiggoron, gPlayAsLUT_Adult_SheathedBiggoron,
};

Gfx* gPlayerSwordSheathsAdult[] = {
    gPlayAsLUT_Adult_SheathKokiri, gPlayAsLUT_Adult_SheathKokiri, 
	gPlayAsLUT_Adult_SheathMaster, gPlayAsLUT_Adult_SheathMaster,  
	gPlayAsLUT_Adult_SheathBiggoron, gPlayAsLUT_Adult_SheathBiggoron,
};

Gfx** D_801C095C[] = {
    gPlayerLeftHandClosedDLs,
    gPlayerLeftHandOpenDLs,
};
Gfx** D_801C0964[] = {
    sPlayerRightHandClosedDLs,
    sPlayerRightHandOpenDLs,
};

Gfx* gPlayerSwordMM[] = {
    // EQUIP_VALUE_SWORD_KOKIRI
    gPlayAsLUT_Child_Sword1FistL, // Adult
    gPlayAsLUT_Child_Sword1FistL,
    // EQUIP_VALUE_SWORD_RAZOR
    gPlayAsLUT_Child_Sword2FistL,
    gPlayAsLUT_Child_Sword2FistL,
    // EQUIP_VALUE_SWORD_GILDED
    gPlayAsLUT_Child_Sword3FistL,
    gPlayAsLUT_Child_Sword3FistL,
};

Gfx* gPlayerSwordMMAdult[] = {
    // EQUIP_VALUE_SWORD_KOKIRI
    gPlayAsLUT_Adult_Sword1FistL, // Adult
    gPlayAsLUT_Adult_Sword1FistL,
    // EQUIP_VALUE_SWORD_RAZOR
    gPlayAsLUT_Adult_Sword2FistL,
    gPlayAsLUT_Adult_Sword2FistL,
    // EQUIP_VALUE_SWORD_GILDED
    gPlayAsLUT_Adult_Sword3FistL,
    gPlayAsLUT_Adult_Sword3FistL,
};

Gfx* gPlayerSwordMM2[] = {
    // EQUIP_VALUE_SWORD_KOKIRI
    gPlayAsLUT_Adult_Sword1FistL, // Adult
    gPlayAsLUT_Child_SwordRFistL,
    // EQUIP_VALUE_SWORD_RAZOR
    gPlayAsLUT_Adult_Sword2FistL,
    gPlayAsLUT_Child_Sword1FistL,
    // EQUIP_VALUE_SWORD_GILDED
    gPlayAsLUT_Adult_Sword2FistL,
    gPlayAsLUT_Child_Sword2FistL,
};

Gfx* gPlayerHandHoldingShields[2 * (PLAYER_SHIELD_MAX - 1)] = {
    gPlayAsLUT_Child_Shield1FistR,
    gPlayAsLUT_Child_Shield1FistR,
    gPlayAsLUT_Child_Shield2FistR,
    gPlayAsLUT_Child_Shield2FistR,
    gPlayAsLUT_Child_Shield3FistR,
    gPlayAsLUT_Child_Shield3FistR,
};

Gfx* gPlayerHandHoldingShieldsAdult[2 * (PLAYER_SHIELD_MAX - 1)] = {
    gPlayAsLUT_Adult_Shield1FistR,
    gPlayAsLUT_Adult_Shield1FistR,
    gPlayAsLUT_Adult_Shield2FistR,
    gPlayAsLUT_Adult_Shield2FistR,
    gPlayAsLUT_Adult_Shield3FistR,
    gPlayAsLUT_Adult_Shield3FistR,
};

Gfx gLinkHumanSheathEmptyDL[] = {
    gsSPEndDisplayList(),
};

Gfx* gPlayerSwordSheathsBlank[] = {
    gLinkHumanSheathEmptyDL, gLinkHumanSheathEmptyDL, 
};

Asm_VanillaHook(Player_OverrideLimbDrawGameplayDefault);
s32 Player_OverrideLimbDrawGameplayDefault(PlayState* play, s32 limbIndex, Gfx** dList, Vec3f* pos, Vec3s* rot,
                                           void* thisx) {
    Player* this = (Player*)thisx;
	

    if (!Player_OverrideLimbDrawGameplayCommon(play, limbIndex, dList, pos, rot, thisx)) {
        if (limbIndex == PLAYER_LIMB_L_HAND) {
            Gfx** dLists = this->leftHandDLists;
			EquipValueSword swordEquipValue = CUR_EQUIP_VALUE(EQUIP_TYPE_SWORD);
			
			//Play_EnableMotionBlur(180);
			
			//void CutsceneCmd_MotionBlur2(PlayState* play, CutsceneContext* csCtx, CsCmdMotionBlur* cmd) {
				//if (R_MOTION_BLUR_ALPHA == false) {
					//Play_EnableMotionBlur(180);
				//}
			//}
			
			// MM Texture Animation System (Used on blades in the blacksmith)
			
			F3DPrimColor object_kgyTexColorChangingPrimColors_00F670[] = {
				{ 255, 0, 0, 0, 128 },
				{ 128, 0, 0, 255, 128 },
				{ 255, 0, 0, 0, 128 },
			};

			u16 object_kgyTexColorChangingFrameData_00F680[] = {
				0, 14, 29,
			};

			AnimatedMatColorParams object_kgy_Matanimheader_00F6A0ColorParams_00F688 = { 
				30, 3, object_kgyTexColorChangingPrimColors_00F670, NULL, object_kgyTexColorChangingFrameData_00F680,
			};

			AnimatedMatTexScrollParams object_kgy_Matanimheader_00F6A0TexScrollParams_00F698[] = {
				{ 1, 0, 0x10, 0x10 },
				{ 0, 0, 0x10, 0x10 },
			};

			AnimatedMaterial object_kgy_Matanimheader_00F6A0[] = {
				{ 1, 3, &object_kgy_Matanimheader_00F6A0ColorParams_00F688 },
				{ -2, 1, object_kgy_Matanimheader_00F6A0TexScrollParams_00F698 },
			};
			
			AnimatedMat_Draw(play, Lib_SegmentedToVirtual(object_kgy_Matanimheader_00F6A0));
			
            if (this->stateFlags3 & PLAYER_STATE3_2000) {
                //rot->z -= this->unk_B8C;
            } else if ((sLeftHandType == PLAYER_MODELTYPE_LH_BOOMERANG) &&
                       (this->stateFlags1 & PLAYER_STATE1_25)) {
                dLists = &gPlayerLeftHandOpenDLs[D_801F59E0] + gSaveContext.linkAge;
                sLeftHandType = PLAYER_MODELTYPE_LH_OPEN;
            } else if ((this->leftHandType == PLAYER_MODELTYPE_LH_OPEN) && (this->actor.speedXZ > 2.0f) &&
                       !(this->stateFlags1 & PLAYER_STATE1_27)) {
                dLists = &gPlayerLeftHandClosedDLs[D_801F59E0] + gSaveContext.linkAge;
                sLeftHandType = PLAYER_MODELTYPE_LH_CLOSED;
            } else if ((this->leftHandType == PLAYER_MODELTYPE_LH_SWORD_2) || ((this->leftHandType == PLAYER_MODELTYPE_LH_SWORD)) || ((this->leftHandType == PLAYER_MODELTYPE_LH_BGS)) &&
                       ((swordEquipValue = CUR_EQUIP_VALUE(EQUIP_TYPE_SWORD),
                         swordEquipValue != EQUIP_VALUE_SWORD_NONE))) {
							if (!LINK_IS_ADULT) {
								dLists = &gPlayerSwordMM[2 * ((swordEquipValue - 1) ^ 0)];
							} else {
								dLists = &gPlayerSwordMMAdult[2 * ((swordEquipValue - 1) ^ 0)];
						}
            } else {
                s32 handIndex = GET_LEFT_HAND_INDEX_FROM_JOINT_TABLE(this->skelAnime.jointTable);

                if (handIndex != 0) {
                    handIndex = (handIndex >> 12) - 1;
                    if (handIndex >= 2) {
                        handIndex = 0;
                    }
                    dLists = &D_801C095C[handIndex][D_801F59E0];
                }
            }

            *dList = *(dLists + sDListsLodOffset);
        } else if (limbIndex == PLAYER_LIMB_R_HAND) {
            Gfx** dLists = this->rightHandDLists;

            if (sRightHandType == PLAYER_MODELTYPE_RH_SHIELD) {
                    if (this->currentShield != PLAYER_SHIELD_NONE) {
						if (!LINK_IS_ADULT) {
                        dLists = &gPlayerHandHoldingShields[2 * ((this->currentShield - 1) ^ 0)];
						} else {
						dLists = &gPlayerHandHoldingShieldsAdult[2 * ((this->currentShield - 1) ^ 0)];
                    }
				}
            } else if ((this->rightHandType == PLAYER_MODELTYPE_RH_OPEN) && (this->actor.speedXZ > 2.0f) &&
                       !(this->stateFlags1 & PLAYER_STATE1_27)) {
                dLists = sPlayerRightHandClosedDLs + gSaveContext.linkAge;
                sRightHandType = PLAYER_MODELTYPE_RH_CLOSED;
            }

            *dList = *(dLists + sDListsLodOffset);
        } else if (limbIndex == PLAYER_LIMB_SHEATH) {
            Gfx** dLists = this->sheathDLists;
        if (limbIndex == PLAYER_LIMB_SHEATH) {
			EquipValueSword swordEquipValue = CUR_EQUIP_VALUE(EQUIP_TYPE_SWORD);
		
            if (!LINK_IS_ADULT) {
                if (swordEquipValue != EQUIP_VALUE_SWORD_NONE) {
                    if ((this->sheathType == PLAYER_MODELTYPE_SHEATH_16) || (this->sheathType == PLAYER_MODELTYPE_SHEATH_18)) {
                        dLists = &gPlayerSheathedSwordsChild[2 * ((swordEquipValue - 1) ^ 0)];
                    } else {
                        dLists = &gPlayerSwordSheathsChild[2 * ((swordEquipValue - 1) ^ 0)];
					}
				} else {
					dLists = &gPlayerSwordSheathsBlank;
                }
            }
			else if (LINK_IS_ADULT) {
                if (swordEquipValue != EQUIP_VALUE_SWORD_NONE) {
                    if ((this->sheathType == PLAYER_MODELTYPE_SHEATH_16 || this->sheathType == PLAYER_MODELTYPE_SHEATH_18)) {
                        dLists = &gPlayerSheathedSwordsAdult[2 * ((swordEquipValue - 1) ^ 0)];
                    } else {
                        dLists = &gPlayerSwordSheathsAdult[2 * ((swordEquipValue - 1) ^ 0)];
                    }
				} else {
					dLists = &gPlayerSwordSheathsBlank;
                }
            }

			/*if (GET_EVENTCHKINF(EVENTCHKINF_70) == true && !LINK_IS_ADULT) {
				if (this->sheathType == PLAYER_MODELTYPE_SHEATH_16 || this->sheathType == PLAYER_MODELTYPE_SHEATH_18) {
					dLists = &gPlayerSheathedSwordsChildFlag[2 * ((swordEquipValue - 1) ^ 0) + gSaveContext.linkAge]; 
				} else {
					dLists = &gPlayerSwordSheathsChildFlag[2 * ((swordEquipValue - 1) ^ 0) + gSaveContext.linkAge];
				}
			}*/

            *dList = *(dLists);
        } else if (limbIndex == PLAYER_LIMB_WAIST) {
            *dList = *(this->waistDLists + sDListsLodOffset);
        }
    }
    return false;
	}
}