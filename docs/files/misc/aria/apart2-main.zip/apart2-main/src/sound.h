#ifndef SOUND_H
#define SOUND_H

#include <libdragon.h>
#include "../include/enums.h"
extern char *xm_fn;
extern xm64player_t xm;
extern wav64_t sfx_jump, sfx_attack, sfx_bounce, sfx_boing;

void sound_load(void);
void sound_init(void);
void xm_init(void);
void switch_xm(int songID);
void sound_update_buffer(void);
void sound_bounce(void);
void sound_clank(void);
void sound_air(void);
void sound_jump(void);
void sound_attack(void);
void sound_handgun(void);
void title_theme(void);
void sound_door(void);
void sound_squirt(void);
void sound_foot(void);
#endif // SOUND_H
