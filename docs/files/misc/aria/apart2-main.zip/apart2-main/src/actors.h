#ifndef ACTORS_H
#define ACTORS_H


#include <libdragon.h>
#include <t3d/t3d.h>
#include "../include/config.h"
#include "../include/enums.h"
#include "../include/types.h"
#include "collision.h"
#include "debug.h"
#include "levels.h"
#include "map.h"
#include "octree_test.h"
#include "player.h"
#include "sound.h"
#include "utils.h"

// Crates
extern T3DMat4FP* crateMatFP[MAX_CRATES];
extern rspq_block_t *dplCrate[MAX_CRATES];
extern T3DModel *modelCrate;
extern Actor *crates[MAX_CRATES];
extern int numCrates;

extern OctreeNode *boxOctree;

extern float dist;
extern float minDist;

extern sprite_t* sprites[2];

void resolve_actor_to_actor_col(Actor *origin, int originCount, Actor **target, int targetCount);
void crates_init(void);
void actors_init(void);
void crates_update(void);
void actors_update(void);


#endif // ACTORS_H