#include "uLib.h"
#include "z64player.h"
#include <z64hdr.h>
#include <playas/playas.h>
#include "code/z_player_lib.h"
#include "assets/objects/object_link_boy/object_link_boy.h"
#include "assets/objects/object_link_child/object_link_child.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

void DrawGauntletDList(PlayState* play, Player* this, s32 limbIndex) {

    Gfx* hackAdultGauntletsDLists[] = {
        gPlayAsDl_Adult_BraceletAdult, 			// PLAYER_LIMB_L_HAND
        gPlayAsDl_Adult_GauntletForearmL,	// PLAYER_LIMB_L_FOREARM
        gPlayAsDl_Adult_GauntletForearmR,	// PLAYER_LIMB_R_FOREARM
        gPlayAsDl_Adult_GauntletHandL,		// PLAYER_LIMB_L_HAND
        gPlayAsDl_Adult_GauntletHandR,		// PLAYER_LIMB_R_HAND
        gPlayAsDl_Adult_GauntletFistL,		// PLAYER_LIMB_L_HAND
        gPlayAsDl_Adult_GauntletFistR,		// PLAYER_LIMB_R_HAND
    };

    Gfx* hackChildGauntletsDLists[] = {
        gPlayAsDl_Child_GoronBracelet, 			// PLAYER_LIMB_L_HAND
        gPlayAsDl_Child_GauntletForearmL, 	// PLAYER_LIMB_L_FOREARM
        gPlayAsDl_Child_GauntletForearmR,	// PLAYER_LIMB_R_FOREARM
        gPlayAsDl_Child_GauntletHandL,		// PLAYER_LIMB_L_HAND
        gPlayAsDl_Child_GauntletHandR,		// PLAYER_LIMB_R_HAND
        gPlayAsDl_Child_GauntletFistL,		// PLAYER_LIMB_L_HAND
        gPlayAsDl_Child_GauntletFistR,		// PLAYER_LIMB_R_HAND
    };

    Gfx** gauntletDListsToUse = LINK_IS_ADULT ? hackAdultGauntletsDLists : hackChildGauntletsDLists;
	s32 strengthUpgrade = CUR_UPG_VALUE(UPG_STRENGTH);
	Color_RGB8* tuniccolor = &sTunicColors[this->currentTunic];

	if (strengthUpgrade > 0 && ((limbIndex == PLAYER_LIMB_L_HAND) || (limbIndex == PLAYER_LIMB_R_HAND) || 
         (limbIndex == PLAYER_LIMB_L_FOREARM)|| (limbIndex == PLAYER_LIMB_R_FOREARM))) {

		OPEN_DISPS(play->state.gfxCtx, __FILE__, __LINE__);

		Color_RGB8* color = &sGauntletColors[strengthUpgrade - 2];
		gDPSetEnvColor(POLY_OPA_DISP++, color->r, color->g, color->b, 0);

		if (limbIndex == PLAYER_LIMB_L_HAND && strengthUpgrade != 1){
			gSPDisplayList(POLY_OPA_DISP++, (sLeftHandType == PLAYER_MODELTYPE_LH_OPEN)
		                                        ? gauntletDListsToUse[3]
		                                        : gauntletDListsToUse[5]);
		}

		if (limbIndex == PLAYER_LIMB_R_HAND && strengthUpgrade != 1){
			gSPDisplayList(POLY_OPA_DISP++, (sRightHandType == PLAYER_MODELTYPE_RH_OPEN)
			                                        ? gauntletDListsToUse[4]
			                                        : gauntletDListsToUse[6]);
		}

	    if (limbIndex == PLAYER_LIMB_L_FOREARM){
		
		// Goron Bracelet
			if (strengthUpgrade == 1){
				gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(play->state.gfxCtx, __FILE__, __LINE__),
	        		G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
				gSPDisplayList(POLY_OPA_DISP++, gauntletDListsToUse[0]);
			}else{
				gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(play->state.gfxCtx, __FILE__, __LINE__),
	        		G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
				gSPDisplayList(POLY_OPA_DISP++, gauntletDListsToUse[1]);
			}
		}

		// Gauntlet Forearms
		if (limbIndex == PLAYER_LIMB_R_FOREARM && strengthUpgrade != 1){
			gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(play->state.gfxCtx, __FILE__, __LINE__),
	        	G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
			gSPDisplayList(POLY_OPA_DISP++, gauntletDListsToUse[2]);
		}

		gDPSetEnvColor(POLY_OPA_DISP++, tuniccolor->r, tuniccolor->g, tuniccolor->b, 0);
		CLOSE_DISPS(play->state.gfxCtx, __FILE__, __LINE__);
	}	
}