#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3danim.h>
#include <t3d/t3dskeleton.h>
#include "../include/config.h"
#include "../include/enums.h"
#include "../include/globals.h"
#include "../include/types.h"
#include "actors.h"
#include "camera.h"
#include "collision.h"
#include "debug.h"
#include "input.h"
#include "levels.h"
#include "map.h"
#include "octree_test.h"
#include "player.h"
#include "sound.h"
#include "utils.h"
#include "test_level.h"


T3DMat4FP* playerMatFP[MAX_PLAYERS];
T3DMat4FP* shadowMatFP[MAX_PLAYERS];
T3DMat4FP* playerhitboxMatFP[MAX_PLAYERS];
T3DMat4FP* projectilehitboxMatFP[MAX_PLAYERS];
T3DModel *modelPlayer;
T3DModel *modelProjectile;
T3DModel *modelShadow;
T3DModel *modelAriaHead;
T3DModel *modelAriaHeadSpecial;
T3DModel *modelAriaSpecial;
T3DModel *modelAriaHair;
T3DModel *modelAriaHairShort;
T3DModel *modelAriaBody;
T3DModel *modelAriaPubic;
T3DModel *modelAriaSweatpants;
T3DModel *modelAriaCasual;
T3DModel *modelAriaClothes;
T3DModel *modelAriaArmor;
T3DModel *modelDragona;
T3DModel *modelDragonaTrue;
T3DModel *modelBaretta;
T3DModel *modelRemington;
T3DSkeleton playerSkel[MAX_PLAYERS];
T3DSkeleton playerSkelBlend[MAX_PLAYERS];
T3DSkeleton playerSkelRun[MAX_PLAYERS];
T3DAnim animIdle[MAX_PLAYERS];
T3DAnim animWalk[MAX_PLAYERS];
T3DAnim animRun[MAX_PLAYERS];
T3DAnim animJump[MAX_PLAYERS];
T3DAnim animPunch[MAX_PLAYERS];
T3DAnim animAttack[MAX_PLAYERS];
T3DAnim animFire[MAX_PLAYERS];
T3DAnim animFireBig[MAX_PLAYERS];
T3DAnim animFall[MAX_PLAYERS];
T3DAnim animRoll[MAX_PLAYERS];
rspq_block_t *dplProjectile[MAX_PLAYERS];
rspq_block_t *dplPlayer[MAX_PLAYERS];
rspq_block_t *dplPlayerHitBox[MAX_PLAYERS];
rspq_block_t *dplProjectileHitBox[MAX_PLAYERS];
rspq_block_t *dplPlayerBody[MAX_PLAYERS];
rspq_block_t *dplPlayerPubic[MAX_PLAYERS];
rspq_block_t *dplPlayerPubicSpecial[MAX_PLAYERS];
rspq_block_t *dplPlayerClothes[MAX_PLAYERS];
rspq_block_t *dplPlayerArmor[MAX_PLAYERS];
rspq_block_t *dplPlayerSweatpants[MAX_PLAYERS];
rspq_block_t *dplPlayerCasual[MAX_PLAYERS];
rspq_block_t *dplPlayerHead[MAX_PLAYERS];
rspq_block_t *dplPlayerHeadSpecial[MAX_PLAYERS];
rspq_block_t *dplPlayerSpecial[MAX_PLAYERS];
rspq_block_t *dplPlayerHairShort[MAX_PLAYERS];
rspq_block_t *dplPlayerHair[MAX_PLAYERS];
rspq_block_t *dplPlayerHairSpecial[MAX_PLAYERS];
rspq_block_t *dplSword[MAX_PLAYERS];
rspq_block_t *dplDragona[MAX_PLAYERS];
rspq_block_t *dplBaretta[MAX_PLAYERS];
rspq_block_t *dplRemington[MAX_PLAYERS];
rspq_block_t *dplShadow[MAX_PLAYERS];
PlayerParams *player[MAX_PLAYERS];
int playerState[MAX_PLAYERS];
T3DVec3 playerStartPos = {{0,50,0}};
int airAttackCount = 0;
actioniconid actionicon[MAX_PLAYERS];
Surface lastSurface;
Surface lastFloor;
Surface lastSlope;
float newScale = 0.03f;
int weaponMax = 4, costumeMax = 4, headMax = 3;


// Check for PvP interaction, delcared first because used in init function
void check_player_collisions(PlayerParams *players[], int numPlayers) {
  for (int i = 0; i < numPlayers; i++) {
    for (int j = i + 1; j < numPlayers; j++) {
      if (check_sphere_collision(player[i]->projectile.hitbox, player[j]->hitbox)) {
        if(!player[j]->isSpecial && playerState[i] == PLAYER_ATTACK){
            // counts as near miss and your hair gets cut
            if(playerState[j] == PLAYER_ROLL){
                player[j]->headIndex = 2;
            } else {
                player[i]->score += 10;
                player[j]->health -= 10;
                sound_squirt();
            }
        }
        resolve_sphere_collision_offset(player[i]->projectile.hitbox, &player[j]->pos, 0.1f);
        resolve_sphere_collision_offset(player[j]->hitbox, &player[i]->projectile.pos, 0.1f);
        player[j]->pos.v[0] += player[i]->forward.v[0] * 5;
        player[j]->pos.v[2] += player[i]->forward.v[2] * 5;
      }
      if (check_sphere_collision(player[i]->hitbox, player[j]->hitbox)) {
        resolve_sphere_collision_offset(player[i]->hitbox, &player[j]->pos,1.0f);
        resolve_sphere_collision_offset(player[j]->hitbox, &player[i]->pos,1.0f);
        // Adjust both players' positions based on their current speed and direction
        players[j]->pos.v[0] += players[i]->forward.v[0] * players[i]->currSpeed;
        players[j]->pos.v[2] += players[i]->forward.v[2] * players[i]->currSpeed;
        players[i]->pos.v[0] += players[j]->forward.v[0];
        players[i]->pos.v[2] += players[j]->forward.v[2];
      }
    }
  }
}


void player_init(void){

  // Load T3D Models
  modelPlayer = t3d_model_load("rom:/models/player.t3dm");
  modelShadow = t3d_model_load("rom:/models/shadow.t3dm");
  modelAriaHead = t3d_model_load("rom:/models/ariahead.t3dm");
  modelAriaHeadSpecial = t3d_model_load("rom:/models/ariaheadspecial.t3dm");
  modelAriaSpecial = t3d_model_load("rom:/models/ariaspecial.t3dm");
  modelAriaHairShort = t3d_model_load("rom:/models/ariahairshort.t3dm");
  modelAriaHair = t3d_model_load("rom:/models/ariahair.t3dm");
  modelAriaBody = t3d_model_load("rom:/models/ariabody.t3dm");
  modelAriaPubic = t3d_model_load("rom:/models/ariapubic.t3dm");
  modelAriaCasual = t3d_model_load("rom:/models/ariacasual.t3dm");
  modelAriaSweatpants = t3d_model_load("rom:/models/ariasweatpants.t3dm");
  modelAriaClothes = t3d_model_load("rom:/models/ariaclothes.t3dm");
  modelAriaArmor = t3d_model_load("rom:/models/ariaarmor.t3dm");
  modelDragona = t3d_model_load("rom:/models/dragona.t3dm");
  modelDragonaTrue = t3d_model_load("rom:/models/dragonatrue.t3dm");
  modelBaretta = t3d_model_load("rom:/models/baretta.t3dm");
  modelRemington = t3d_model_load("rom:/models/remington.t3dm");

  for (int i = 0; i < numPlayers; ++i) {

    // Init player params
    player[i] = malloc(sizeof(PlayerParams));
    player[i]->moveDir = (T3DVec3){{0,0,0}};
    player[i]->rot = (T3DVec3){{0,0,0}};
    player[i]->scale = (T3DVec3){{newScale,newScale,newScale}};
    player[i]->pos = playerStartPos;
    player[i]->shadowPos = player[i]->pos;
    player[i]->shadowRot = player[i]->rot;
    player[i]->forward = (T3DVec3){{0,0,1}};
    player[i]->hitbox = (Sphere){player[i]->pos, 16.0f};
    player[i]->projectile.pos = player[i]->hitbox.center;
    player[i]->projectile.dir = player[i]->forward;
    player[i]->projectile.hitbox = (Sphere){player[i]->hitbox.center, 6.0f};
    player[i]->projectile.speed = 0.0f;
    player[i]->projectile.isActive = false;
    player[i]->projectile.length = 16.0f;
    player[i]->currSpeed = 0.0f;
    player[i]->animBlend = 0.0f;
    player[i]->isGrounded = false;
    player[i]->weaponIndex = 1;
    player[i]->costumeIndex = 2;
    player[i]->headIndex = 1;
    player[i]->isTrimmed = false;
    player[i]->isNude = false;
    player[i]->isSpecial = false;
    player[i]->isSword = true;
    player[i]->gunCooldown = 0;
    player[i]->vel = (T3DVec3){{0,0,0}};
    player[i]->haircolor = RED;
    player[i]->health = 200;
    player[i]->playernumb = -1;
    player[i]->ztarget = false;

    actionicon[i] = none;

    // Allocate player matrices
    playerMatFP[i] = malloc_uncached(sizeof(T3DMat4FP));
    shadowMatFP[i] = malloc_uncached(sizeof(T3DMat4FP));
    playerhitboxMatFP[i] = malloc_uncached(sizeof(T3DMat4FP));
    projectilehitboxMatFP[i] = malloc_uncached(sizeof(T3DMat4FP));

    // Create skeleton and anims for each player
    playerSkel[i] = t3d_skeleton_create(modelAriaBody);
    playerSkelBlend[i] = t3d_skeleton_clone(&playerSkel[i], false);
    playerSkelRun[i] = t3d_skeleton_clone(&playerSkel[i], false);

    animIdle[i] = t3d_anim_create(modelAriaBody, "Idle");
    t3d_anim_attach(&animIdle[i], &playerSkel[i]);

    animWalk[i] = t3d_anim_create(modelAriaBody, "Walk");
    t3d_anim_attach(&animWalk[i], &playerSkelBlend[i]);

    animRun[i] = t3d_anim_create(modelAriaBody, "Run");
    t3d_anim_attach(&animRun[i], &playerSkelRun[i]);

    animJump[i] = t3d_anim_create(modelAriaBody, "Jump");
    t3d_anim_set_speed(&animJump[i], 1.0f);
    t3d_anim_set_looping(&animJump[i], false);
    t3d_anim_set_playing(&animJump[i], false);
    t3d_anim_attach(&animJump[i], &playerSkel[i]);

    animFire[i] = t3d_anim_create(modelAriaBody, "Fire");
    t3d_anim_set_speed(&animFire[i], 1.5);
    t3d_anim_set_looping(&animFire[i], false);
    t3d_anim_set_playing(&animFire[i], false);
    t3d_anim_attach(&animFire[i], &playerSkel[i]);

    animFireBig[i] = t3d_anim_create(modelAriaBody, "FireBig");
    t3d_anim_set_speed(&animFireBig[i], 1.5f);
    t3d_anim_set_looping(&animFireBig[i], false);
    t3d_anim_set_playing(&animFireBig[i], false);
    t3d_anim_attach(&animFireBig[i], &playerSkel[i]);

    animPunch[i] = t3d_anim_create(modelAriaBody, "AttackKick");
    t3d_anim_set_speed(&animPunch[i], 1.2f);
    t3d_anim_set_looping(&animPunch[i], false);
    t3d_anim_set_playing(&animPunch[i], false);
    t3d_anim_attach(&animPunch[i], &playerSkel[i]);

    animAttack[i] = t3d_anim_create(modelAriaBody, "AttackVertical");
    t3d_anim_set_speed(&animAttack[i], 1.5f);
    t3d_anim_set_looping(&animAttack[i], false);
    t3d_anim_set_playing(&animAttack[i], false);
    t3d_anim_attach(&animAttack[i], &playerSkel[i]);

    animFall[i] = t3d_anim_create(modelAriaBody, "Fall");
    t3d_anim_set_speed(&animFall[i], 1.0f);
    t3d_anim_set_looping(&animFall[i], true);
    t3d_anim_set_playing(&animFall[i], false);
    t3d_anim_attach(&animFall[i], &playerSkel[i]);

    animRoll[i] = t3d_anim_create(modelAriaBody, "Roll");
    t3d_anim_set_looping(&animRoll[i], false);
    t3d_anim_set_playing(&animRoll[i], false);
    t3d_anim_attach(&animRoll[i], &playerSkelBlend[i]);

    int hack2p = 0;
    if (numPlayers == 2){
      hack2p = 1;
    }

    // Create player's RSPQ blocks
    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelPlayer, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayer[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaBody, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerBody[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaSweatpants, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerSweatpants[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(WHITE);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaCasual, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerCasual[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaClothes, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerClothes[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaArmor, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerArmor[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaHead, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerHead[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaHeadSpecial, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerHeadSpecial[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaSpecial, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerSpecial[i] = rspq_block_end();

    //Body Hair

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(RED);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaHair, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerHair[i] = rspq_block_end();

      rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(RED);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaHairShort, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerHairShort[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(RED);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaPubic, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerPubic[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(WHITE);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaHair, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerHairSpecial[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      rdpq_set_prim_color(WHITE);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelAriaPubic, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplPlayerPubicSpecial[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelDragona, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplSword[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelDragonaTrue, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplDragona[i] = rspq_block_end();

    rspq_block_begin();
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelBaretta, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplBaretta[i] = rspq_block_end();

    rspq_block_begin();
      if(hack2p){
        rdpq_mode_begin();
          t3d_frame_start(); // When 2 players, and ONLY 2 players, the second player is rendered inside out
        rdpq_mode_end();
      }
      t3d_matrix_push_pos(1);
      t3d_matrix_set(playerMatFP[i], true);
      t3d_model_draw_skinned(modelRemington, &playerSkel[i]);
      t3d_matrix_pop(1);
    dplRemington[i] = rspq_block_end();

    rspq_block_begin();
      rdpq_mode_begin();
        rdpq_set_mode_standard();
        rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);
      rdpq_mode_end();
      t3d_matrix_push_pos(1);
      matCount++;
      t3d_matrix_set(playerhitboxMatFP[i], true);
      rdpq_set_prim_color(T_RED);
      t3d_matrix_set(playerhitboxMatFP[i], true);
      t3d_model_draw(modelDebugSphere);
      t3d_matrix_pop(1);
    dplPlayerHitBox[i] = rspq_block_end();

    rspq_block_begin();
      rdpq_mode_begin();
        rdpq_set_mode_standard();
        rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);
      rdpq_mode_end();
      t3d_matrix_push_pos(1);
      matCount++;
      t3d_matrix_set(projectilehitboxMatFP[i], true);
      rdpq_set_prim_color(T_BLUE);
      t3d_matrix_set(projectilehitboxMatFP[i], true);
      t3d_model_draw(modelDebugSphere);
      t3d_matrix_pop(1);
    dplProjectileHitBox[i] = rspq_block_end();

    rspq_block_begin();
      rdpq_mode_begin();
        rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);
      rdpq_mode_end();
      t3d_matrix_push_pos(1);
      matCount++;
      t3d_matrix_set(shadowMatFP[i], true);
      rdpq_set_prim_color(TRANSPARENT);
      t3d_matrix_set(shadowMatFP[i], true);
      t3d_model_draw(modelShadow);
      t3d_matrix_pop(1);
    dplShadow[i] = rspq_block_end();

    if(numPlayers > 2){
      player[i]->jumpForce = 300.0f;
    } else {
      player[i]->jumpForce = 250.0f;
    }

    player[i]->score = 0;

  }

  // If more than 1 player, place the players randomly and check for collisions
  if(numPlayers > 1){
    for (int p = 0; p < numPlayers; ++p){
      player[p]->pos = (T3DVec3){{random_float(-320.0f, 320.0f),groundLevel,random_float(-320.0f, 320.0f)}};
      player[p]->hitbox.center = player[p]->pos;
      check_player_collisions(player, numPlayers);

      if (check_sphere_box_collision(player[p]->hitbox, FloorBox)) {
        player[p]->pos = playerStartPos;
        if(!rumbleLong[p] && !rumbleShort[p] && !rumbleWave[p]){
          rumbleShort[p] = true;
        }
      }
    }
  }
}

void check_warp(Warp warp, int playerCount) {
    bool collided = false;

    // Check collision based on warp shape type
    if (warp.hitbox.shape.type == SHAPE_BOX) {
        collided = check_sphere_box_collision(player[playerCount]->hitbox, warp.hitbox.shape.aabb);
    } else if (warp.hitbox.shape.type == SHAPE_SPHERE) {
        collided = check_sphere_collision(player[playerCount]->hitbox, warp.hitbox.shape.sphere);
    }

    // If a collision occurs, handle the warp transition
    if (collided) {
        actionicon[playerCount] = open;
        if (btn[playerCount].a || !warp.door) {
            sound_door();
            prevLevel = currLevel;               // Store the current level
            currLevel = warp.exit;               // Set current level to warp exit level
            level_free(&levels[prevLevel]);      // Free the previous level
            level_load(currLevel);               // Load the new level
            player[0]->pos = warp.spawnpos; // Update player position
            if(numPlayers > 1)player[1]->pos = player[0]->pos; // Update player position
            if(numPlayers > 2)player[2]->pos = player[0]->pos; // Update player position
            if(numPlayers > 3)player[3]->pos = player[0]->pos; // Update player position
        }
    }
}

// General actor interaction
void check_actor_collisions(Actor **actor, int actorCount, int playerCount) {

  // Set the closet actor to current actor
  Actor *currActor;
  int closestActor = find_closest(player[playerCount]->pos, actor, actorCount);

  if (closestActor != -1){
    currActor = actor[closestActor];

    // Handles if actor has a AABB hitbox
    if(currActor->hitbox.shape.type == SHAPE_BOX){
      if (check_sphere_box_collision(player[playerCount]->hitbox, currActor->hitbox.shape.aabb)) {

        // If the actor is movable ie. bouncy, player pushes actor
        if(currActor->IsBouncy){
          resolve_sphere_collision_offset(player[playerCount]->hitbox, &currActor->pos, 2.0f);
          currActor->pos.v[0] += player[playerCount]->forward.v[0] * player[playerCount]->currSpeed;
          currActor->pos.v[2] += player[playerCount]->forward.v[2] * player[playerCount]->currSpeed;
        }

        // Move model and hitbox separately to blend later
        resolve_box_collision_offset_xz(currActor->hitbox.shape.aabb, &player[playerCount]->hitbox.center, player[playerCount]->hitbox.radius);
        resolve_box_collision_offset_xz(currActor->hitbox.shape.aabb, &player[playerCount]->pos, 0.2f);
        t3d_lerp(player[playerCount]->pos.v[0], player[playerCount]->hitbox.center.v[0], 0.2f);
        t3d_lerp(player[playerCount]->pos.v[2], player[playerCount]->hitbox.center.v[2], 0.2f);
      }
    }

    // Handles if actor has a Sphere hitbox
    if(currActor->hitbox.shape.type == SHAPE_SPHERE){
      if (check_sphere_collision(player[playerCount]->hitbox, currActor->hitbox.shape.sphere)) {

        // If the actor is movable ie. bouncy, player pushes actor
        if(currActor->IsBouncy){
          resolve_sphere_collision_offset(player[playerCount]->hitbox, &currActor->hitbox.shape.sphere.center, 1.4f);
        }

        // Actor pushes player
        resolve_sphere_collision_xz(currActor->hitbox.shape.sphere, &player[playerCount]->pos);


      }
    }

    // More to be added

  }
}

// General attack interaction
void check_attack_collisions(Actor **actor, int actorCount, int playerCount) {

  // Set the closet actor to current actor
  Actor *currActor;
  int closestActor = find_closest(player[playerCount]->projectile.hitbox.center, actor , actorCount);

  if (closestActor != -1){
    currActor = actor[closestActor];

    // Handles if actor has a AABB hitbox
    if(currActor->hitbox.shape.type == SHAPE_BOX){
      if (check_sphere_box_collision(player[playerCount]->projectile.hitbox, currActor->hitbox.shape.aabb)) {

        // If the actor is movable ie. bouncy, player pushes actor
        if(currActor->IsBouncy){
          resolve_sphere_collision_offset_xz(player[playerCount]->projectile.hitbox, &currActor->pos, 2.0f);
          currActor->pos.v[0] += player[playerCount]->forward.v[0] * 2;
          currActor->pos.v[2] += player[playerCount]->forward.v[2] * 2;
        }

        resolve_box_collision_offset_xz(currActor->hitbox.shape.aabb, &player[playerCount]->projectile.pos, 0.02f);
        sound_clank();
        player[playerCount]->score += (player[playerCount]->weaponIndex + 1) * 2;

      }
    }

    // Handles if actor has a Sphere hitbox
    if(currActor->hitbox.shape.type == SHAPE_SPHERE){
      if (check_sphere_collision(player[playerCount]->hitbox, currActor->hitbox.shape.sphere)) {

        // If the actor is movable ie. bouncy, projectile pushes actor
        if(currActor->IsBouncy){
          resolve_sphere_collision_offset(player[playerCount]->projectile.hitbox, &currActor->hitbox.shape.sphere.center, 2.0f);
        }

        // Actor pushes projectile
        resolve_sphere_collision(currActor->hitbox.shape.sphere, &player[playerCount]->projectile.pos);

        player[playerCount]->score += (player[playerCount]->weaponIndex + 1) * 2;

      }
    }

    // More to be added

  }
}


// Example interaction: bounce player, not working in multiplayer??
void player_bounced(PlayerParams *player[], int playerCount) {
  float bounceMultiplier = 1.5f;

  playerState[playerCount] = PLAYER_JUMP_START;

  if(!rumbleLong[playerCount] && !rumbleShort[playerCount] && !rumbleWave[playerCount]){
    rumbleLong[playerCount] = true;
  }

  player[playerCount]->vel.v[1] += (player[playerCount]->jumpForce * bounceMultiplier) + GRAVITY * jumpFixedTime;

  player[playerCount]->pos.v[1] += player[playerCount]->vel.v[1] * jumpFixedTime;

  player[playerCount]->hitbox.center.v[1] = player[playerCount]->pos.v[1];

  player[playerCount]->projectile.pos.v[1] = player[playerCount]->hitbox.center.v[1];
}


// General airbourne actor interaction
void check_midair_actor_collisions(Actor **actor, int actorCount, int playerCount) {

  // Set the closet actor to current actor
  Actor *currActor;
  int closestActor = find_closest(player[playerCount]->pos, actor , actorCount);

  if (closestActor != -1){
    currActor = actor[closestActor];

    // Handles if actor has a AABB hitbox
    if(currActor->hitbox.shape.type == SHAPE_BOX){
      if (check_sphere_box_collision(player[playerCount]->hitbox, currActor->hitbox.shape.aabb)) {

        // Move model and hitbox separately to blend later
        resolve_box_collision_offset(currActor->hitbox.shape.aabb, &player[playerCount]->hitbox.center, player[playerCount]->hitbox.radius);
        resolve_box_collision_offset(currActor->hitbox.shape.aabb, &player[playerCount]->pos, 0.01f);

        // Check if the player is above or within bounds in the x and z directions
        if (player[playerCount]->hitbox.center.v[0] <= currActor->hitbox.shape.aabb.max.v[0] &&
            player[playerCount]->hitbox.center.v[0] >= currActor->hitbox.shape.aabb.min.v[0] &&
            player[playerCount]->hitbox.center.v[2] <= currActor->hitbox.shape.aabb.max.v[2] &&
            player[playerCount]->hitbox.center.v[2] >= currActor->hitbox.shape.aabb.min.v[2]) {

          // Check if the player is above the top surface
          if (player[playerCount]->hitbox.center.v[1] >= currActor->hitbox.shape.aabb.max.v[1]) {

            // Check if not playing an override animations
            if(!animJump[playerCount].isPlaying && !animPunch[playerCount].isPlaying && !animAttack[playerCount].isPlaying && !animFire[playerCount].isPlaying && !animFireBig[playerCount].isPlaying){

              // Check if the actor is marked as safe...
              if(currActor->isSafe){

                //... if so landed
                playerState[playerCount] = PLAYER_LAND;

              } else {

                //... if not do something  ie. bounce the player
                player_bounced(player, playerCount);

                // Always push the mixer ASAP or there is a delay in the sound
                sound_bounce();
              }
            } else {
              // Resolve collision if not at the right height
              resolve_box_collision_offset(currActor->hitbox.shape.aabb, &player[playerCount]->pos, 0.1f);
            }

          } else {
            // Resolve collision if not at the right height
            resolve_box_collision_offset(currActor->hitbox.shape.aabb, &player[playerCount]->pos, 0.1f);
          }
        } else {
          // Resolve collision if not within bounds
          resolve_box_collision_offset(currActor->hitbox.shape.aabb, &player[playerCount]->pos, 0.1f);
        }
      }
    }

    // More to come
  }

}


void player_to_quad(int playerCount){
// quad collisions?
  T3DQuad currQuad = get_closest_quad(player[playerCount]->pos, modelMesh, 1);
  T3DVec3 currQuadNorm = get_quad_normal(currQuad);
  T3DVec3 currQuadCenter = compute_quad_center(currQuad);
  if (check_sphere_quad_collision(player[playerCount]->hitbox, currQuad)){
    //player[i]->vel = reflect_velocity(player[i]->vel, currQuadNorm);
    resolve_slope_collision(player[playerCount]->hitbox.center, player[playerCount]->vel, currQuad);
    float planeD = calculate_plane_d(currQuadNorm, currQuadCenter);
    resolve_sphere_quad_collision(&player[playerCount]->hitbox.center, player[playerCount]->hitbox.radius, currQuadNorm, planeD);
  }
}

// wall surface collisions
void player_to_wall(Surface currWall, int playerCount){
  float newRadius = player[playerCount]->hitbox.radius * 4.0f;
  Sphere dummy = {player[playerCount]->hitbox.center, newRadius};
  if(!player[playerCount]->isGrounded){
    if(currWall.center.v[1] >= dummy.center.v[1]){
      resolve_sphere_surface_collision(&dummy, &player[playerCount]->pos, &player[playerCount]->vel, &currWall);
      player[playerCount]->rot.v[1] *= -1.0f;
      player[playerCount]->currSpeed *= -1.0f;
    }
  } else {
    if(currWall.center.v[1] >= player[playerCount]->hitbox.center.v[1]){
      resolve_sphere_surface_collision(&player[playerCount]->hitbox, &player[playerCount]->pos, &player[playerCount]->vel, &currWall);
    }
  }
  player[playerCount]->moveDir.v[0] *= -1.0f;
  player[playerCount]->moveDir.v[2] *= -1.0f;
}

// slope surface collisions
void player_to_slope(Surface currSlope, int playerCount){
  resolve_sphere_surface_collision(&player[playerCount]->hitbox, &player[playerCount]->pos, &player[playerCount]->moveDir, &currSlope);
  playerState[playerCount] = PLAYER_SLIDE;
  airAttackCount = 0;
  lastSlope = currSlope;
  lastSurface = lastSlope;
}

// floor surface collisions
void player_to_floor(Surface currFloor, int playerCount){
    if(player[playerCount]->isGrounded){
      resolve_sphere_surface_collision(&player[playerCount]->hitbox, &player[playerCount]->pos, &player[playerCount]->vel, &currFloor);
      player[playerCount]->pos.v[1] = currFloor.posA.v[1];
    }
    if (!player[playerCount]->isGrounded){
      playerState[playerCount] = PLAYER_LAND;
    }
    lastFloor = currFloor;
    lastSurface = lastFloor;
    airAttackCount = 0;
}


float searchDiameter = 0;

Surface closestFloors[8];
int closestFloorsCount;
Surface currFloor;
RaycastResult nextFloor;

Surface currSlope;

Surface currWall;
Surface closestWalls[8];
int closestWallsCount;

Surface closestSurfaces[3];
int closestCount;

void get_batched_surfaces(int playerCount){
  searchDiameter = player[playerCount]->hitbox.radius * 4.0f; // Double the player's hitbox diameter
  find_closest_surfaces_any_type(player[playerCount]->hitbox.center, levels[currLevel].surfaces, levels[currLevel].totalSurfaceCount, closestSurfaces, &closestCount, searchDiameter);

  find_closest_surfaces(player[playerCount]->pos, levels[currLevel].floors, levels[currLevel].floorCount, closestFloors, &closestFloorsCount, SURFACE_FLOOR, searchDiameter);
  currFloor = find_closest_surface(player[playerCount]->hitbox.center, closestFloors, closestFloorsCount);
  nextFloor = closest_surface_below_raycast(player[playerCount]->hitbox.center, levels[currLevel].floors, levels[currLevel].floorCount);


  find_closest_surfaces(player[playerCount]->pos, levels[currLevel].walls, levels[currLevel].wallCount, closestWalls, &closestWallsCount, SURFACE_WALL, searchDiameter);
  currWall = find_closest_surface(player[playerCount]->hitbox.center, closestWalls, closestWallsCount);

  currSlope = find_closest_surface(player[playerCount]->hitbox.center, levels[currLevel].slopes, levels[currLevel].slopeCount);
}

bool hitFloor = false, hitWall = false, hitSlope = false;
Surface* collidedWall1 = NULL;
Surface* collidedSlope = NULL;
void player_surface_collider(int playerCount){

  Surface* collidedWall2 = NULL;

  // Check collisions with floors
  for (int i = 0; i < closestFloorsCount; ++i) {
      if (check_sphere_surface_collision(player[playerCount]->hitbox, closestFloors[i])) {
          hitFloor = true;
          currFloor = closestFloors[i];
          break; // Stop after finding the first collision
      }
  }

  // Check collisions with walls
  for (int w = 0; w < closestWallsCount; ++w) {
    if (check_sphere_surface_collision(player[playerCount]->hitbox, closestWalls[w])) {
      if (!hitWall) {
        collidedWall1 = &closestWalls[w];
      } else {
        collidedWall2 = &closestWalls[w];
      }
      hitWall = true;
    }
  }

  // Check collisions with slopes
  if (check_sphere_surface_collision(player[playerCount]->hitbox, currSlope)) {
    hitSlope = true;
    collidedSlope = &currSlope;
  }

  // Resolve collisions
  if (hitFloor) {
      player_to_floor(currFloor, playerCount);
      if (hitSlope) player_to_slope(currSlope, playerCount);
      if (hitWall) player_to_wall(currWall, playerCount);
  } else if (hitSlope) {
      player_to_slope(currSlope, playerCount);
      if (hitWall) player_to_wall(currWall, playerCount);
  } else if (hitWall) {
    player_to_wall(currWall, playerCount);
  }
  if (collidedWall1 && collidedWall2) {
    resolve_corner_collision(&player[playerCount]->hitbox, &player[playerCount]->pos, &player[playerCount]->vel, collidedWall1, collidedWall2, closestFloors);
  }

  hitSlope = hitFloor = false;
}

void player_surface_collider_quarter_step(int playerCount) {
  T3DVec3 storedPos = player[playerCount]->pos;     // Store initial position
  T3DVec3 stepVel = player[playerCount]->vel;       // Get player velocity
  float hitboxRadius = player[playerCount]->projectile.hitbox.radius;  // Retrieve hitbox radius
  t3d_vec3_scale(&stepVel, &stepVel, 0.25f);        // Scale velocity for quarter steps

  for (uint8_t step = 0; step < 4; ++step) {
    player_surface_collider(playerCount);           // Perform collision check

    if (hitWall) {
      T3DVec3 wallNormal = calc_surface_norm(*collidedWall1);

      // Calculate the push distance based on the hitbox radius
      T3DVec3 pushOut;
      t3d_vec3_scale(&pushOut, &wallNormal, hitboxRadius);

      // Move player out of the wall
      t3d_vec3_add(&player[playerCount]->pos, &player[playerCount]->pos, &pushOut);

      // Reflect or nullify the velocity along the wall normal
      float velocityAlongWall = t3d_vec3_dot(&player[playerCount]->vel, &wallNormal);
      T3DVec3 projectedVel;
      t3d_vec3_scale(&projectedVel, &wallNormal, velocityAlongWall);
      t3d_vec3_diff(&player[playerCount]->vel, &player[playerCount]->vel, &projectedVel);

      // Nullify horizontal velocity to prevent sliding
      player[playerCount]->vel.v[0] *= 0.1f;  // Damp x velocity
      player[playerCount]->vel.v[2] *= 0.1f;  // Damp z velocity

      break;  // Exit loop after handling wall collision
    }
    else if (hitSlope) {
      // Handle slope collision similarly to wall
      T3DVec3 slopeNormal = calc_surface_norm(*collidedSlope);
      T3DVec3 pushUp;
      t3d_vec3_scale(&pushUp, &slopeNormal, hitboxRadius);
      t3d_vec3_add(&player[playerCount]->pos, &player[playerCount]->pos, &pushUp);

      float velocityAlongSlope = t3d_vec3_dot(&player[playerCount]->vel, &slopeNormal);
      T3DVec3 projectedVel;
      t3d_vec3_scale(&projectedVel, &slopeNormal, velocityAlongSlope);
      t3d_vec3_diff(&player[playerCount]->vel, &player[playerCount]->vel, &projectedVel);

      // Nullify horizontal velocity to prevent sliding on slopes
      player[playerCount]->vel.v[0] *= 0.1f;  // Damp x velocity
      player[playerCount]->vel.v[2] *= 0.1f;  // Damp z velocity

      break;
    } else {
      // No collision, move player by quarter step
      player[playerCount]->pos.v[0] += stepVel.v[0];
      player[playerCount]->pos.v[2] += stepVel.v[2];
    }
  }

  // Apply full velocity if no wall or slope collision
  if (!hitWall && !hitSlope) {
    player[playerCount]->pos.v[0] = storedPos.v[0] + player[playerCount]->vel.v[0];
    player[playerCount]->pos.v[2] = storedPos.v[2] + player[playerCount]->vel.v[2];
  } else {
    // Reduce velocity after handling collision to prevent sliding
    player[playerCount]->vel.v[0] *= 0.8f;
    player[playerCount]->vel.v[2] *= 0.8f;
  }
}

void player_update(void){
  float speedMultiplayer;
  for (int i = 0; i < numPlayers; ++i) {

      speedMultiplayer = 1.2f;

    // Transform input direction to camera's coordinate system
    T3DVec3 newDir = {{
        (float)joypad[i].stick_x * 0.05f * player[i]->cam.camResults.right.v[0] + -(float)joypad[i].stick_y * 0.05f * player[i]->cam.camResults.forward.v[0],
        0, // :.[
        (float)joypad[i].stick_x * 0.05f * player[i]->cam.camResults.right.v[2] + -(float)joypad[i].stick_y * 0.05f * player[i]->cam.camResults.forward.v[2]
    }};
    float speed = 0.75f * sqrtf(t3d_vec3_len2(&newDir));

    // Player Jump Input
    if(btn[i].r  && player[i]->isGrounded) {
        sound_jump();
        playerState[i] = PLAYER_JUMP_START;
    }

    player[i]->haircolor = player[i]->isSpecial ? WHITE : RED;


  // Head, weapon, and costume selection
  if (btn[i].d_left) player[i]->headIndex = (player[i]->headIndex < headMax) ? player[i]->headIndex+ 1 : 0;
  if (btn[i].d_right) player[i]->weaponIndex = (player[i]->weaponIndex < weaponMax) ? player[i]->weaponIndex + 1 : 0;
  if (btn[i].d_up) player[i]->costumeIndex = (player[i]->costumeIndex < costumeMax) ? player[i]->costumeIndex + 1 : 0;
  if (btn[i].d_down) {
    player[0]->health = 200;
    player[0]->headIndex = 1;
    if(numPlayers > 1){
        player[1]->health = 200;
        player[1]->headIndex = 1;
    }
    if(numPlayers > 2){
        player[2]->health = 200;
        player[2]->headIndex = 1;
    }
    if(numPlayers > 3){
        player[3]->health = 200;
        player[3]->headIndex = 1;
    }

  }

  if (btnheld[i].a && btnheld[i].b && player[i]->score >= 500 && !player[i]->isGrounded){
      player[i]->isSpecial = true;
  }

  if (player[i]->isSpecial && player[i]->score > 0){
      player[i]->headIndex = 3;
      player[i]->score --;
  }

  if (player[i]->isSpecial && player[i]->score < 1){
      player[i]->isSpecial = false;
      player[i]->headIndex = 1;
  }

  if (player[i]->health < 1){
      player[i]->isSpecial = false;
      player[i]->health = 0;
      player[i]->headIndex = 0;
  }

  // Player Doging Input
  if (btn[i].a && actionicon[i] != open &&  player[i]->isGrounded){
    sound_jump();
    playerState[i] = PLAYER_ROLL;
  }

if(player[i]->gunCooldown > 0)player[i]->gunCooldown--;

  // Player Attack Input
  if(btn[i].b && player[i]->gunCooldown == 0) {
    player[i]->isSword ? sound_attack() : sound_handgun();
          switch(player[i]->weaponIndex) {
        case 4:
          player[i]->gunCooldown += display_get_fps() * 0.75f;
          break;
      }
    //sound_air();
    t3d_anim_set_time(&animPunch[i], 0.0f);
    t3d_anim_set_time(&animAttack[i], 0.0f);
    t3d_anim_set_time(&animFire[i], 0.0f);
    t3d_anim_set_time(&animFireBig[i], 0.0f);
    playerState[i] = PLAYER_ATTACK_START;
  }

  player[i]->isSword = !(player[i]->weaponIndex > 2);

  // Player movement
  if((speed > 0.1f
              && playerState[i] != PLAYER_JUMP_START
              && playerState[i] != PLAYER_JUMP
              && playerState[i] != PLAYER_ATTACK_START
              && playerState[i] != PLAYER_ATTACK)
              || (speed > 0.1f && !player[i]->isSword)) {
    newDir.v[0] /= speed;
    newDir.v[2] /= speed;
    player[i]->moveDir = newDir;

    float newAngle = atan2f(player[i]->moveDir.v[0], player[i]->moveDir.v[2]);
    // fix for gun mode
    if(!player[i]->isSword && (float)joypad[i].stick_y < 0 && player[i]->cam.cam_mode == CAM_FOLLOW) newAngle += M_PI;
    // press z to strafe
    if (!btnheld[i].z || ((player[i]->ztarget == true) && (player[i]->weaponIndex < 3))) player[i]->rot.v[1] = t3d_lerp_angle(player[i]->rot.v[1], newAngle, 0.2f);

    player[i]->currSpeed = t3d_lerp(player[i]->currSpeed, speed * 0.2f, 0.2f);
    player[i]->currSpeed *= speedMultiplayer;

  } else if (speed > 0.1f && playerState[i] == PLAYER_JUMP) {
    newDir.v[0] /= speed;
    newDir.v[2] /= speed;
    player[i]->moveDir = newDir;

    float newAngle = atan2f((player[i]->moveDir.v[0]), (player[i]->moveDir.v[2]));
    if(player[i]->playernumb > -1)player[i]->rot.v[1] = t3d_lerp_angle(player[i]->rot.v[1], newAngle, 0.7f);
    player[i]->currSpeed = t3d_lerp(player[i]->currSpeed, speed * 0.6f, 0.6f);
    player[i]->currSpeed *= speedMultiplayer;

  } else {
    player[i]->currSpeed *= 0.8f * speedMultiplayer;
  }
        for (int i = 0; i < numPlayers; i++) {
            for (int j = i + 1; j < numPlayers; j++) {
                if (btnheld[i].z){
                    if((t3d_vec3_distance(&player[i]->pos, &player[j]->pos) < 100.0f)
                            && (j > player[i]->playernumb)){
                                    player[i]->playernumb = j;
                    }
                } else {
                player[i]->playernumb = -1;
            }
        }
    }

    if(player[i]->playernumb > -1) {
        player[i]->ztarget = true;
    } else {
        player[i]->ztarget = false;
    }

  // use blend based on speed for smooth transitions
  player[i]->animBlend = player[i]->currSpeed * 5;
  if(player[i]->animBlend > 1.0f || playerState[i] == PLAYER_FALL || playerState[i] == PLAYER_ROLL)player[i]->animBlend = 1.0f;
  if(!player[i]->isGrounded || playerState[i] == PLAYER_ATTACK_START || playerState[i] == PLAYER_ATTACK){
    player[i]->animBlend = 0;
  }

  // move player...
  player[i]->pos.v[0] += player[i]->moveDir.v[0] * player[i]->currSpeed;
  player[i]->pos.v[2] += player[i]->moveDir.v[2] * player[i]->currSpeed;

  // Update player bounding box
  player[i]->hitbox.center.v[0] = player[i]->pos.v[0];
  player[i]->hitbox.center.v[1] = player[i]->pos.v[1] + player[i]->hitbox.radius;
  player[i]->hitbox.center.v[2] = player[i]->pos.v[2];

  // Limit position inside of bounds
  if(player[i]->pos.v[0] < FloorBox.min.v[0]) player[i]->pos.v[0] = FloorBox.min.v[0];
  if(player[i]->pos.v[0] >  FloorBox.max.v[0])player[i]->pos.v[0] = FloorBox.max.v[0];
  if(player[i]->pos.v[2] < FloorBox.min.v[2]) player[i]->pos.v[2] = FloorBox.min.v[2];
  if(player[i]->pos.v[2] >  FloorBox.max.v[2])player[i]->pos.v[2] = FloorBox.max.v[2];

  // Update the animation and modify the skeleton, this will however NOT recalculate the matrices

  switch(playerState[i]){
    case PLAYER_SLIDE:
    case PLAYER_SLIDE_DOWN:
    case PLAYER_IDLE:
    case PLAYER_WALK:
    case PLAYER_RUN:
    actionicon[i] = roll;
      t3d_anim_set_playing(&animJump[i], false);
      t3d_anim_set_playing(&animFall[i], false);
      t3d_anim_set_playing(&animFire[i], false);
      t3d_anim_set_playing(&animFireBig[i], false);
      t3d_anim_set_playing(&animAttack[i], false);
      t3d_anim_set_playing(&animPunch[i], false);
      t3d_anim_set_playing(&animIdle[i], true);
      t3d_anim_set_playing(&animWalk[i], true);
      t3d_anim_update(&animIdle[i], deltaTime);
      t3d_anim_set_speed(&animWalk[i], player[i]->animBlend);
      t3d_anim_update(&animWalk[i], deltaTime);
      t3d_anim_update(&animRun[i], deltaTime);
        if((player[i]->currSpeed > 1.0f) || (playerState[i] == (PLAYER_SLIDE_DOWN || PLAYER_SLIDE))) {
          t3d_anim_set_playing(&animRun[i], true);
        } else if(player[i]->currSpeed < 0.1f){
          player[i]->currSpeed = 0.0f;
          t3d_anim_set_speed(&animWalk[i], 0);
        }
      break;
    case PLAYER_JUMP_START:
    case PLAYER_JUMP:
    actionicon[i] = fall;
      t3d_anim_set_playing(&animIdle[i], false);
      t3d_anim_set_playing(&animWalk[i], false);
      t3d_anim_set_playing(&animRun[i], false);
      t3d_anim_update(&animJump[i], deltaTime);
      break;
    case PLAYER_FALL:
    actionicon[i] = fall;
      t3d_anim_set_playing(&animIdle[i], false);
      t3d_anim_set_playing(&animWalk[i], false);
      t3d_anim_set_playing(&animPunch[i], false);
      t3d_anim_set_playing(&animAttack[i], false);
      t3d_anim_set_playing(&animFire[i], false);
      t3d_anim_set_playing(&animFireBig[i], false);
      t3d_anim_update(&animFall[i], deltaTime);
      break;
    case PLAYER_ATTACK:
    case PLAYER_ATTACK_START:
      t3d_anim_set_playing(&animJump[i], false);
      t3d_anim_set_playing(&animFall[i], false);
      switch(player[i]->weaponIndex) {
        case 0:
          t3d_anim_set_playing(&animAttack[i], false);
          t3d_anim_set_playing(&animFire[i], false);
          t3d_anim_set_playing(&animFireBig[i], false);
          t3d_anim_set_playing(&animPunch[i], true);
          t3d_anim_update(&animPunch[i], deltaTime);
          break;
        case 1:
          t3d_anim_set_playing(&animPunch[i], false);
          t3d_anim_set_playing(&animFire[i], false);
          t3d_anim_set_playing(&animFireBig[i], false);
          t3d_anim_set_playing(&animAttack[i], true);
          t3d_anim_update(&animAttack[i], deltaTime);
          break;
        case 2:
          t3d_anim_set_playing(&animPunch[i], false);
          t3d_anim_set_playing(&animFire[i], false);
          t3d_anim_set_playing(&animFireBig[i], false);
          t3d_anim_set_playing(&animAttack[i], true);
          t3d_anim_update(&animAttack[i], deltaTime);
          break;
        case 3:
          t3d_anim_set_playing(&animAttack[i], false);
          t3d_anim_set_playing(&animPunch[i], false);
          t3d_anim_set_playing(&animFireBig[i], false);
          t3d_anim_set_playing(&animFire[i], true);
          t3d_anim_update(&animFire[i], deltaTime);
          break;
        case 4:
          t3d_anim_set_playing(&animAttack[i], false);
          t3d_anim_set_playing(&animPunch[i], false);
          t3d_anim_set_playing(&animFire[i], false);
          t3d_anim_set_playing(&animFireBig[i], true);
          t3d_anim_update(&animFireBig[i], deltaTime);
          break;
      }
      break;
    case PLAYER_ROLL:
    actionicon[i] = roll;
      t3d_anim_set_playing(&animIdle[i], true);
      t3d_anim_set_playing(&animWalk[i], true);
      t3d_anim_update(&animIdle[i], deltaTime);
      t3d_anim_set_speed(&animWalk[i], player[i]->animBlend);
      t3d_anim_update(&animWalk[i], deltaTime);
      t3d_anim_set_playing(&animRoll[i], true);
    case PLAYER_LAND:
    actionicon[i] = none;
      t3d_anim_set_time(&animIdle[i], 0.0f);
      t3d_anim_set_time(&animWalk[i], 0.0f);
      t3d_anim_set_time(&animRun[i], 0.0f);
      t3d_anim_set_time(&animJump[i], 0.0f);
      t3d_anim_set_time(&animFall[i], 0.0f);
      t3d_anim_set_playing(&animJump[i], false);
      t3d_anim_set_playing(&animFall[i], false);
      break;
  }

  // do walk
  if(player[i]->isGrounded){
    if(playerState[i] != PLAYER_JUMP_START
      && playerState[i] != PLAYER_JUMP
      && playerState[i] != PLAYER_FALL
      && playerState[i] != PLAYER_SLIDE
      && playerState[i] != PLAYER_ATTACK_START
      && playerState[i] != PLAYER_ATTACK
      && playerState[i] != PLAYER_ROLL) {
        if(player[i]->currSpeed > 1.0f) {
          playerState[i] = PLAYER_RUN;
        } else if(player[i]->currSpeed > 0.1f) {
          playerState[i] = PLAYER_WALK;
        } else {
          playerState[i] = PLAYER_IDLE;
        }
    }
  }

  get_batched_surfaces(i);

  // Check for collision with players then actors if in grounded asction state
  if(playerState[i] == PLAYER_IDLE
  || playerState[i] == PLAYER_WALK
  || playerState[i] == PLAYER_RUN
  || playerState[i] == PLAYER_ATTACK_START
  || playerState[i] == PLAYER_ATTACK
  || playerState[i] == PLAYER_ROLL){
    if(numPlayers > 1){
      check_player_collisions(player, numPlayers);
    }

    player_surface_collider_quarter_step(i);

    for (int w = 0; w < levels[currLevel].numWarps; ++w) {
        check_warp(levels[currLevel].warp[w], i);
    }

    handle_actor_octree_collisions(boxOctree, crates, numCrates, i);

  }

// do fall
  if(playerState[i] == PLAYER_FALL || playerState[i] == PLAYER_ATTACK) {
    t3d_anim_update(&animFall[i], deltaTime);

    if(numPlayers > 1){
      check_player_collisions(player, numPlayers);
    }

    player_surface_collider_quarter_step(i);

    for (int w = 0; w < levels[currLevel].numWarps; ++w) {
        check_warp(levels[currLevel].warp[w], i);
    }

    check_midair_actor_collisions(crates, numCrates, i);

    if(!player[i]->isGrounded){
      if (player[i]->pos.v[1] > groundLevel) {
        // Slow fall while holding A
        if(btnheld[i].r){
          player[i]->vel.v[1] = t3d_lerp(player[i]->vel.v[1], GRAVITY, fallFixedTime);
          player[i]->pos.v[1] = t3d_lerp(player[i]->pos.v[1],player[i]->vel.v[1], fallFixedTime);
          player[i]->hitbox.center.v[1] = t3d_lerp(player[i]->hitbox.center.v[1],player[i]->pos.v[1], fallFixedTime);
        } else {
          player[i]->vel.v[1] = t3d_lerp(player[i]->vel.v[1], GRAVITY, jumpFixedTime);
          player[i]->pos.v[1] = t3d_lerp(player[i]->pos.v[1],player[i]->vel.v[1], jumpFixedTime);
          player[i]->hitbox.center.v[1] = t3d_lerp(player[i]->hitbox.center.v[1],player[i]->pos.v[1], jumpFixedTime);
        }
        player[i]->scale.v[1] = t3d_lerp(player[i]->scale.v[1], newScale * 1.4f, fixedTime);

      } else if (player[i]->pos.v[1] <= groundLevel) {
        player[i]->pos = playerStartPos;
        player[i]->vel.v[1] = 0.0f;
        player[i]->scale.v[1] = newScale;
        if(numPlayers > 2){
          player[i]->jumpForce = 300.0f;
        } else {
          player[i]->jumpForce = 250.0f;
        }
      }
    }
  }

  // do land
  while(playerState[i] == PLAYER_LAND){
    player[i]->scale.v[1] = newScale;
    playerState[i] = PLAYER_IDLE;
    if(!rumbleLong[i] && !rumbleShort[i] && !rumbleWave[i]){
        rumbleLong[i] = true;
      }
    break;
  }

  // do slide/slope interaction
  if(playerState[i] == PLAYER_SLIDE){
    player[i]->scale.v[1] = newScale;
    player[i]->cam.camPos.v[1] = player[i]->hitbox.center.v[1] + 10;
    player[i]->cam.camTarget.v[1] = player[i]->hitbox.center.v[1] +10;
    if(!rumbleLong[i] && !rumbleShort[i] && !rumbleWave[i]){
      rumbleWave[i] = true;
    }
    if(animRoll[i].isPlaying) {
      playerState[i] = PLAYER_ROLL;
    } else if(animPunch[i].isPlaying || animAttack[i].isPlaying || animFire[i].isPlaying || animFireBig[i].isPlaying) {
      playerState[i] = PLAYER_ATTACK;
    } else {
      playerState[i] = PLAYER_RUN;
    }
  }

  // do roll
  if(playerState[i] == PLAYER_ROLL){
      t3d_anim_set_playing(&animRoll[i], true);
      t3d_anim_set_speed(&animRoll[i], player[i]->animBlend);
      t3d_anim_update(&animRoll[i], deltaTime);
      if(!animRoll[i].isPlaying)playerState[i] = PLAYER_IDLE;
  }

  //do attack
  if(playerState[i] == PLAYER_ATTACK_START){

    if(airAttackCount == 0){
      player[i]->scale.v[1] = newScale;
      //player[i]->currSpeed *= 0.5f;
      player[i]->projectile.pos = player[i]->hitbox.center;
      if(player[i]->isSword){
        player[i]->projectile.speed = 80.0f;
      } else {
      player[i]->projectile.speed = 80.0f * 32.0f;
      }
      player[i]->projectile.isActive = true;
      playerState[i] = PLAYER_ATTACK;
      if(!rumbleLong[i] && !rumbleShort[i] && !rumbleWave[i]){
        rumbleShort[i] = true;
      }
    } else {
      playerState[i] = PLAYER_FALL;
    }
  }

  if(playerState[i] == PLAYER_ATTACK){

    if(player[i]->isSword)player[i]->currSpeed = 0;
    player[i]->projectile.pos.v[0] += player[i]->projectile.dir.v[0] * player[i]->projectile.speed * fixedTime;
    player[i]->projectile.pos.v[1] += player[i]->projectile.dir.v[1] * player[i]->projectile.speed * fixedTime;
    player[i]->projectile.pos.v[2] += player[i]->projectile.dir.v[2] * player[i]->projectile.speed * fixedTime;

    // Calculate the distance traveled by the projectile from its origin
    float distanceTraveled = t3d_vec3_distance(&player[i]->projectile.pos, &player[i]->hitbox.center);

    // Define the maximum distance the projectile can travel
    float EndPosMax = player[i]->projectile.length = 16.0f;
    if(!player[i]->isSword) {
      EndPosMax = player[i]->projectile.length = 16.0f * 128.0f;
    } else {
      EndPosMax = player[i]->projectile.length = 16.0f;
    }

    // Reverse direction if the maximum distance is reached
    if (distanceTraveled >= EndPosMax) {
      player[i]->projectile.speed = 128.0f;
      if(!player[i]->isSword)player[i]->projectile.speed *= 32.0f;
      player[i]->projectile.dir.v[0] = -player[i]->projectile.dir.v[0];
      player[i]->projectile.dir.v[1] = -player[i]->projectile.dir.v[1];
      player[i]->projectile.dir.v[2] = -player[i]->projectile.dir.v[2];
    }

    // Calculate the end position based on the projectiles's direction and length
    T3DVec3 EndPos;
    EndPos.v[0] = player[i]->projectile.pos.v[0] + player[i]->projectile.dir.v[0] * player[i]->projectile.length;
    EndPos.v[1] = player[i]->projectile.pos.v[1] + player[i]->projectile.dir.v[1] * player[i]->projectile.length;
    EndPos.v[2] = player[i]->projectile.pos.v[2] + player[i]->projectile.dir.v[2] * player[i]->projectile.length;
    t3d_vec3_norm(&EndPos);



    // Scale hitbox up and down according to position
    if (distanceTraveled <= EndPosMax) {
      player[i]->projectile.hitbox.center = player[i]->projectile.pos;
      if(numPlayers > 3){
        player[i]->projectile.hitbox.radius += 2.5f;
      } else {
        player[i]->projectile.hitbox.radius += 1.5f;
      }

      if(player[i]->projectile.hitbox.radius > 20.0f){
        player[i]->projectile.hitbox.radius = 20.0f;
      }
    }

    if(numPlayers > 1){
      check_player_collisions(player, numPlayers);
    }
    check_attack_collisions(crates, numCrates, i);

    if(!animPunch[i].isPlaying && !animAttack[i].isPlaying && !animFire[i].isPlaying && !animFireBig[i].isPlaying){
      player[i]->projectile.hitbox.center = player[i]->hitbox.center;
      player[i]->projectile.speed = 0.0f;
      player[i]->projectile.isActive = false;
      if (player[i]->isGrounded) {
        playerState[i] = PLAYER_IDLE;
      } else {
        airAttackCount++;
        playerState[i] = PLAYER_FALL;
      }
    }
  }

//do jump
  if(playerState[i] == PLAYER_JUMP_START) {

    t3d_anim_set_time(&animJump[i], 0.0f);
    t3d_anim_set_playing(&animJump[i], true);

    if(numPlayers > 1){
      check_player_collisions(player, numPlayers);
    }

    handle_actor_octree_collisions(boxOctree, crates, numCrates, i);
    player_surface_collider_quarter_step(i);

    Surface currSlope = find_closest_surface(player[i]->hitbox.center, levels[currLevel].slopes, levels[currLevel].slopeCount);
    if (check_sphere_surface_collision(player[i]->hitbox, currSlope)){
      player[i]->pos.v[1] += player[i]->hitbox.radius * 2.5f;
    }
    Surface currFloor = find_closest_surface(player[i]->hitbox.center, levels[currLevel].floors, levels[currLevel].floorCount);
    if (check_sphere_surface_collision(player[i]->hitbox, currFloor)){
      player[i]->pos.v[1] += player[i]->hitbox.radius;
    }

    // Apply jump force modifier
    player[i]->vel.v[1] = player[i]->jumpForce + player[i]->pos.v[1];

    playerState[i] = PLAYER_JUMP;
  }

  if(playerState[i] == PLAYER_JUMP){

    //t3d_anim_update(&animJump[i], jumpTime);
    player[i]->scale.v[1] = t3d_lerp(player[i]->scale.v[1], newScale * 1.4f, fixedTime);

    if (!animJump[i].isPlaying){
      playerState[i] = PLAYER_FALL;
      t3d_anim_set_playing(&animFall[i], true);
      t3d_anim_set_time(&animFall[i], 0.0f);
    }

    // Apply gravity
    player[i]->vel.v[1] = t3d_lerp(player[i]->vel.v[1], GRAVITY, fixedTime);

    // Update player position
    player[i]->pos.v[1] = t3d_lerp(player[i]->pos.v[1], player[i]->vel.v[1], fixedTime);

    // Update player bounding box
    t3d_vec3_lerp(&player[i]->hitbox.center, &player[i]->pos, &player[i]->hitbox.center, fixedTime);
    player[i]->hitbox.center.v[1] = player[i]->hitbox.center.v[1] + player[i]->hitbox.radius;

    // Check for collision with players then actors then floor
    if(numPlayers > 1){
      check_player_collisions(player, numPlayers);
    }

    player_surface_collider_quarter_step(i);

    for (int w = 0; w < levels[currLevel].numWarps; ++w) {
      check_warp(levels[currLevel].warp[w], i);
    }

    check_midair_actor_collisions(crates, numCrates, i);
  }

// do grounded
  switch(playerState[i]){
    case PLAYER_WALK:
    case PLAYER_RUN:
    //sound_foot();
    case PLAYER_IDLE:
    case PLAYER_ROLL:
    case PLAYER_SLIDE:
    case PLAYER_LAND:
      player[i]->isGrounded = true;
    break;
    case PLAYER_JUMP_START:
    case PLAYER_JUMP:
    case PLAYER_FALL:
      player[i]->isGrounded = false;
      break;
  }

  if(player[i]->isGrounded) {
    if (player[i]->pos.v[1] < groundLevel) {
      player[i]->pos = playerStartPos;
    }

    if(player[i]->pos.v[1] > groundLevel){
      Surface currSlope = find_closest_surface(player[i]->hitbox.center, levels[currLevel].slopes, levels[currLevel].slopeCount);
      if (!check_sphere_surface_collision(player[i]->hitbox, currSlope)){
        Surface currFloor = find_closest_surface(player[i]->hitbox.center, levels[currLevel].floors, levels[currLevel].floorCount);
        if (!check_sphere_surface_collision(player[i]->hitbox, currFloor)){
          for (int c = 0; c < numCrates; ++c) {
            int closestCrate = find_closest(player[i]->pos, crates, numCrates);
            if(!check_sphere_box_collision(player[i]->hitbox, crates[closestCrate]->hitbox.shape.aabb)){
              // Check if the player is outside bounds in the x and z directions
              if (player[i]->hitbox.center.v[0] >= crates[closestCrate]->hitbox.shape.aabb.max.v[0] ||
                  player[i]->hitbox.center.v[0] <= crates[closestCrate]->hitbox.shape.aabb.min.v[0] ||
                  player[i]->hitbox.center.v[2] >= crates[closestCrate]->hitbox.shape.aabb.max.v[2] ||
                  player[i]->hitbox.center.v[2] <= crates[closestCrate]->hitbox.shape.aabb.min.v[2]) {

                playerState[i] = PLAYER_FALL;
              }
            } else {
              if (player[i]->pos.v[1] < crates[closestCrate]->hitbox.shape.aabb.max.v[1]) {
                playerState[i] = PLAYER_FALL;
              }
            }
          }
        }
      }
    }
  }


  // Handle surface rotations
  float pitch = 0;
  float roll = 0;
  T3DVec3 lastSurfaceNormal = lastSurface.normal;
  t3d_vec3_norm(&lastSurfaceNormal);

  if (lastSurface.type == SURFACE_SLOPE) {
    float newPitch = atan2f(lastSurfaceNormal.v[2], lastSurfaceNormal.v[1]) * 180.0f / T3D_PI;
    newPitch = clamp(newPitch, -0.5f, 0.5f);

    float newRoll = atan2f(lastSurfaceNormal.v[1], lastSurfaceNormal.v[2]) * 180.0f / T3D_PI;
    newRoll = clamp(newRoll, -0.5f, 0.5f);

    pitch = fabsf(newPitch);
    if(lastSurfaceNormal.v[0] > 0){
      roll = -fabsf(newRoll);
    }
    if(lastSurfaceNormal.v[0] < 0){
      roll = fabsf(newRoll);
    }

  }

  player[i]->rot.v[0] = t3d_lerp_angle(player[i]->rot.v[0], pitch, 0.2f);
  player[i]->rot.v[2] = t3d_lerp_angle(player[i]->rot.v[2], roll, 0.2f);

  // update shadow
  if(numPlayers < 3){
  player[i]->shadowPos.v[0] = player[i]->pos.v[0];
  player[i]->shadowPos.v[2] = player[i]->pos.v[2];
  player[i]->shadowRot = player[i]->rot;
  RaycastResult raySlope = closest_surface_below_raycast(player[i]->pos, levels[currLevel].slopes, levels[currLevel].slopeCount);
  Surface shadowSlope = find_closest_surface(player[i]->pos, levels[currLevel].slopes, levels[currLevel].slopeCount);

  currFloor = find_closest_surface(player[i]->hitbox.center, levels[currLevel].floors, levels[currLevel].floorCount);
  float dist_player_next_floor = distance_to_surface(player[i]->hitbox.center, currFloor);
  float dist_player_next_slope = distance_to_surface(player[i]->hitbox.center, shadowSlope);

  bool shadowOnSlope = false;

  if (!isnan(dist_player_next_slope) && !isnan(dist_player_next_floor) && dist_player_next_slope < dist_player_next_floor){
    shadowOnSlope = true;
  } else {
    shadowOnSlope = false;
  }


  if(!player[i]->isGrounded){
    if(shadowOnSlope){
      if(!isnan(dist_player_next_slope) && dist_player_next_slope > player[i]->hitbox.radius * 2.5f){
        if(!isnan(raySlope.posY)){
          player[i]->shadowPos.v[1] = t3d_lerp(player[i]->shadowPos.v[1], raySlope.posY, 0.7f);
        } else {
          player[i]->shadowPos.v[1] = t3d_lerp(player[i]->shadowPos.v[1], 0, 0.7f);
        }
      } else {
        if(!isnan(nextFloor.posY)){
          player[i]->shadowPos.v[1] = nextFloor.posY;
        } else {
          player[i]->shadowPos.v[1] = player[i]->pos.v[1];
        }
      }
    } else {
      if(!isnan(nextFloor.posY)){
        player[i]->shadowPos.v[1] = t3d_lerp(player[i]->shadowPos.v[1], nextFloor.posY, 0.7f);
      } else {
        player[i]->shadowPos.v[1] = t3d_lerp(player[i]->shadowPos.v[1], 0, 0.7f);
      }
    }
  } else {
    player[i]->shadowPos.v[1] = player[i]->pos.v[1];
  }
  }

  //reset projectile
  if(player[i]->projectile.speed == 0.0f){
    update_player_forward(&player[i]->forward, player[i]->rot.v[1]);
    player[i]->projectile.pos = player[i]->hitbox.center;
    player[i]->projectile.dir = player[i]->forward;
    player[i]->projectile.hitbox.center =  player[i]->projectile.pos;
    player[i]->projectile.hitbox.radius = 8.0f;
  }

  hitWall = false;

  }

}
