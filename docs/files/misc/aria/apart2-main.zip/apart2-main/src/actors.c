#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3danim.h>
#include <t3d/t3dmodel.h>
#include <t3d/t3dskeleton.h>
#include "../include/globals.h"
#include "../include/enums.h"
#include "../include/types.h"
#include "actors.h"
#include "collision.h"
#include "debug.h"
#include "levels.h"
#include "map.h"
#include "octree_test.h"
#include "player.h"
#include "sound.h"
#include "utils.h"

// Crates
T3DMat4FP* crateMatFP[MAX_CRATES];
rspq_block_t *dplCrate[MAX_CRATES];
T3DModel *modelCrate;
Actor *crates[MAX_CRATES];
int numCrates;
T3DVec3 cratesStartingPos[MAX_CRATES];
OctreeNode *boxOctree;


// This is a callback for t3d_model_draw_custom, it is used when a texture in a model is set to dynamic/"reference"
void dynamic_tex_cb(void* userData, const T3DMaterial* material, rdpq_texparms_t *tileParams, rdpq_tile_t tile) {
  if(tile != TILE0)return; // we only want to set one texture
  // 'userData' is a value you can pass into 't3d_model_draw_custom', this can be any value or struct you want...
  surface_t* surface = (surface_t*)userData; // ...in this case it is a surface pointer

  rdpq_sync_tile();
  rdpq_mode_tlut(TLUT_NONE);
  rdpq_tex_upload(TILE0, surface, NULL);
}

void check_crates_collisions(Actor *crates[], int numCrates) {

  for (int i = 0; i < numCrates; i++) {
    for (int j = i + 1; j < numCrates; j++) {
      if (check_box_collision(crates[i]->hitbox.shape.aabb, crates[j]->hitbox.shape.aabb)) {
        resolve_box_collision_offset_xz(crates[j]->hitbox.shape.aabb, &crates[i]->pos, .2f);
        if(crates[j]->IsBouncy == true) {
          crates[j]->pos.v[0] += crates[i]->pos.v[0]  * jumpFixedTime;
          crates[j]->pos.v[2] += crates[i]->pos.v[2] * jumpFixedTime;
        }
      }
    }
  }
}


// Initialize crates
void crates_init(void){
  numCrates = (int)(random_float(1.0f,MAX_CRATES));

  for (int i = 0; i <= numCrates; ++i) {
    crateMatFP[i] = malloc_uncached(sizeof(T3DMat4FP));

    float X = random_float(-200.0f, 200.0f);
    float Z = random_float(-200.0f, 100.0f);

    crates[i] = malloc(sizeof(Actor));

    crates[i]->pos = (T3DVec3){{X, 50.0f, Z}};
    cratesStartingPos[i] = crates[i]->pos;
    crates[i]->moveDir = (T3DVec3){{0, 0, 0}};
    crates[i]->forward = (T3DVec3){{0, 0, 1}};
    crates[i]->vel = (T3DVec3){{0, 0, 0}};
    crates[i]->rot = (T3DVec3){{0, 0, 0}};
    crates[i]->hitbox.shape.type = SHAPE_BOX;
    crates[i]->hitbox.shape.aabb = (AABB){{{crates[i]->pos.v[0] - 32.0f, crates[i]->pos.v[1], crates[i]->pos.v[2] - 32.0f}},
                                         {{crates[i]->pos.v[0] + 32.0f, crates[i]->pos.v[1] + 64.0f, crates[i]->pos.v[2] + 32.0f}}};
    crates[i]->isSafe = RANDN(2);
    crates[i]->IsBouncy = RANDN(2);
    color_t crateColor[MAX_CRATES];
    if(crates[i]->isSafe){
      if(crates[i]->IsBouncy){
        crateColor[i] = YELLOW;
      } else {
        crateColor[i] = WHITE;
      }
    } else {
      crateColor[i] = RED;
    }

    // Create gfx call to draw crate
    rspq_block_begin();
      t3d_matrix_push_pos(1);
      matCount++;
      t3d_matrix_set(crateMatFP[i], true);
      rdpq_set_prim_color(crateColor[i]);
      t3d_matrix_set(crateMatFP[i], true);
      t3d_model_draw(modelCrate);
      t3d_matrix_pop(1);
    dplCrate[i] = rspq_block_end();

  }

}

sprite_t* sprites[2];

void actors_init(void){

  modelCrate = t3d_model_load("rom:/models/box.t3dm");
  crates_init();

  // Check and resolve collisions for each actor
  for (int c = 0; c <= numCrates; ++c) {
    if (check_box_collision(crates[c]->hitbox.shape.aabb, FloorBox)) {
      resolve_box_collision_offset(FloorBox, &crates[c]->pos, 1.0f);
    }
    check_crates_collisions(crates, numCrates);
    crates[c]->hitbox.shape.aabb = (AABB){{{crates[c]->pos.v[0] - 32.0f, crates[c]->pos.v[1], crates[c]->pos.v[2] - 32.0f}},
                                         {{crates[c]->pos.v[0] + 32.0f, crates[c]->pos.v[1] + 64.0f, crates[c]->pos.v[2] + 32.0f}}};
  }

  boxOctree = create_octree(octreeCenter, octreeHalfSize, maxActorsPerNode);
  populate_octree(boxOctree, crates, numCrates);

}

float dist = 0;
float minDist = 0;

void crates_update(void){

  for (int c = 0; c <= numCrates; ++c) {

    crates[c]->pos.v[1] += GRAVITY * jumpFixedTime;

    Surface findFloor = find_closest_surface(crates[c]->hitbox.shape.aabb.min, levels[currLevel].floors, levels[currLevel].floorCount);
    Surface findWallMin = find_closest_surface(crates[c]->hitbox.shape.aabb.min, levels[currLevel].walls, levels[currLevel].wallCount);
    Surface findWallMax = find_closest_surface(crates[c]->hitbox.shape.aabb.max, levels[currLevel].walls, levels[currLevel].wallCount);
    if (crates[c]->pos.v[1] < findFloor.center.v[1] + crates[c]->hitbox.shape.aabb.min.v[1]) {
      crates[c]->pos.v[1] = findFloor.center.v[1];
    }

    if(crates[c]->IsBouncy){
      check_crates_collisions(crates, numCrates);
       float dist_crates_to_floor = distance_to_surface(crates[c]->pos, findFloor);
      if(dist_crates_to_floor > 75.0f) {
        crates[c]->pos.v[0] = cratesStartingPos[c].v[0];
        crates[c]->pos.v[2] = cratesStartingPos[c].v[2];
      }
      if(check_box_surface_collision(crates[c]->hitbox.shape.aabb, findWallMin)) {
        crates[c]->pos = cratesStartingPos[c];
      }
      if(check_box_surface_collision(crates[c]->hitbox.shape.aabb, findWallMax)) {
        crates[c]->pos = cratesStartingPos[c];
      }
    }
    // Limit position inside of bounds
    if(crates[c]->pos.v[0] < FloorBox.min.v[0]){
      crates[c]->pos.v[0] = FloorBox.min.v[0];
      crates[c]->vel.v[0] = -crates[c]->vel.v[0];
    }
    if(crates[c]->pos.v[0] >  FloorBox.max.v[0]){
      crates[c]->pos.v[0] = FloorBox.max.v[0];
      crates[c]->vel.v[0] = -crates[c]->vel.v[0];
    }
    if(crates[c]->pos.v[2] < FloorBox.min.v[2]){
      crates[c]->pos.v[2] = FloorBox.min.v[2];
      crates[c]->vel.v[2] = -crates[c]->vel.v[2];
    }
    if(crates[c]->pos.v[2] >  FloorBox.max.v[2]){
      crates[c]->pos.v[2] = FloorBox.max.v[2];
      crates[c]->vel.v[2] = -crates[c]->vel.v[2];
    }

    crates[c]->hitbox.shape.aabb = (AABB){{{crates[c]->pos.v[0] - 32.0f, crates[c]->pos.v[1], crates[c]->pos.v[2] - 32.0f}},
                                         {{crates[c]->pos.v[0] + 32.0f, crates[c]->pos.v[1] + 64.0f, crates[c]->pos.v[2] + 32.0f}}};
  }

}


void actors_update(void){
  crates_update();
}
