#include <z64hdr.h>
#include "code/z_player_lib.h"
#include "playas/playas.h"
#include "uLib.h"
#include "z64camera.h"
#include "z64player.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

Gfx* gPlayerLeftHandMasterDLs[] = {
    // Master Sword (Pedestal)
    gPlayAsDl_Adult_FistL,
    gPlayAsLUT_Child_SwordPedestalFistL,
    gPlayAsDl_Adult_FistL,
    gPlayAsLUT_Child_SwordPedestalFistL,
};