#include <libdragon.h>
#include "../include/enums.h"
#include "../include/globals.h"
#include "sound.h"

char *xm_fn = NULL;
xm64player_t xm;
wav64_t title, sfx_jump, sfx_attack, sfx_bounce, sfx_boing, attack1, attack2, attack3, attack4, air, metal, handgun, door, squirt, foot;

// Configure depending on number of channels in xm



const char* xmFileNames[10] = {
    "rom:/sound/Moutain-Crawl.xm64",
    "rom:/sound/Anger_of_The_Guardians.xm64",
    "rom:/sound/The_Cosmic_Goddess.xm64",
    "rom:/sound/Master-Sword.xm64",
    "rom:/sound/ene.xm64",
    "rom:/sound/Floating-Down.xm64",
    "rom:/sound/hand-over-hand.xm64",
    "rom:/sound/Systematic.xm64",
    "rom:/sound/turned-around.xm64",
    "rom:/sound/deepcode.xm64",
};

void sound_load(void) {
	xm64player_open(&xm, xmFileNames[0]);
	wav64_open(&title, "rom:/sound/戦士の帰還.wav64");
	wav64_open(&sfx_jump, "rom:/sound/Aria_Jump.wav64");
	wav64_open(&sfx_attack, "rom:/sound/attack.wav64");
	wav64_open(&sfx_bounce, "rom:/sound/bounce.wav64");
	wav64_open(&sfx_boing, "rom:/sound/boing.wav64");
	wav64_open(&attack1, "rom:/sound/Aria_1.wav64");
  	wav64_open(&attack2, "rom:/sound/Aria_2.wav64");
  	wav64_open(&attack3, "rom:/sound/Aria_3.wav64");
 	wav64_open(&attack4, "rom:/sound/Aria_4.wav64");
	wav64_open(&air, "rom:/sound/air_flowing.wav64");
 	wav64_open(&metal, "rom:/sound/metal_clank.wav64");
	wav64_open(&handgun, "rom:/sound/HandGun.wav64");
	wav64_open(&door, "rom:/sound/door_close.wav64");
	wav64_open(&squirt, "rom:/sound/gore.wav64");
	wav64_open(&foot, "rom:/sound/grass.wav64");

}

void sound_init(void) {
	audio_init(48000, 4);
	mixer_init(NUM_CHANNELS+29); // sfx1, sfx 2, and music channel + 29 for 32 max
	sound_load();
}
void xm_init(void){
   	xm64player_set_loop(&xm, true);
   	xm64player_set_vol(&xm, 1.0f);
   	xm64player_play(&xm, MUSIC_CHANNEL);
}
void switch_xm(int songID){
	xm64player_close(&xm);
	xm64player_open(&xm, xmFileNames[songID]);
	xm64player_set_loop(&xm, true);
	xm64player_set_vol(&xm, 0.3f);
	xm64player_play(&xm, MUSIC_CHANNEL);
}

void sound_update_buffer(void) {
    if (audio_can_write()) {
		short *buf = audio_write_begin();
		mixer_poll(buf, audio_get_buffer_length());
		audio_write_end();
	}
}

void title_theme(void){
	wav64_play(&title, SFX1);
	mixer_try_play();
}

void sound_bounce(void){
	wav64_play(&sfx_bounce, SFX1);
	wav64_play(&sfx_boing, SFX2);
	mixer_try_play();
}

void sound_clank(void){
	if(!mixer_ch_playing(SFX1))wav64_play(&metal, SFX1);
	mixer_try_play();
}

void sound_handgun(void){
	wav64_play(&handgun, SFX1);
	mixer_try_play();
}

void sound_air(void){
	wav64_play(&air, SFX1);
	mixer_try_play();
}

void sound_jump(void){
	wav64_play(&sfx_jump, SFX1);
	mixer_try_play();
}

void sound_door(void){
	wav64_play(&door, SFX1);
	mixer_try_play();
}

void sound_squirt(void){
	wav64_play(&squirt, SFX1);
	mixer_try_play();
}

void sound_foot(void){
	wav64_play(&foot, SFX1);
	mixer_try_play();
}

static wav64_t* attacknoise[] = { &attack1, &attack2, &attack3, &attack4 };

void sound_attack(void){
	int n = rand() % 4;
	wav64_play(attacknoise[n], SFX2);
	mixer_try_play();
}
