#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3dmodel.h>
#include "../include/enums.h"
#include "../include/types.h"
#include "debug.h"
#include "collision.h"
#include "lvl2.h"
#include "utils.h"

T3DMat4FP* lvl2MatFP;
T3DModel *modelLvl2;
rspq_block_t *dplLvl2;

T3DVec3 lvl2Verts[31] =
{
    {{-102, 50, -145}},
    {{-102, 193, -145}},
    {{-102, 193, -219}},
    {{-102, 50, -219}},
    {{-297, 50, -71}},
    {{-297, 193, -71}},
    {{-297, 193, 3}},
    {{-297, 50, 3}},
    {{-102, 193, -293}},
    {{-102, 50, -293}},
    {{-297, 50, -145}},
    {{-297, 193, -145}},
    {{-102, 50, 3}},
    {{-102, 193, 3}},
    {{-102, 193, -71}},
    {{-102, 50, -71}},
    {{-200, 50, -293}},
    {{-200, 193, -293}},
    {{-297, 193, -293}},
    {{-297, 50, -293}},
    {{-200, 193, 3}},
    {{-200, 50, 3}},
    {{-297, 50, -219}},
    {{-297, 193, -219}},
    {{-490, 466, -145}},
    {{-490, 466, -251}},
    {{-630, 466, -251}},
    {{-630, 466, -145}},
    {{-200, 50, -71}},
    {{-200, 50, -219}},
    {{-200, 50, -145}},
};


int lvl2WallCount = 24;
Surface* lvl2Wall;

int lvl2SlopeCount = 2;
Surface* lvl2Slope;

int lvl2FloorCount = 16;
Surface* lvl2Floor;

int lvl2SurfacesCount = 0;
Surface* lvl2Surfaces;

void lvl2_init(void){
    lvl2Wall = malloc(lvl2WallCount * sizeof(Surface));
    lvl2Slope = malloc(lvl2SlopeCount * sizeof(Surface));
    lvl2Floor = malloc(lvl2FloorCount * sizeof(Surface));
    lvl2Surfaces = malloc((lvl2WallCount + lvl2SlopeCount + lvl2FloorCount) * sizeof(Surface));

    lvl2Wall[0].posA = lvl2Verts[0]; lvl2Wall[0].posB = lvl2Verts[1]; lvl2Wall[0].posC = lvl2Verts[2];
    lvl2Wall[1].posA = lvl2Verts[0]; lvl2Wall[1].posB = lvl2Verts[2]; lvl2Wall[1].posC = lvl2Verts[3];
    lvl2Wall[2].posA = lvl2Verts[4]; lvl2Wall[2].posB = lvl2Verts[5]; lvl2Wall[2].posC = lvl2Verts[6];
    lvl2Wall[3].posA = lvl2Verts[4]; lvl2Wall[3].posB = lvl2Verts[6]; lvl2Wall[3].posC = lvl2Verts[7];
    lvl2Wall[4].posA = lvl2Verts[3]; lvl2Wall[4].posB = lvl2Verts[2]; lvl2Wall[4].posC = lvl2Verts[8];
    lvl2Wall[5].posA = lvl2Verts[3]; lvl2Wall[5].posB = lvl2Verts[8]; lvl2Wall[5].posC = lvl2Verts[9];
    lvl2Wall[6].posA = lvl2Verts[10]; lvl2Wall[6].posB = lvl2Verts[11]; lvl2Wall[6].posC = lvl2Verts[5];
    lvl2Wall[7].posA = lvl2Verts[10]; lvl2Wall[7].posB = lvl2Verts[5]; lvl2Wall[7].posC = lvl2Verts[4];
    lvl2Wall[8].posA = lvl2Verts[12]; lvl2Wall[8].posB = lvl2Verts[13]; lvl2Wall[8].posC = lvl2Verts[14];
    lvl2Wall[9].posA = lvl2Verts[12]; lvl2Wall[9].posB = lvl2Verts[14]; lvl2Wall[9].posC = lvl2Verts[15];
    lvl2Wall[10].posA = lvl2Verts[16]; lvl2Wall[10].posB = lvl2Verts[17]; lvl2Wall[10].posC = lvl2Verts[18];
    lvl2Wall[11].posA = lvl2Verts[16]; lvl2Wall[11].posB = lvl2Verts[18]; lvl2Wall[11].posC = lvl2Verts[19];
    lvl2Wall[12].posA = lvl2Verts[7]; lvl2Wall[12].posB = lvl2Verts[6]; lvl2Wall[12].posC = lvl2Verts[20];
    lvl2Wall[13].posA = lvl2Verts[7]; lvl2Wall[13].posB = lvl2Verts[20]; lvl2Wall[13].posC = lvl2Verts[21];
    lvl2Wall[14].posA = lvl2Verts[22]; lvl2Wall[14].posB = lvl2Verts[23]; lvl2Wall[14].posC = lvl2Verts[11];
    lvl2Wall[15].posA = lvl2Verts[22]; lvl2Wall[15].posB = lvl2Verts[11]; lvl2Wall[15].posC = lvl2Verts[10];
    lvl2Wall[16].posA = lvl2Verts[9]; lvl2Wall[16].posB = lvl2Verts[8]; lvl2Wall[16].posC = lvl2Verts[17];
    lvl2Wall[17].posA = lvl2Verts[9]; lvl2Wall[17].posB = lvl2Verts[17]; lvl2Wall[17].posC = lvl2Verts[16];
    lvl2Wall[18].posA = lvl2Verts[19]; lvl2Wall[18].posB = lvl2Verts[18]; lvl2Wall[18].posC = lvl2Verts[23];
    lvl2Wall[19].posA = lvl2Verts[19]; lvl2Wall[19].posB = lvl2Verts[23]; lvl2Wall[19].posC = lvl2Verts[22];
    lvl2Wall[20].posA = lvl2Verts[21]; lvl2Wall[20].posB = lvl2Verts[20]; lvl2Wall[20].posC = lvl2Verts[13];
    lvl2Wall[21].posA = lvl2Verts[21]; lvl2Wall[21].posB = lvl2Verts[13]; lvl2Wall[21].posC = lvl2Verts[12];
    lvl2Wall[22].posA = lvl2Verts[15]; lvl2Wall[22].posB = lvl2Verts[14]; lvl2Wall[22].posC = lvl2Verts[1];
    lvl2Wall[23].posA = lvl2Verts[15]; lvl2Wall[23].posB = lvl2Verts[1]; lvl2Wall[23].posC = lvl2Verts[0];
    lvl2Slope[0].posA = lvl2Verts[24]; lvl2Slope[0].posB = lvl2Verts[25]; lvl2Slope[0].posC = lvl2Verts[26];
    lvl2Slope[1].posA = lvl2Verts[24]; lvl2Slope[1].posB = lvl2Verts[26]; lvl2Slope[1].posC = lvl2Verts[27];
    lvl2Floor[0].posA = lvl2Verts[7]; lvl2Floor[0].posB = lvl2Verts[21]; lvl2Floor[0].posC = lvl2Verts[28];
    lvl2Floor[1].posA = lvl2Verts[7]; lvl2Floor[1].posB = lvl2Verts[28]; lvl2Floor[1].posC = lvl2Verts[4];
    lvl2Floor[2].posA = lvl2Verts[22]; lvl2Floor[2].posB = lvl2Verts[29]; lvl2Floor[2].posC = lvl2Verts[16];
    lvl2Floor[3].posA = lvl2Verts[22]; lvl2Floor[3].posB = lvl2Verts[16]; lvl2Floor[3].posC = lvl2Verts[19];
    lvl2Floor[4].posA = lvl2Verts[21]; lvl2Floor[4].posB = lvl2Verts[12]; lvl2Floor[4].posC = lvl2Verts[15];
    lvl2Floor[5].posA = lvl2Verts[21]; lvl2Floor[5].posB = lvl2Verts[15]; lvl2Floor[5].posC = lvl2Verts[28];
    lvl2Floor[6].posA = lvl2Verts[28]; lvl2Floor[6].posB = lvl2Verts[15]; lvl2Floor[6].posC = lvl2Verts[0];
    lvl2Floor[7].posA = lvl2Verts[28]; lvl2Floor[7].posB = lvl2Verts[0]; lvl2Floor[7].posC = lvl2Verts[30];
    lvl2Floor[8].posA = lvl2Verts[30]; lvl2Floor[8].posB = lvl2Verts[0]; lvl2Floor[8].posC = lvl2Verts[3];
    lvl2Floor[9].posA = lvl2Verts[30]; lvl2Floor[9].posB = lvl2Verts[3]; lvl2Floor[9].posC = lvl2Verts[29];
    lvl2Floor[10].posA = lvl2Verts[29]; lvl2Floor[10].posB = lvl2Verts[3]; lvl2Floor[10].posC = lvl2Verts[9];
    lvl2Floor[11].posA = lvl2Verts[29]; lvl2Floor[11].posB = lvl2Verts[9]; lvl2Floor[11].posC = lvl2Verts[16];
    lvl2Floor[12].posA = lvl2Verts[4]; lvl2Floor[12].posB = lvl2Verts[28]; lvl2Floor[12].posC = lvl2Verts[30];
    lvl2Floor[13].posA = lvl2Verts[4]; lvl2Floor[13].posB = lvl2Verts[30]; lvl2Floor[13].posC = lvl2Verts[10];
    lvl2Floor[14].posA = lvl2Verts[30]; lvl2Floor[14].posB = lvl2Verts[29]; lvl2Floor[14].posC = lvl2Verts[22];
    lvl2Floor[15].posA = lvl2Verts[30]; lvl2Floor[15].posB = lvl2Verts[22]; lvl2Floor[15].posC = lvl2Verts[10];

    for (int i = 0; i < lvl2WallCount; i++) {
        lvl2Wall[i].type = SURFACE_WALL;
        lvl2Wall[i].center = center;
        lvl2Wall[i].normal = norm;
        lvl2Wall[i].center = calc_surface_center(lvl2Wall[i]);
        lvl2Wall[i].normal = calc_surface_norm(lvl2Wall[i]);
    }

    for (int i = 0; i < lvl2SlopeCount; i++) {
        lvl2Slope[i].type = SURFACE_SLOPE;
        lvl2Slope[i].center = center;
        lvl2Slope[i].normal = norm;
        lvl2Slope[i].center = calc_surface_center(lvl2Slope[i]);
        lvl2Slope[i].normal = calc_surface_norm(lvl2Slope[i]);
    }

    for (int i = 0; i < lvl2FloorCount; i++) {
        lvl2Floor[i].type = SURFACE_FLOOR;
        lvl2Floor[i].center = center;
        lvl2Floor[i].normal = norm;
        lvl2Floor[i].center = calc_surface_center(lvl2Floor[i]);
        lvl2Floor[i].normal = calc_surface_norm(lvl2Floor[i]);
    }

    // Combine the surfaces for collision detection
    combine_surfaces(
       lvl2Surfaces, &lvl2SurfacesCount,
       lvl2Wall, lvl2WallCount,
       lvl2Slope, lvl2SlopeCount,
       lvl2Floor, lvl2FloorCount
    );

    // Allocate map's matrix and construct
    lvl2MatFP = malloc_uncached(sizeof(T3DMat4FP));
    t3d_mat4fp_from_srt_euler(lvl2MatFP, (float[3]){1.0f, 1.0f, 1.0f}, (float[3]){0, 0, 0}, (float[3]){0, 0, 0});

    // Load model
    modelLvl2 = t3d_model_load("rom:/lvl_2.t3dm");

    // Create map's RSPQ block
    rspq_block_begin();
        t3d_matrix_push(lvl2MatFP);
        matCount++;
        rdpq_set_prim_color(WHITE);
        t3d_model_draw(modelLvl2);
        t3d_matrix_pop(1);
    dplLvl2 = rspq_block_end();
}
