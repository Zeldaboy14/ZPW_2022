#include "ultra64.h"
#include "z64.h"
#include "macros.h"

Vtx gLinkMaskVtx[] = {
#include "gLinkMaskVtx.vtx.inc"
};

Vtx gameplay_keepVtx_003DD0[] = {
#include "gameplay_keepVtx_003DD0.vtx.inc"
};

u64 gLinkMaskTLUT[] = {
#include "link_mask_tlut.rgba16.inc"
};

u64 gGoronMaskTLUT[] = {
#include "goron_mask_tlut.rgba16.inc"
};

u64 gZoraMaskTLUT[] = {
#include "zora_mask_tlut.rgba16.inc"
};

u64 gGoronMaskMouthTex[] = {
#include "goron_mask_mouth.ci8.inc"
};

u64 gGoronMaskInsideEyeTex[] = {
#include "goron_mask_inside_eye.ci8.inc"
};

u64 gGoronMaskNoseEyebrowTex[] = {
#include "goron_mask_nose_eyebrow.ci8.inc"
};

u64 gGoronMaskHairTex[] = {
#include "goron_mask_hair.ci8.inc"
};

u64 gGoronMaskEyeTex[] = {
#include "goron_mask_eye.rgba32.inc"
};

u64 gDekuMaskEyeTex[] = {
#include "deku_mask_eye.rgba16.inc"
};

u64 gDekuMaskFaceTex[] = {
#include "deku_mask_face.rgba16.inc"
};

u64 gDekuMaskHairTex[] = {
#include "deku_mask_hair.rgba16.inc"
};

u64 gZoraMaskInsideEyeTex[] = {
#include "zora_mask_inside_eye.ci8.inc"
};

u64 gZoraMaskMouthTex[] = {
#include "zora_mask_mouth.ci8.inc"
};

u64 gZoraMaskNoseTex[] = {
#include "zora_mask_nose.ci8.inc"
};

u64 gZoraMaskSpotsTex[] = {
#include "zora_mask_spots.ci8.inc"
};

u64 gZoraMaskEyeTex[] = {
#include "zora_mask_eye.i8.inc"
};

u8 gameplay_keep_possiblePadding_00A938[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_keepVtx_00A940[] = {
#include "gameplay_keepVtx_00A940.vtx.inc"
};

u64 gFierceDeityMaskTLUT[] = {
#include "fierce_deity_mask_tlut.rgba16.inc"
};

u64 gFierceDeityMaskHairTex[] = {
#include "fierce_deity_mask_hair.ci8.inc"
};

u64 gFierceDeityMaskEyesTex[] = {
#include "fierce_deity_mask_eyes.ci8.inc"
};

u64 gFierceDeityMaskMouthTex[] = {
#include "fierce_deity_mask_mouth.ci8.inc"
};

u64 gFierceDeityMaskEarTex[] = {
#include "fierce_deity_mask_ear.ci8.inc"
};

u64 gFierceDeityMaskHatTex[] = {
#include "fierce_deity_mask_hat.rgba16.inc"
};

Gfx gZoraMaskDL[] = {
	gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gZoraMaskTLUT),
    gsDPLoadTextureBlock(gZoraMaskInsideEyeTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_keepVtx_003DD0[282], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 1, 0, 0, 3, 5, 6, 0),
    gsSP2Triangles(2, 7, 0, 0, 8, 9, 10, 0),
    gsSP2Triangles(4, 10, 1, 0, 11, 10, 4, 0),
    gsSP2Triangles(8, 12, 9, 0, 10, 11, 8, 0),
    gsSP2Triangles(13, 9, 14, 0, 14, 9, 12, 0),
    gsSP2Triangles(10, 9, 3, 0, 3, 1, 10, 0),
    gsSP2Triangles(9, 5, 3, 0, 14, 15, 13, 0),
    gsSP2Triangles(16, 17, 18, 0, 3, 19, 20, 0),
    gsSP2Triangles(21, 22, 3, 0, 3, 20, 21, 0),
    gsSP2Triangles(23, 20, 24, 0, 24, 20, 13, 0),
    gsSP2Triangles(25, 26, 21, 0, 20, 23, 25, 0),
    gsSP2Triangles(27, 21, 26, 0, 22, 21, 27, 0),
    gsSP2Triangles(21, 20, 25, 0, 28, 7, 2, 0),
    gsSP2Triangles(29, 19, 3, 0, 28, 22, 27, 0),
    gsSP2Triangles(3, 22, 2, 0, 2, 22, 28, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gZoraMaskTLUT),
    gsDPLoadTextureBlock(gZoraMaskMouthTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[312], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(0, 4, 5, 0, 5, 1, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gZoraMaskTLUT),
    gsDPLoadTextureBlock(gZoraMaskNoseTex, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[318], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gZoraMaskTLUT),
    gsDPLoadTextureBlock(gZoraMaskSpotsTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[322], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 8, 7, 0, 11, 12, 13, 0),
    gsDPSetAlphaCompare(G_AC_THRESHOLD),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_ZB_XLU_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gZoraMaskEyeTex, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_keepVtx_003DD0[336], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(1, 4, 2, 0, 2, 5, 6, 0),
    gsSP2Triangles(7, 8, 2, 0, 2, 6, 7, 0),
    gsDPPipeSync(),
    gsDPSetAlphaCompare(G_AC_NONE),
    gsSPEndDisplayList(),
};

Gfx gDekuMaskDL[] = {
	gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gDekuMaskEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_keepVtx_003DD0[99], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(4, 3, 2, 0, 2, 5, 4, 0),
    gsSP2Triangles(6, 5, 2, 0, 1, 6, 2, 0),
    gsSP2Triangles(7, 6, 1, 0, 7, 8, 6, 0),
    gsSP2Triangles(9, 8, 7, 0, 7, 10, 9, 0),
    gsSP2Triangles(7, 11, 10, 0, 7, 1, 11, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPLoadTextureBlock(gDekuMaskFaceTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_keepVtx_003DD0[111], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(0, 4, 3, 0, 3, 5, 1, 0),
    gsSP2Triangles(5, 6, 1, 0, 0, 7, 4, 0),
    gsSP2Triangles(8, 9, 10, 0, 9, 11, 10, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
    gsSP2Triangles(10, 16, 17, 0, 10, 11, 16, 0),
    gsSP2Triangles(16, 18, 17, 0, 18, 19, 17, 0),
    gsSP2Triangles(20, 18, 21, 0, 20, 19, 18, 0),
    gsSP2Triangles(20, 21, 22, 0, 21, 23, 22, 0),
    gsSP2Triangles(22, 24, 25, 0, 22, 23, 24, 0),
    gsSP2Triangles(24, 13, 25, 0, 13, 15, 25, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 27, 26, 0),
    gsSPVertex(&gameplay_keepVtx_003DD0[141], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 5, 0, 8, 9, 2, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 5, 7, 0),
    gsSP2Triangles(7, 14, 13, 0, 12, 2, 10, 0),
    gsSP2Triangles(10, 15, 11, 0, 14, 16, 13, 0),
    gsSP2Triangles(17, 10, 2, 0, 18, 5, 13, 0),
    gsSP2Triangles(19, 18, 13, 0, 17, 20, 10, 0),
    gsSP2Triangles(10, 20, 15, 0, 21, 15, 22, 0),
    gsSP2Triangles(23, 16, 24, 0, 23, 25, 26, 0),
    gsSP2Triangles(27, 15, 21, 0, 26, 16, 23, 0),
    gsSP2Triangles(22, 28, 21, 0, 29, 30, 31, 0),
    gsSPVertex(&gameplay_keepVtx_003DD0[173], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 3, 5, 0),
    gsSP2Triangles(0, 14, 1, 0, 9, 8, 15, 0),
    gsSP2Triangles(15, 16, 17, 0, 9, 1, 7, 0),
    gsSP2Triangles(1, 14, 7, 0, 18, 19, 20, 0),
    gsSP2Triangles(21, 22, 23, 0, 24, 25, 26, 0),
    gsSP2Triangles(27, 28, 29, 0, 19, 30, 27, 0),
    gsSP2Triangles(23, 19, 27, 0, 19, 18, 30, 0),
    gsSPVertex(&gameplay_keepVtx_003DD0[204], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 1, 0, 0),
    gsSP2Triangles(2, 1, 4, 0, 10, 11, 12, 0),
    gsSP2Triangles(13, 14, 15, 0, 16, 17, 18, 0),
    gsSP2Triangles(15, 19, 20, 0, 16, 21, 13, 0),
    gsSP2Triangles(13, 15, 20, 0, 21, 14, 13, 0),
    gsSP2Triangles(0, 2, 22, 0, 23, 24, 8, 0),
    gsSP2Triangles(25, 17, 16, 0, 10, 12, 26, 0),
    gsSP1Triangle(27, 20, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gDekuMaskHairTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[232], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 6, 7, 5, 0),
    gsSP2Triangles(6, 8, 7, 0, 6, 9, 8, 0),
    gsSP2Triangles(9, 10, 8, 0, 11, 12, 13, 0),
    gsSP2Triangles(11, 13, 14, 0, 15, 16, 14, 0),
    gsSP2Triangles(16, 11, 14, 0, 15, 14, 17, 0),
    gsSP2Triangles(15, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(19, 22, 20, 0, 23, 24, 22, 0),
    gsSP2Triangles(19, 23, 22, 0, 24, 25, 22, 0),
    gsSP2Triangles(24, 12, 25, 0, 26, 10, 27, 0),
    gsSP2Triangles(28, 26, 27, 0, 28, 27, 29, 0),
    gsSP2Triangles(28, 29, 30, 0, 31, 28, 30, 0),
    gsSPVertex(&gameplay_keepVtx_003DD0[264], 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 6, 7, 4, 0),
    gsSP2Triangles(7, 8, 4, 0, 7, 9, 8, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 10, 12, 0),
    gsSP2Triangles(13, 14, 15, 0, 13, 12, 14, 0),
    gsSP2Triangles(16, 13, 15, 0, 17, 16, 15, 0),
    gsSPEndDisplayList(),
};

Gfx gGoronMaskDL[] = {
	gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gGoronMaskTLUT),
    gsDPLoadTextureBlock(gGoronMaskMouthTex, G_IM_FMT_CI, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_keepVtx_003DD0, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 2, 0, 8, 9, 10, 0),
    gsSP2Triangles(5, 11, 12, 0, 5, 13, 11, 0),
    gsSP2Triangles(8, 14, 9, 0, 15, 16, 8, 0),
    gsSP2Triangles(8, 16, 14, 0, 17, 5, 9, 0),
    gsSP2Triangles(18, 19, 20, 0, 19, 15, 20, 0),
    gsSP2Triangles(3, 21, 22, 0, 13, 5, 4, 0),
    gsSP2Triangles(5, 17, 3, 0, 23, 22, 24, 0),
    gsSP2Triangles(2, 1, 25, 0, 2, 7, 0, 0),
    gsSP2Triangles(24, 22, 21, 0, 23, 24, 26, 0),
    gsSP2Triangles(27, 9, 14, 0, 28, 29, 30, 0),
    gsSPVertex(&gameplay_keepVtx_003DD0[31], 29, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 8, 0),
    gsSP2Triangles(5, 4, 11, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 14, 16, 0, 4, 3, 12, 0),
    gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
    gsSP2Triangles(21, 14, 13, 0, 22, 23, 24, 0),
    gsSP2Triangles(24, 23, 18, 0, 21, 22, 24, 0),
    gsSP2Triangles(25, 16, 14, 0, 26, 25, 14, 0),
    gsSP2Triangles(27, 21, 24, 0, 8, 7, 28, 0),
    gsSP2Triangles(14, 15, 12, 0, 8, 10, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gGoronMaskTLUT),
    gsDPLoadTextureBlock(gGoronMaskInsideEyeTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[60], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(0, 4, 1, 0, 5, 6, 7, 0),
    gsSP2Triangles(7, 8, 0, 0, 5, 7, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gGoronMaskTLUT),
    gsDPLoadTextureBlock(gGoronMaskNoseEyebrowTex, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[69], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 7, 8, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gGoronMaskTLUT),
    gsDPLoadTextureBlock(gGoronMaskHairTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_003DD0[78], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(2, 4, 0, 0, 5, 6, 7, 0),
    gsSP2Triangles(8, 6, 5, 0, 9, 4, 2, 0),
    gsSP2Triangles(9, 10, 11, 0, 2, 10, 9, 0),
    gsDPSetAlphaCompare(G_AC_THRESHOLD),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_ZB_XLU_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGoronMaskEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_32b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_keepVtx_003DD0[90], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(0, 4, 1, 0, 5, 6, 7, 0),
    gsSP2Triangles(7, 8, 0, 0, 5, 7, 0, 0),
    gsDPPipeSync(),
    gsDPSetAlphaCompare(G_AC_NONE),
    gsSPEndDisplayList(),
};

Gfx gFierceDeityMaskDL[] = {
	gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gFierceDeityMaskTLUT),
    gsDPLoadTextureBlock(gFierceDeityMaskHairTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_keepVtx_00A940, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 7, 3, 5, 0),
    gsSP2Triangles(7, 8, 3, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(16, 18, 19, 0, 15, 18, 16, 0),
    gsSP2Triangles(15, 8, 20, 0, 21, 8, 15, 0),
    gsSP2Triangles(22, 4, 6, 0, 13, 23, 14, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 25, 24, 0),
    gsSP2Triangles(27, 28, 25, 0, 20, 8, 7, 0),
    gsSP2Triangles(29, 9, 30, 0, 31, 14, 23, 0),
    gsSPVertex(&gameplay_keepVtx_00A940[32], 26, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 5, 0, 6, 7, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 10, 12, 11, 0),
    gsSP2Triangles(9, 8, 7, 0, 13, 9, 7, 0),
    gsSP2Triangles(14, 3, 15, 0, 4, 16, 17, 0),
    gsSP2Triangles(18, 16, 4, 0, 18, 19, 16, 0),
    gsSP2Triangles(15, 3, 1, 0, 20, 3, 14, 0),
    gsSP2Triangles(11, 21, 9, 0, 22, 23, 15, 0),
    gsSP2Triangles(13, 10, 9, 0, 5, 24, 2, 0),
    gsSP1Triangle(9, 25, 8, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gFierceDeityMaskTLUT),
    gsDPLoadTextureBlock(gFierceDeityMaskEyesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_00A940[58], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 6, 5, 0),
    gsSP2Triangles(9, 10, 1, 0, 1, 11, 9, 0),
    gsSP2Triangles(1, 4, 11, 0, 4, 12, 11, 0),
    gsSP2Triangles(1, 13, 14, 0, 15, 13, 1, 0),
    gsSP2Triangles(16, 13, 15, 0, 15, 10, 16, 0),
    gsSP2Triangles(1, 10, 15, 0, 17, 1, 14, 0),
    gsSP2Triangles(2, 1, 17, 0, 18, 2, 17, 0),
    gsSP2Triangles(19, 20, 21, 0, 21, 22, 19, 0),
    gsSP2Triangles(22, 23, 19, 0, 22, 21, 24, 0),
    gsSP2Triangles(19, 25, 20, 0, 20, 26, 21, 0),
    gsSP2Triangles(27, 13, 16, 0, 16, 10, 28, 0),
    gsSP2Triangles(27, 29, 13, 0, 13, 29, 14, 0),
    gsSP2Triangles(14, 29, 30, 0, 30, 17, 14, 0),
    gsSP2Triangles(30, 18, 17, 0, 18, 30, 31, 0),
    gsSP2Triangles(20, 25, 31, 0, 25, 18, 31, 0),
    gsSPVertex(&gameplay_keepVtx_00A940[90], 23, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 4, 6, 0),
    gsSP2Triangles(8, 9, 10, 0, 10, 11, 8, 0),
    gsSP2Triangles(12, 11, 10, 0, 12, 13, 11, 0),
    gsSP2Triangles(13, 12, 14, 0, 12, 15, 14, 0),
    gsSP2Triangles(16, 10, 9, 0, 16, 9, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 18, 20, 0),
    gsSP1Triangle(14, 15, 22, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gFierceDeityMaskTLUT),
    gsDPLoadTextureBlock(gFierceDeityMaskMouthTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_00A940[113], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 4, 0),
    gsSP2Triangles(1, 0, 3, 0, 1, 3, 5, 0),
    gsSP2Triangles(6, 5, 3, 0, 3, 4, 6, 0),
    gsSP1Triangle(6, 7, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gFierceDeityMaskTLUT),
    gsDPLoadTextureBlock(gFierceDeityMaskEarTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_00A940[121], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(0, 4, 1, 0, 5, 6, 7, 0),
    gsSP2Triangles(7, 8, 9, 0, 9, 5, 7, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gFierceDeityMaskHatTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_keepVtx_00A940[131], 15, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 6, 8, 0),
    gsSP2Triangles(6, 5, 8, 0, 0, 5, 4, 0),
    gsSP2Triangles(0, 4, 9, 0, 5, 0, 2, 0),
    gsSP2Triangles(0, 9, 3, 0, 8, 5, 2, 0),
    gsSP2Triangles(10, 7, 8, 0, 11, 10, 8, 0),
    gsSP2Triangles(2, 11, 8, 0, 12, 3, 9, 0),
    gsSP2Triangles(7, 10, 13, 0, 4, 6, 14, 0),
    gsSPEndDisplayList(),
};

Vtx object_stkVtx_006120[] = {
#include "object_stk/object_stkVtx_006120.vtx.inc"
};

u64 gSkullKidMajorasMaskFaceTex[] = {
#include "object_stk/skull_kid_majoras_mask_face.rgba16.inc"
};

u64 gSkullKidMajorasMaskSpikes1Tex[] = {
#include "object_stk/skull_kid_majoras_mask_spikes_1.rgba16.inc"
};

u64 gSkullKidMajorasMaskSpikes2Tex[] = {
#include "object_stk/skull_kid_majoras_mask_spikes_2.rgba16.inc"
};

u64 gSkullKidMajorasMaskSpikes3Tex[] = {
#include "object_stk/skull_kid_majoras_mask_spikes_3.rgba16.inc"
};

u64 gSkullKidMajorasMaskSpikes4Tex[] = {
#include "object_stk/skull_kid_majoras_mask_spikes_4.rgba16.inc"
};

u64 gSkullKidMajorasMaskBackTex[] = {
#include "object_stk/skull_kid_majoras_mask_back.rgba16.inc"
};

Vtx object_stkVtx_006F60[] = {
#include "object_stk/object_stkVtx_006F60.vtx.inc"
};

Gfx gSkullKidMajorasMaskMatrix[] = {
	gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPEndDisplayList(),
};

Gfx gSkullKidMajorasMask1DL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskFaceTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_stkVtx_006120, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(5, 1, 6, 0, 7, 4, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 1, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(2, 1, 20, 0, 20, 1, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 18, 26, 0),
    gsSP2Triangles(16, 1, 9, 0, 10, 12, 27, 0),
    gsSP2Triangles(6, 1, 15, 0, 13, 23, 22, 0),
    gsSP2Triangles(4, 1, 5, 0, 28, 29, 0, 0),
    gsSP1Triangle(30, 31, 29, 0),
    gsSPVertex(&object_stkVtx_006120[32], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 16, 15, 0, 19, 18, 20, 0),
    gsSP2Triangles(21, 19, 22, 0, 23, 21, 24, 0),
    gsSP2Triangles(25, 23, 9, 0, 26, 27, 28, 0),
    gsSP2Triangles(28, 27, 29, 0, 30, 29, 3, 0),
    gsSP2Triangles(0, 3, 5, 0, 8, 5, 12, 0),
    gsSP2Triangles(6, 12, 14, 0, 15, 20, 18, 0),
    gsSP2Triangles(29, 30, 28, 0, 20, 15, 31, 0),
    gsSPVertex(&object_stkVtx_006120[64], 21, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 3, 6, 0, 7, 8, 2, 0),
    gsSP2Triangles(9, 2, 8, 0, 4, 10, 11, 0),
    gsSP2Triangles(12, 13, 8, 0, 10, 4, 14, 0),
    gsSP2Triangles(15, 8, 13, 0, 11, 16, 17, 0),
    gsSP2Triangles(17, 18, 12, 0, 10, 19, 16, 0),
    gsSP1Triangle(18, 20, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskSpikes1Tex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[85], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(6, 8, 12, 0, 4, 13, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskSpikes2Tex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[99], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 6, 8, 0, 3, 13, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskSpikes3Tex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[113], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(6, 8, 12, 0, 4, 13, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskSpikes4Tex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[127], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 6, 8, 0, 3, 13, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskSpikes1Tex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[141], 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gSkullKidMajorasMaskBackTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_stkVtx_006120[159], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 0, 9, 6, 0),
    gsSP2Triangles(5, 1, 0, 0, 5, 0, 3, 0),
    gsSP2Triangles(8, 0, 6, 0, 2, 9, 0, 0),
    gsSPEndDisplayList(),
};
	
Gfx gSpookyMask[] = {
	gsSPDisplayList(gSkullKidMajorasMaskMatrix),
    gsSPDisplayList(gSkullKidMajorasMask1DL),
    gsSPEndDisplayList(),
};