#include <libdragon.h>
#include "../include/config.h"
#include "../include/enums.h"
#include "../include/globals.h"
#include "../include/types.h"
#include "debug.h"
#include "input.h"
#include "levels.h"
#include "player.h"
#include "sound.h"
#include "ui.h"
#include "utils.h"

//static sprite_t* blade_icon[] = { &knife, &katana, &dragona};
//static sprite_t* gun_icon[] ={ &beretta, &remington, &acp };
//static sprite_t* outfit_main_icon[] = { &casual, &gi, &armor, &swim,};
//static sprite_t* outfit_sexy_icon[] = { &birthday, &pantieless, &sleep, &weadding };


rspq_block_t *dplScore;
rspq_block_t *dplControls;
rdpq_font_t *font[MAX_NUM_FONTS];
sprite_t *spriteTextWindow;
rdpq_texparms_t textWindowParams = {
    .s.repeats = REPEAT_INFINITE,
    .t.repeats = REPEAT_INFINITE,
};

bool isPaused;
int nextFont = FONT_8BIT_3;
int xmID = 0;
float textX;
float textY;
char* ACTION[MAX_PLAYERS];

void ui_init (void){

    // TODO fontma
    font[1] =  rdpq_font_load("rom:/fonts/abaddon.font64");
    font[2] =  rdpq_font_load("rom:/fonts/8bit0.font64");
    font[3] =  rdpq_font_load("rom:/fonts/8bit1.font64");
    font[4] =  rdpq_font_load("rom:/fonts/8bit2.font64");
    font[5] =  rdpq_font_load("rom:/fonts/8bit3.font64");
    font[6] =  rdpq_font_load("rom:/fonts/8bit4.font64");
    font[7] =  rdpq_font_load("rom:/fonts/8bit5.font64");
    font[8] =  rdpq_font_load("rom:/fonts/at01.font64");
    font[9] =  rdpq_font_load("rom:/fonts/avenuepixel.font64");
    font[10] = rdpq_font_load("rom:/fonts/bitpotion.font64");
    font[11] = rdpq_font_load("rom:/fonts/chunkysans.font64");
    font[12] = rdpq_font_load("rom:/fonts/CyborgSister.font64");
    font[13] = rdpq_font_load("rom:/fonts/divinity.font64");
    font[14] = rdpq_font_load("rom:/fonts/dmsans.font64");
    font[15] = rdpq_font_load("rom:/fonts/droid-sans.font64");
    font[16] = rdpq_font_load("rom:/fonts/EnterCommand.font64");
    font[17] = rdpq_font_load("rom:/fonts/FiraMonoBold.font64");
    font[18] = rdpq_font_load("rom:/fonts/fortzilla.font64");
    font[19] = rdpq_font_load("rom:/fonts/Lato.font64");
    font[20] = rdpq_font_load("rom:/fonts/Liver.font64");
    font[21] = rdpq_font_load("rom:/fonts/m3x6.font64");
    font[22] = rdpq_font_load("rom:/fonts/m5x7.font64");
    font[23] = rdpq_font_load("rom:/fonts/m6x11plus.font64");
    font[24] = rdpq_font_load("rom:/fonts/minimalpixel.font64");
    font[25] = rdpq_font_load("rom:/fonts/monogram.font64");
    font[26] = rdpq_font_load("rom:/fonts/Pacifico.font64");
    font[27] = rdpq_font_load("rom:/fonts/poco.font64");
    font[28] = rdpq_font_load("rom:/fonts/Roboto-Medium.font64");
    font[29] = rdpq_font_load("rom:/fonts/roundabout.font64");
    font[30] = rdpq_font_load("rom:/fonts/Silver.font64");
    font[31] = rdpq_font_load("rom:/fonts/slab.font64");
    font[32] = rdpq_font_load("rom:/fonts/timesplitter.font64");
    font[33] = rdpq_font_load("rom:/fonts/Unbalanced.font64");
    font[34] = rdpq_font_load("rom:/fonts/xolonium.font64");
    font[35] = rdpq_font_load("rom:/fonts/f3dforever.font64");
    font[36] = rdpq_font_load("rom:/fonts/f3dforeverbig.font64");
    font[37] = rdpq_font_load("rom:/fonts/Chiaro.font64");

    for (int i = 1; i < MAX_NUM_FONTS; i++) {
        rdpq_font_style(font[i], STYLE_0, &(rdpq_fontstyle_t){
            .color = WHITE,
            .outline_color = BLACK,
        });
        rdpq_font_style(font[i], STYLE_1, &(rdpq_fontstyle_t){
            .color = GREEN,
            .outline_color = DARK_GREEN,
        });
        rdpq_font_style(font[i], STYLE_2, &(rdpq_fontstyle_t){
            .color = RED,
            .outline_color = DARK_RED,
        });
        rdpq_font_style(font[i], STYLE_3, &(rdpq_fontstyle_t){
            .color = BLACK,
            .outline_color = GREY,
        });
        rdpq_font_style(font[i], STYLE_4, &(rdpq_fontstyle_t){
            .color = BLUE,
            .outline_color = GREY,
        });
        rdpq_font_style(font[i], STYLE_5, &(rdpq_fontstyle_t){
            .color = YELLOW,
            .outline_color = GREY,
        });
        rdpq_font_style(font[i], STYLE_DEBUG, &(rdpq_fontstyle_t){
            .color = WHITE,
            .outline_color = GREY,
        });
        rdpq_font_style(font[i], STYLE_DB_PASS, &(rdpq_fontstyle_t){
            .color = GREEN,
            .outline_color = DARK_GREEN,
        });
        rdpq_font_style(font[i], STYLE_DB_FAIL, &(rdpq_fontstyle_t){
            .color = RED,
            .outline_color = DARK_RED,
        });
    }
    rdpq_text_register_font(FONT_abaddon,       font[1]);
    rdpq_text_register_font(FONT_8BIT_0,        font[2]);
    rdpq_text_register_font(FONT_8BIT_1,        font[3]);
    rdpq_text_register_font(FONT_8BIT_2,        font[4]);
    rdpq_text_register_font(FONT_8BIT_3,        font[5]);
    rdpq_text_register_font(FONT_8BIT_4,        font[6]);
    rdpq_text_register_font(FONT_8BIT_5,        font[7]);
    rdpq_text_register_font(FONT_at01,          font[8]);
    rdpq_text_register_font(FONT_avenuepixel,   font[9]);
    rdpq_text_register_font(FONT_bitpotion,     font[10]);
    rdpq_text_register_font(FONT_chunkysans,    font[11]);
    rdpq_text_register_font(FONT_CyborgSister,  font[12]);
    rdpq_text_register_font(FONT_divinty,       font[13]);
    rdpq_text_register_font(FONT_dmsans,        font[14]);
    rdpq_text_register_font(FONT_droidsans,     font[15]);
    rdpq_text_register_font(FONT_EnterCommand,  font[16]);
    rdpq_text_register_font(FONT_FiraMonoBold,  font[17]);
    rdpq_text_register_font(FONT_fortzilla,     font[18]);
    rdpq_text_register_font(FONT_Lato,          font[19]);
    rdpq_text_register_font(FONT_Liver,         font[20]);
    rdpq_text_register_font(FONT_m3x6,          font[21]);
    rdpq_text_register_font(FONT_m5x7,          font[22]);
    rdpq_text_register_font(FONT_m6x11plus,     font[23]);
    rdpq_text_register_font(FONT_minimalpixel,  font[24]);
    rdpq_text_register_font(FONT_monogram,      font[25]);
    rdpq_text_register_font(FONT_Pacifico,      font[26]);
    rdpq_text_register_font(FONT_poco,          font[27]);
    rdpq_text_register_font(FONT_RobotoMedium,  font[28]);
    rdpq_text_register_font(FONT_roundabout,    font[29]);
    rdpq_text_register_font(FONT_Silver,        font[30]);
    rdpq_text_register_font(FONT_slab,          font[31]);
    rdpq_text_register_font(FONT_timesplitter,  font[32]);
    rdpq_text_register_font(FONT_Unbalanced,    font[33]);
    rdpq_text_register_font(FONT_xolonium,      font[34]);
    rdpq_text_register_font(FONT_f3dforever,    font[35]);
    rdpq_text_register_font(FONT_f3dforeverbig, font[36]);
    rdpq_text_register_font(FONT_chiaro, font[37]);


    isPaused = false;
    spriteTextWindow = sprite_load("rom:/BG0.rgba16.sprite");

    dplScore = NULL;
    dplControls = NULL;
}

void print_score(int fontIdx){
    textX = 12;
    textY = 220;

    // Set up block for score
    if(!dplScore){
        rspq_block_begin();
            rdpq_mode_begin();
                rdpq_sync_pipe();
                rdpq_sync_tile();
                rdpq_set_mode_standard();
                rdpq_mode_combiner(RDPQ_COMBINER1((0,0,0,PRIM), (PRIM,0,TEX0,0)));
                rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);
            rdpq_mode_end();

            //rdpq_set_prim_color(T_BLACK);
            //rdpq_sprite_upload(TILE1, spriteTextWindow, &textWindowParams);

            //rdpq_texture_rectangle(TILE1, textX-2, textY-48, textX+72, textY+4, 0, 0);

        dplScore = rspq_block_end();
    }

    rdpq_textparms_t scoreTextParams = {
        .disable_aa_fix = true,
        .style_id = STYLE_DEBUG,
    };

    rdpq_textparms_t ActionIcon = {
        .disable_aa_fix = false,
        .style_id = STYLE_4,
    };

    rdpq_textparms_t WeaponIcon = {
        .disable_aa_fix = false,
        .style_id = STYLE_1,
    };

    // Run text window block
    rspq_block_run(dplScore);

    // Cap score at 999 to fit with %03d prints
    for(int p = 0; p < numPlayers; ++p){
        if(player[p]->score > 999){
            player[p]->score = 999;
        }
    }


    if(numPlayers > 1) {
        if(numPlayers == 2) {
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY/2, "SPECIAL %03d", player[0]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY-18, "\nSPECIAL %03d", player[1]->score);
        }
        if(numPlayers == 3) {
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY/2, "SPECIAL %03d", player[0]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY-18, "\nSPECIAL %03d", player[1]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, (textX*14)+4,  textY, "SPECIAL %03d", player[2]->score);
        }
        if(numPlayers == 4) {
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY/2, "SPECIAL %03d", player[0]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, (textX*14)+4,  textY/2, "SPECIAL %03d", player[1]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY-18, "\nSPECIAL %03d", player[2]->score);
            rdpq_text_printf(&scoreTextParams, fontIdx, (textX*14)+4, textY, "SPECIAL %03d", player[3]->score);
        }
    } else {
    for(int p = 0; p < numPlayers; ++p){
            switch(actionicon[p]) {
                case roll:
                ACTION[p] = "ROLL     ";
                break;
                case open:
                ACTION[p] = "OPEN     ";
                break;
                case fall:
                ACTION[p] = "FAST FALL";
                break;
                default:
                ACTION[p] = "         ";
                break;
            }

            rdpq_text_printf(&scoreTextParams, fontIdx, textX, textY - 32, "\n""SPECIAL %03d\n", player[0]->score);
            if(!isPaused) {
            rdpq_text_printf(&ActionIcon, FONT_f3dforeverbig, 210, 64, "a");
            rdpq_text_printf(&scoreTextParams, FONT_divinty, 224, 64, "%s", ACTION[0]);
            rdpq_text_printf(&WeaponIcon, FONT_f3dforeverbig, 190, 48, "b");
            }
        }

    }

}

void print_controls(int fontIdx){
    textX  = 97;
    textY = 35;

    // Set up block for score
    if(!dplControls){
        rspq_block_begin();

        rdpq_mode_begin();
            rdpq_sync_pipe();
            rdpq_sync_tile();
            rdpq_set_mode_standard();
            rdpq_mode_combiner(RDPQ_COMBINER1((0,0,0,PRIM), (PRIM,0,TEX0,0)));
            rdpq_mode_blender(RDPQ_BLENDER_MULTIPLY);
        rdpq_mode_end();

        //rdpq_set_prim_color(T_BLACK);
        //rdpq_sprite_upload(TILE1, spriteTextWindow, &textWindowParams);

        // unhardcode?
        //rdpq_texture_rectangle(TILE1, 85, 20, 235, 220, 0, 0);

        rdpq_text_print(&(rdpq_textparms_t){.disable_aa_fix = true, .align= ALIGN_CENTER, .style_id = STYLE_1,},
            fontIdx,
            textX, textY,
            "Far Apart\n"
            "IBE: Itty Bitty Engine\n"
        );
        textX+=3;
        textY+=25;
        rdpq_text_printf(&(rdpq_textparms_t){.disable_aa_fix = true, .style_id = STYLE_1,}, fontIdx, textX+45, textY, "v%.1f.%u", VERSION, VERSION_SUFFIX);
        textY+=10;
        rdpq_text_print(&(rdpq_textparms_t){.disable_aa_fix = true, .style_id = STYLE_2,}, fontIdx, textX+40, textY, "by s4ys");
        /*textY+=15;

        rdpq_text_print(&(rdpq_textparms_t){.width = 125, .style_id = STYLE_0,},
            FONT_divinty,
            textX, textY,
            "     : MOVE\n"
            "     : ACTION\n"
            "     : ATTACK\n"
            "     : NORMAL CAM\n"
            "        : ROTATE FIXED CAM\n"
            "     : TOPDOWN CAM\n"
            "     : RECENTER\n"
            "     : DEBUG / JUMP\n"
            "     : HITBOXES\n"
            "     : CHANGE FONT"
        );

        rdpq_text_print(&(rdpq_textparms_t){.disable_aa_fix = false, .width = 125, .valign = VALIGN_CENTER, .style_id = STYLE_0,},
            FONT_f3dforever,
            textX, textY,
            "0\n"
            "a\n"
            "b\n"
            "u\n"
            "h  k\n"
            "j\n"
            "z\n"
            "r\n"
            "l\n"
            "5\n"
            );*/

        dplControls = rspq_block_end();
    }

    rspq_block_run(dplControls);
}

void ui_update(void){

    if(btn[0].start){
        if(isPaused == false){
            isPaused = true;
        } else {
            isPaused = false;
        }
    }

    if(isPaused){

        if(btn[0].d_left){
            if(nextFont > FONT_RESERVED + 1){
                nextFont--;
            }
        }
        if(btn[0].d_right){
            if(nextFont < MAX_NUM_FONTS - 1){
                nextFont++;
            }
        }
        if(btn[0].d_down){
            if(xmID > 0){
                xmID--;
                switch_xm(xmID);
            }
        }
        if(btn[0].d_up){
            if(xmID < 10){
                xmID++;
                switch_xm(xmID);
            }
        }
        if(btn[0].c_down){
            if(currLevel > 0){
                prevLevel = currLevel;
                currLevel = 0;
                level_free(&levels[prevLevel]);
                level_load(currLevel);
            }
        }
        if(btn[0].c_up){
            if(currLevel < 1){
                prevLevel = currLevel;
                currLevel = 1;
                level_free(&levels[prevLevel]);
                level_load(currLevel);
            }
        }
        print_controls(nextFont);
    } else {
        print_score(nextFont);
        if(numPlayers < 3){
            rdpq_set_mode_fill(RGBA32(0xFF, 0x00, 0x00, 0xFF));
            rdpq_fill_rectangle(
               	30,	// Top-left pixel X coordinate
               	30,	// Top-left pixel Y coordinate
               	30 + (player[0]->health / 2),	// Bottom-right X coordinate
               	35		// Bottom-right Y coordinate
           	);
            if(numPlayers > 1) {
                if(numPlayers == 2) {
                    rdpq_fill_rectangle(
                       	30,	// Top-left pixel X coordinate
                       	150,	// Top-left pixel Y coordinate
                       	30 + (player[1]->health / 2),	// Bottom-right X coordinate
                       	155	// Bottom-right Y coordinate
                   	);
                }
            }
        } else {
            rdpq_text_printf(
               	NULL,	// Font settings, this is default
               	2,		// Font ID number
               	30,		// X position
               	30,		// Y position
               	"P1 LIFE %d",
                player[0]->health
           	);
            rdpq_text_printf(
               	NULL,	// Font settings, this is default
               	2,		// Font ID number
               	30,		// X position
               	40,		// Y position
                "P2 LIFE %d",
                player[1]->health
           	);
            if(numPlayers > 2)
                rdpq_text_printf(
                   	NULL,	// Font settings, this is default
                   	2,		// Font ID number
                   	30,		// X position
                   	50,		// Y position
                    "P3 LIFE %d",
                    player[2]->health
               	);
            if(numPlayers > 3)
                rdpq_text_printf(
                   	NULL,	// Font settings, this is default
                   	2,		// Font ID number
                   	30,		// X position
                   	60,		// Y position
                    "P4 LIFE %d",
                    player[3]->health
               	);
        }
    }
}
