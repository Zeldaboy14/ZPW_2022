#include <z64hdr.h>
#include "code/z_player_lib.h"
#include "playas/playas.h"
#include "uLib.h"
#include "z64camera.h"
#include "z64player.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"
#include "object_fast64/masks/masks_mm.h"
#include "object_fast64/masks/stone/object_mask_stone.h"
#define PLAYER_BOTTLE_EMPTY -1



Gfx* gPlayerShieldsChild[] = {
    gPlayAsLUT_Child_BackShield1, gPlayAsLUT_Child_BackShield1,
    gPlayAsLUT_Child_BackShield2, gPlayAsLUT_Child_BackShield2, 
	gPlayAsLUT_Child_BackShield3, gPlayAsLUT_Child_BackShield3,
};

Gfx* gPlayerShieldsAdult[] = {
    gPlayAsLUT_Adult_BackShield1, gPlayAsLUT_Adult_BackShield1,
    gPlayAsLUT_Adult_BackShield2, gPlayAsLUT_Adult_BackShield2, 
	gPlayAsLUT_Adult_BackShield3, gPlayAsLUT_Adult_BackShield3,
};

Asm_VanillaHook(Player_PostLimbDrawGameplay);
void Player_PostLimbDrawGameplay(PlayState* play, s32 limbIndex, Gfx** dList, Vec3s* rot, void* thisx) {
    Player* this = (Player*)thisx;

    Gfx* hackStringDLists[]= {
        gPlayAsDl_Adult_BowString,
        gPlayAsDl_Adult_SlingshotString,
        gPlayasChild_DlBowString,
        gPlayasChild_DlSlingshotString,
    };

    static Gfx* sChildMaskDlists[PLAYER_MASK_MAX - 1] = {
        object_mask_stone_DL_000820, gSpookyMask, gDekuMaskDL,  gPlayAsDlChildBunnyHoodDL,
        gGoronMaskDL,  gZoraMaskDL,  gPlayAsDlChildGerudoMaskDL,  gPlayAsDlChildMaskOfTruthDL,
    };

    static Gfx* sAdultMaskDlists[PLAYER_MASK_MAX - 1] = {
        gPlayAsDlAdultKeatonMaskDL, gPlayAsDlAdultSkullMaskDL, gPlayAsDlAdultSpookyMaskDL,  gPlayAsDlAdultBunnyHoodDL,
        gPlayAsDlAdultGoronMaskDL,  gPlayAsDlAdultZoraMaskDL,  gPlayAsDlAdultGerudoMaskDL,  gPlayAsDlAdultMaskOfTruthDL,
    };

    Vec3f hackStringPos[] = {
        { 0.0f,  -360.4f, 0.0f }, //Adult Bow
        { 606.0f, 236.0f, 0.0f }, //Slingshot
    };
	
	Vec3f ChildHookshotChainPos = { 50.0f, 800.0f, 0.0f };
	Vec3f ChildHookshotSpikePos = { 50.0f, 850.0f, 0.0f };

    u8 rangedStringPosition = 0;
    u8 rangedStringSelection = 0;

    Camera cam = *Play_GetCamera(play,CAM_ID_MAIN);

    if (*dList != NULL) {
        Matrix_MultVec3f(&sZeroVec, sCurBodyPartPos);
    }

    //hack gauntlet/bracelets not in first person view
    if (CUR_UPG_VALUE(UPG_STRENGTH) != 0 && cam.mode != 6 && cam.mode != 7 && cam.mode != 11){
        DrawGauntletDList(play,this,limbIndex);
    }

    if (limbIndex == PLAYER_LIMB_L_HAND) {
        MtxF sp14C;
        Actor* hookedActor;

        Math_Vec3f_Copy(&this->leftHandPos, sCurBodyPartPos);

        if (this->itemActionParam == PLAYER_AP_STICK) {
            Vec3f sp124[3];

            OPEN_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2633);

            if (this->actor.scale.y >= 0.0f) {
                D_80126080.x = this->unk_85C * 5000.0f;
                func_80090A28(this, sp124);

                if (this->meleeWeaponState != 0) {
                    func_800906D4(play, this, sp124);
                } else {
                    Math_Vec3f_Copy(&this->meleeWeaponInfo[0].tip, &sp124[0]);
                }
            }

            //Shrinking of stick when burning down
            //if (this->unk_85C > 0.5f) {
            //    Matrix_Scale(this->unk_85C, 1.0f, 1.0f, MTXMODE_APPLY);
            //}
			
            Matrix_Translate(-428.26f, 267.2f, -33.82f, MTXMODE_APPLY);
            Matrix_RotateZYX(-0x8000, 0, 0x4000, MTXMODE_APPLY);
            Matrix_Scale(1.0f, this->unk_85C, 1.0f, MTXMODE_APPLY);

            gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(play->state.gfxCtx, "../z_player_lib.c", 2653),
                      G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);

            //Stick Display Lists
            //D_80126080.x = 2500.0f; //Used to assign length manually if changed
            if (LINK_IS_ADULT) {
                if (this->unk_85C > 0.5f) {
                    gSPDisplayList(POLY_OPA_DISP++, gPlayAsDl_Adult_DekuStick);
                } else {
                    gSPDisplayList(POLY_OPA_DISP++, gPlayAsDl_Adult_DekuStickBrokenHeld);
                }

            } else {
                if (this->unk_85C > 0.5f) {
                    gSPDisplayList(POLY_OPA_DISP++, gPlayAsDl_Child_DekuStick);
                } else {
                    gSPDisplayList(POLY_OPA_DISP++, gPlayAsDl_Child_DekuStickBrokenHeld);
                }
            }

            CLOSE_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2656);
        } else if ((this->actor.scale.y >= 0.0f) && (this->meleeWeaponState != 0)) {
            Vec3f spE4[3];

            if (this->heldItemActionParam != PLAYER_AP_STICK){
                if (Player_HoldsBrokenKnife(this)){
                    D_80126080.x = 1500.0f;
                } else {
                    D_80126080.x = sMeleeWeaponLengths[Player_GetMeleeWeaponHeld(this)];
                }
            }

            func_80090A28(this, spE4);
            func_800906D4(play, this, spE4);
        } else if ((*dList != NULL) && (this->leftHandType == PLAYER_MODELTYPE_LH_BOTTLE)) {
            Color_RGB8* bottleColor = &sBottleColors[Player_ActionToBottle(this, this->itemActionParam)];
            int contents = Player_ActionToBottle(this, this->itemActionParam);

            OPEN_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2710);
            
            gSPMatrix(POLY_XLU_DISP++, Matrix_NewMtx(play->state.gfxCtx, "../z_player_lib.c", 2712),
                      G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
            
           if (contents != 0) {
               Color_RGB8* bottleColor = &sBottleColors[contents];
               Gfx* sBottleContentsDLists[] = { gPlayAsDl_Adult_Bottle_Contents, gPlayAsDl_Child_Bottle_Contents };

               gDPSetEnvColor(POLY_XLU_DISP++, bottleColor->r, bottleColor->g, bottleColor->b, 0);
               gSPDisplayList(POLY_XLU_DISP++, sBottleContentsDLists[LINK_IS_CHILD]);
           }

            gDPSetEnvColor(POLY_XLU_DISP++, bottleColor->r, bottleColor->g, bottleColor->b, 0);
            gDPSetEnvColor(POLY_XLU_DISP++, 255, 255, 255, 0);
            gSPDisplayList(POLY_XLU_DISP++, sBottleDLists[LINK_IS_CHILD]);

            CLOSE_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2717);
        }

        if (this->actor.scale.y >= 0.0f) {
            if (!Player_HoldsHookshot(this) && ((hookedActor = this->heldActor) != NULL)) {
                if (this->stateFlags1 & PLAYER_STATE1_9) {
					static Vec3f D_80126128 = { 398.0f, 1419.0f, 244.0f };
					static Vec3f D_80126128_CHILD = { 420.0f, 1210.0f, 380.0f };
					
					if (LINK_IS_ADULT){
						Matrix_MultVec3f(&D_80126128, &hookedActor->world.pos); //Arrow Adult
					} else {
						Matrix_MultVec3f(&D_80126128_CHILD, &hookedActor->world.pos); //Arrow Child
					}
                    Matrix_RotateZYX(0x69E8, -0x5708, 0x458E, MTXMODE_APPLY);
                    Matrix_Get(&sp14C);
                    Matrix_MtxFToYXZRotS(&sp14C, &hookedActor->world.rot, 0);
                    hookedActor->shape.rot = hookedActor->world.rot;
                } else if (this->stateFlags1 & PLAYER_STATE1_11) {
                    Vec3s spB8;

                    Matrix_Get(&sp14C);
                    Matrix_MtxFToYXZRotS(&sp14C, &spB8, 0);

                    if (hookedActor->flags & ACTOR_FLAG_17) {
                        hookedActor->world.rot.x = hookedActor->shape.rot.x = spB8.x - this->unk_3BC.x;
                    } else {
                        hookedActor->world.rot.y = hookedActor->shape.rot.y = this->actor.shape.rot.y + this->unk_3BC.y;
                    }
                }
            } else {
                Matrix_Get(&this->mf_9E0);
                Matrix_MtxFToYXZRotS(&this->mf_9E0, &this->unk_3BC, 0);
            }
        }
    } else if (limbIndex == PLAYER_LIMB_R_HAND) {
        Actor* heldActor = this->heldActor;

        if (this->rightHandType == PLAYER_MODELTYPE_RH_FF) {
            Matrix_Get(&this->shieldMf);
        } else if ((this->rightHandType == PLAYER_MODELTYPE_RH_BOW_SLINGSHOT) ||
                   (this->rightHandType == PLAYER_MODELTYPE_RH_BOW_SLINGSHOT_2)) {

            // Hack String Selection per item
            rangedStringPosition = this->itemActionParam == PLAYER_AP_SLINGSHOT ? 1 : 0;
            rangedStringSelection = LINK_IS_ADULT ? (this->itemActionParam == PLAYER_AP_SLINGSHOT ? 1 : 0) : (this->itemActionParam == PLAYER_AP_SLINGSHOT ? 3 : 2);

            Vec3f stringhackData = hackStringPos[rangedStringPosition];

            OPEN_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2783);

            Matrix_Push();
            Matrix_Translate(stringhackData.x, stringhackData.y, stringhackData.z, MTXMODE_APPLY);

            if ((this->stateFlags1 & PLAYER_STATE1_9) && (this->unk_860 >= 0) && (this->unk_834 <= 10)) {
                Vec3f sp90;
                f32 distXYZ;

                Matrix_MultVec3f(&sZeroVec, &sp90);
                distXYZ = Math_Vec3f_DistXYZ(sCurBodyPartPos, &sp90);

                this->unk_858 = distXYZ - 3.0f;
                if (distXYZ < 3.0f) {
                    this->unk_858 = 0.0f;
                } else {
                    this->unk_858 *= 1.6f;
                    if (this->unk_858 > 1.0f) {
                        this->unk_858 = 1.0f;
                    }
                }

                this->unk_85C = -0.5f;
            }

            Matrix_Scale(1.0f, this->unk_858, 1.0f, MTXMODE_APPLY);

            if (!LINK_IS_ADULT) {
                Matrix_RotateZ(this->unk_858 * -0.2f, MTXMODE_APPLY);
            }

            gSPMatrix(POLY_XLU_DISP++, Matrix_NewMtx(play->state.gfxCtx, "../z_player_lib.c", 2804),
                      G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
            gSPDisplayList(POLY_XLU_DISP++,hackStringDLists[rangedStringSelection]);

            Matrix_Pop();
            CLOSE_DISPS(play->state.gfxCtx, "../z_player_lib.c", 2809);

        } else if ((this->actor.scale.y >= 0.0f) && (this->rightHandType == PLAYER_MODELTYPE_RH_SHIELD)) {
            Matrix_Get(&this->shieldMf);
            Player_UpdateShieldCollider(play, this, &this->shieldQuad, sRightHandLimbModelShieldQuadVertices);
        }

        if (this->actor.scale.y >= 0.0f) {
            if ((this->heldItemActionParam == PLAYER_AP_HOOKSHOT) ||
                (this->heldItemActionParam == PLAYER_AP_LONGSHOT)) {
					        if (LINK_IS_ADULT){
							Matrix_MultVec3f(&D_80126184, &this->unk_3C8); //Chain Adult
							} else {
							Matrix_MultVec3f(&ChildHookshotChainPos, &this->unk_3C8); //Chain Child
							}

                if (heldActor != NULL) {
                    MtxF sp44;

					if (LINK_IS_ADULT){
					Matrix_MultVec3f(&D_80126190, &heldActor->world.pos); //Spike Adult
					} else {
					Matrix_MultVec3f(&ChildHookshotSpikePos, &heldActor->world.pos); //Spike Child
					}
                    Matrix_RotateZYX(0, -0x4000, -0x4000, MTXMODE_APPLY);
                    Matrix_Get(&sp44);
                    Matrix_MtxFToYXZRotS(&sp44, &heldActor->world.rot, 0);
                    heldActor->shape.rot = heldActor->world.rot;

                    if (func_8002DD78(this) != 0) {
                        Matrix_Translate(500.0f, 300.0f, 0.0f, MTXMODE_APPLY);
                        Player_DrawHookshotReticle(
                            play, this, (this->heldItemActionParam == PLAYER_AP_HOOKSHOT) ? 38600.0f : 77600.0f);
                    }
                }
            }
        }

        if ((this->unk_862 != 0) || ((func_8002DD6C(this) == 0) && (heldActor != NULL))) {
            if (!(this->stateFlags1 & PLAYER_STATE1_10) && (this->unk_862 != 0) &&
                (this->exchangeItemId != EXCH_ITEM_NONE)) {
                Math_Vec3f_Copy(&sGetItemRefPos, &this->leftHandPos);
            } else {
                sGetItemRefPos.x = (this->bodyPartsPos[PLAYER_BODYPART_R_HAND].x + this->leftHandPos.x) * 0.5f;
                sGetItemRefPos.y = (this->bodyPartsPos[PLAYER_BODYPART_R_HAND].y + this->leftHandPos.y) * 0.5f;
                sGetItemRefPos.z = (this->bodyPartsPos[PLAYER_BODYPART_R_HAND].z + this->leftHandPos.z) * 0.5f;
            }

            if (this->unk_862 == 0) {
                Math_Vec3f_Copy(&heldActor->world.pos, &sGetItemRefPos);
            }
        }
        
    } else if (this->actor.scale.y >= 0.0f) {

//hackStringDLists

		if (limbIndex == PLAYER_LIMB_SHEATH) {
			if ((*dList != NULL) && (!LINK_IS_ADULT) &&
				(this->currentShield != PLAYER_SHIELD_NONE) &&
				((this->sheathType == PLAYER_MODELTYPE_SHEATH_18) ||
				(this->sheathType == PLAYER_MODELTYPE_SHEATH_19))) {
				OPEN_DISPS(play->state.gfxCtx, __FILE__, __LINE__);

				gSPDisplayList(POLY_OPA_DISP++, gPlayerShieldsChild[2 * ((this->currentShield - 1) ^ 0)]);

				CLOSE_DISPS(play->state.gfxCtx, __FILE__, __LINE__);
			}
			else if ((*dList != NULL) && (LINK_IS_ADULT) &&
				(this->currentShield != PLAYER_SHIELD_NONE) &&
				((this->sheathType == PLAYER_MODELTYPE_SHEATH_18) ||
				(this->sheathType == PLAYER_MODELTYPE_SHEATH_19))) {
				OPEN_DISPS(play->state.gfxCtx, __FILE__, __LINE__);

				gSPDisplayList(POLY_OPA_DISP++, gPlayerShieldsAdult[2 * ((this->currentShield - 1) ^ 0)]);

				CLOSE_DISPS(play->state.gfxCtx, __FILE__, __LINE__);
			}
			else if (this->unk_6AD == 3) {
			*dList = NULL;
			}
			
			
			if (this->actor.scale.y >= 0.0f) {
				if ((this->rightHandType != PLAYER_MODELTYPE_RH_SHIELD) &&
					(this->rightHandType != PLAYER_MODELTYPE_RH_FF)) {
					static Vec3f sSheathLimbModelShieldOnBackPos = { 630.0f, 100.0f, -30.0f };
					static Vec3s sSheathLimbModelShieldOnBackZyxRot = { 0, 0, 0x7FFF };

					Matrix_TranslateRotateZYX(&sSheathLimbModelShieldOnBackPos, &sSheathLimbModelShieldOnBackZyxRot);
					Matrix_Get(&this->shieldMf);
				}
			}

			
        } else if (limbIndex == PLAYER_LIMB_HEAD) {
        Matrix_MultVec3f(&sPlayerFocusHeadLimbModelPos, &this->actor.focus.pos);

        // Hack Masks excluding bunny for physics
        if (this->currentMask != PLAYER_MASK_NONE && this->currentMask != PLAYER_MASK_BUNNY && this->unk_6AD != 2) {
            //Select correct mask based on age
            Gfx** maskDListsToUse = LINK_IS_ADULT ? sAdultMaskDlists : sChildMaskDlists;
            gSPDisplayList(POLY_OPA_DISP++, maskDListsToUse[this->currentMask - 1]);
			}
        } else if (limbIndex == PLAYER_LIMB_L_FOOT || limbIndex == PLAYER_LIMB_R_FOOT) {
            Vec3f footpos = {200.0f, 300.0f, 0.0f};
            Actor_SetFeetPos(&this->actor, limbIndex, PLAYER_LIMB_L_FOOT, &footpos, PLAYER_LIMB_R_FOOT, &footpos);
        }
    }
	
	Input* input = &play->state.input[0];
	// Bremen March is Anim 68 in MM (no the fuck it ain't, dude)
	if (this->currentMask == PLAYER_MASK_KEATON) {
		//if (CHECK_BTN_ALL(input->cur.button, BTN_B)) {
		if (CHECK_BTN_ALL(input->cur.button, BTN_B)) {
			//gSaveContext.rupees++;
            LinkAnimation_Change(
				play,
				&this->skelAnime,
				&gPlayerAnim_L_1kyoro,
				-2.0f,
				Animation_GetLastFrame(&gPlayerAnim_L_1kyoro),
				0.0f,
				ANIMMODE_ONCE,
				0.0f
            );
		} else if (!CHECK_BTN_ALL(input->cur.button, BTN_B)) {
			return 0;
		}
    }
}