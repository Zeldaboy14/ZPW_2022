#include <libdragon.h>
#include <t3d/t3d.h>
#include <t3d/t3dmodel.h>
#include "../include/enums.h"
#include "../include/types.h"
#include "debug.h"
#include "collision.h"
#include "lvl1.h"
#include "utils.h"

T3DMat4FP* lvl1MatFP;
T3DModel *modelLvl1;
rspq_block_t *dplLvl1;

T3DVec3 lvl1Verts[408] =
{
    {{-142, 70, 1066}},
    {{-202, 60, 1020}},
    {{-286, 80, 1091}},
    {{-226, 90, 1136}},
    {{-617, 92, 1567}},
    {{-570, 92, 1603}},
    {{-536, 113, 1527}},
    {{-804, 71, 1423}},
    {{-891, 50, 1458}},
    {{-798, 71, 1529}},
    {{-711, 93, 1494}},
    {{-639, 50, 1754}},
    {{-535, 50, 1731}},
    {{-604, 71, 1678}},
    {{-92, 50, 1373}},
    {{-84, 50, 1279}},
    {{-140, 69, 1337}},
    {{-219, 69, 1441}},
    {{-298, 69, 1545}},
    {{-250, 50, 1581}},
    {{-171, 50, 1477}},
    {{-636, 70, 1123}},
    {{-548, 70, 1026}},
    {{-608, 60, 980}},
    {{-691, 60, 1081}},
    {{-810, 71, 1318}},
    {{-723, 71, 1220}},
    {{-774, 60, 1182}},
    {{-857, 61, 1282}},
    {{-624, 114, 1460}},
    {{-519, 113, 1375}},
    {{-570, 102, 1337}},
    {{-717, 93, 1389}},
    {{-621, 92, 1298}},
    {{-672, 81, 1259}},
    {{-764, 82, 1353}},
    {{-415, 111, 1291}},
    {{-470, 101, 1249}},
    {{-525, 91, 1207}},
    {{-580, 81, 1165}},
    {{-310, 110, 1207}},
    {{-370, 100, 1162}},
    {{-429, 90, 1116}},
    {{-489, 80, 1071}},
    {{-367, 90, 1492}},
    {{-467, 92, 1580}},
    {{-398, 71, 1632}},
    {{-336, 110, 1351}},
    {{-436, 111, 1439}},
    {{-267, 89, 1404}},
    {{-328, 50, 1685}},
    {{-501, 71, 1655}},
    {{-188, 89, 1300}},
    {{-236, 108, 1263}},
    {{-177, 89, 1174}},
    {{-118, 69, 1085}},
    {{-58, 50, 995}},
    {{-129, 69, 1211}},
    {{-70, 50, 1121}},
    {{-432, 50, 1708}},
    {{-884, 50, 1563}},
    {{-897, 50, 1352}},
    {{-664, 92, 1530}},
    {{-802, 50, 1627}},
    {{-733, 71, 1579}},
    {{-720, 50, 1690}},
    {{-669, 71, 1629}},
    {{-464, 50, 955}},
    {{-566, 50, 945}},
    {{-345, 70, 1046}},
    {{-261, 50, 975}},
    {{-363, 50, 965}},
    {{-405, 60, 1000}},
    {{-160, 50, 985}},
    {{-825, 50, 1143}},
    {{-904, 50, 1247}},
    {{-746, 50, 1039}},
    {{-667, 50, 935}},
    {{-148, 143, -145}},
    {{-148, 123, -251}},
    {{-218, 123, -251}},
    {{-218, 143, -145}},
    {{-288, 123, -40}},
    {{-218, 123, -40}},
    {{-288, 143, -145}},
    {{-148, 123, -40}},
    {{-288, 123, -251}},
    {{-148, 50, 927}},
    {{-235, 50, 861}},
    {{-321, 50, 930}},
    {{-524, 50, 910}},
    {{-322, 50, 795}},
    {{-418, 50, 722}},
    {{-501, 50, 793}},
    {{-441, 50, 839}},
    {{-145, 50, -384}},
    {{-72, 50, -456}},
    {{-145, 50, -528}},
    {{-217, 50, -456}},
    {{-290, 50, -239}},
    {{-217, 50, -311}},
    {{-290, 50, -384}},
    {{-362, 50, -311}},
    {{145, 50, -384}},
    {{217, 50, -456}},
    {{72, 50, -456}},
    {{0, 50, -239}},
    {{72, 50, -311}},
    {{0, 50, -384}},
    {{-72, 50, -311}},
    {{-145, 50, -94}},
    {{-72, 50, -166}},
    {{-145, 50, -239}},
    {{-217, 50, -166}},
    {{-290, 50, 51}},
    {{-217, 50, -22}},
    {{-290, 50, -94}},
    {{-362, 50, -22}},
    {{290, 50, -239}},
    {{362, 50, -311}},
    {{290, 50, -384}},
    {{217, 50, -311}},
    {{145, 50, -94}},
    {{217, 50, -166}},
    {{145, 50, -239}},
    {{72, 50, -166}},
    {{0, 50, 51}},
    {{72, 50, -22}},
    {{0, 50, -94}},
    {{-72, 50, -22}},
    {{-145, 50, 196}},
    {{-72, 50, 123}},
    {{-145, 50, 51}},
    {{-217, 50, 123}},
    {{434, 50, -94}},
    {{507, 50, -166}},
    {{434, 50, -239}},
    {{362, 50, -166}},
    {{290, 50, 51}},
    {{362, 50, -22}},
    {{290, 50, -94}},
    {{217, 50, -22}},
    {{145, 50, 196}},
    {{217, 50, 123}},
    {{145, 50, 51}},
    {{72, 50, 123}},
    {{0, 50, 340}},
    {{72, 50, 268}},
    {{0, 50, 196}},
    {{-72, 50, 268}},
    {{579, 50, 51}},
    {{652, 50, -22}},
    {{579, 50, -94}},
    {{507, 50, -22}},
    {{434, 50, 196}},
    {{507, 50, 123}},
    {{434, 50, 51}},
    {{362, 50, 123}},
    {{290, 50, 340}},
    {{362, 50, 268}},
    {{290, 50, 196}},
    {{217, 50, 268}},
    {{0, 50, 630}},
    {{72, 50, 558}},
    {{0, 50, 485}},
    {{-72, 50, 558}},
    {{-145, 50, 775}},
    {{-72, 50, 703}},
    {{-145, 50, 630}},
    {{-217, 50, 703}},
    {{443, 50, 494}},
    {{507, 50, 413}},
    {{434, 50, 340}},
    {{362, 50, 413}},
    {{290, 50, 630}},
    {{362, 50, 558}},
    {{290, 50, 485}},
    {{217, 50, 558}},
    {{145, 50, 775}},
    {{217, 50, 703}},
    {{145, 50, 630}},
    {{72, 50, 703}},
    {{0, 50, 920}},
    {{72, 50, 847}},
    {{0, 50, 775}},
    {{-72, 50, 847}},
    {{145, 50, 1354}},
    {{290, 50, 1354}},
    {{217, 50, 1282}},
    {{290, 50, 920}},
    {{362, 50, 847}},
    {{290, 50, 775}},
    {{217, 50, 847}},
    {{145, 50, 1065}},
    {{217, 50, 992}},
    {{145, 50, 920}},
    {{72, 50, 992}},
    {{0, 50, 1209}},
    {{72, 50, 1137}},
    {{0, 50, 1065}},
    {{290, 50, 1209}},
    {{362, 50, 1137}},
    {{290, 50, 1065}},
    {{217, 50, 1137}},
    {{145, 50, 1209}},
    {{72, 50, 1282}},
    {{72, 50, 1427}},
    {{0, 50, 1354}},
    {{362, 50, 1282}},
    {{434, 50, 1209}},
    {{434, 50, 1065}},
    {{362, 50, 992}},
    {{443, 50, 920}},
    {{434, 50, 775}},
    {{362, 50, 703}},
    {{434, 50, 630}},
    {{145, 50, 485}},
    {{217, 50, 413}},
    {{507, 50, 268}},
    {{579, 50, 196}},
    {{652, 50, 123}},
    {{-290, 50, 630}},
    {{-217, 50, 558}},
    {{-145, 50, 485}},
    {{-217, 50, 268}},
    {{-145, 50, 340}},
    {{434, 50, -384}},
    {{362, 50, -456}},
    {{507, 50, -311}},
    {{-362, 50, -166}},
    {{-290, 50, -528}},
    {{-68, 50, 1422}},
    {{-381, 50, 884}},
    {{-584, 50, 864}},
    {{11, -50, 537}},
    {{87, -50, 547}},
    {{89, 326, 547}},
    {{12, 326, 537}},
    {{620, -50, 76}},
    {{621, 326, 76}},
    {{535, 326, 54}},
    {{535, -50, 54}},
    {{535, -50, 55}},
    {{361, -50, 689}},
    {{386, -50, 763}},
    {{390, 326, 766}},
    {{366, 326, 693}},
    {{-182, -50, 309}},
    {{-182, 326, 309}},
    {{-56, 326, 208}},
    {{-56, -50, 208}},
    {{462, -50, 447}},
    {{398, -50, 531}},
    {{402, 326, 534}},
    {{462, 326, 447}},
    {{239, -50, 567}},
    {{284, -50, 498}},
    {{286, 326, 498}},
    {{243, 326, 567}},
    {{76, -50, -425}},
    {{77, 326, -432}},
    {{93, 326, -354}},
    {{93, -50, -354}},
    {{320, -50, 325}},
    {{320, 326, 325}},
    {{329, 326, 430}},
    {{329, -50, 430}},
    {{36, 326, 211}},
    {{36, -50, 211}},
    {{-823, -50, 1611}},
    {{-823, 326, 1611}},
    {{-761, 326, 1659}},
    {{-761, -50, 1659}},
    {{-889, -50, 1484}},
    {{-894, -50, 1405}},
    {{-894, 326, 1405}},
    {{-889, 326, 1484}},
    {{-186, -50, -344}},
    {{-186, 326, -344}},
    {{-320, 326, -308}},
    {{-320, -50, -308}},
    {{367, 326, 1203}},
    {{391, 326, 1106}},
    {{391, -50, 1106}},
    {{367, -50, 1203}},
    {{-162, -50, 189}},
    {{-162, 326, 189}},
    {{446, -50, -250}},
    {{446, 326, -250}},
    {{373, 326, -329}},
    {{373, -50, -329}},
    {{-218, -50, -40}},
    {{-218, 326, -40}},
    {{-190, 326, 75}},
    {{-190, -50, 75}},
    {{-207, -50, -480}},
    {{-207, 326, -480}},
    {{430, -50, 249}},
    {{430, 326, 249}},
    {{453, 326, 207}},
    {{453, -50, 207}},
    {{535, -50, -11}},
    {{535, 326, -11}},
    {{490, 326, -131}},
    {{490, -50, -131}},
    {{274, 326, -376}},
    {{274, -50, -376}},
    {{-356, 326, -258}},
    {{-356, -50, -258}},
    {{535, 326, 167}},
    {{535, -50, 167}},
    {{-351, -50, -158}},
    {{-351, 326, -158}},
    {{-285, 326, -99}},
    {{-288, -50, -94}},
    {{-561, -50, 1737}},
    {{-561, 326, 1737}},
    {{-483, 326, 1720}},
    {{-483, -50, 1720}},
    {{-328, -50, 1685}},
    {{-328, 326, 1685}},
    {{-269, 326, 1607}},
    {{-269, -50, 1607}},
    {{-480, -50, 775}},
    {{-480, 326, 775}},
    {{-542, 326, 829}},
    {{-542, -50, 829}},
    {{235, 326, 1319}},
    {{235, -50, 1319}},
    {{126, -50, 1337}},
    {{126, 326, 1337}},
    {{-726, -50, 1013}},
    {{-726, 326, 1013}},
    {{-785, 326, 1091}},
    {{-785, -50, 1091}},
    {{157, 326, -363}},
    {{157, -50, -363}},
    {{312, 326, 221}},
    {{312, -50, 221}},
    {{446, -50, 348}},
    {{446, 326, 348}},
    {{-129, -50, -367}},
    {{-129, 326, -367}},
    {{-18, 326, -361}},
    {{-18, -50, -361}},
    {{-329, 326, 673}},
    {{-329, -50, 673}},
    {{-241, -50, 625}},
    {{-241, 326, 625}},
    {{-210, -50, 1529}},
    {{-210, 326, 1529}},
    {{-151, 326, 1451}},
    {{-151, -50, 1451}},
    {{-406, -50, 1702}},
    {{-406, 326, 1702}},
    {{-700, -50, 1706}},
    {{-700, 326, 1706}},
    {{-639, 326, 1754}},
    {{-639, -50, 1754}},
    {{-899, 326, 1326}},
    {{-899, -50, 1326}},
    {{-904, -50, 1247}},
    {{-904, 326, 1247}},
    {{-844, -50, 1169}},
    {{-844, 326, 1169}},
    {{-605, -50, 882}},
    {{-605, 326, 882}},
    {{-667, 326, 935}},
    {{-667, -50, 935}},
    {{166, 326, 557}},
    {{163, -50, 557}},
    {{-153, 326, 576}},
    {{-153, -50, 576}},
    {{-65, -50, 527}},
    {{-65, 326, 527}},
    {{17, 326, 1355}},
    {{17, -50, 1355}},
    {{-92, -50, 1373}},
    {{-92, 326, 1373}},
    {{414, -50, 1008}},
    {{414, 326, 1008}},
    {{437, 326, 911}},
    {{437, -50, 911}},
    {{413, 326, 838}},
    {{412, -50, 837}},
    {{128, -50, 215}},
    {{128, 326, 215}},
    {{220, 326, 218}},
    {{220, -50, 218}},
    {{154, -50, -433}},
    {{151, 326, -439}},
    {{335, -50, 615}},
    {{342, 326, 621}},
    {{-148, -50, -251}},
    {{-218, -50, -251}},
    {{-288, -50, -251}},
    {{-288, -50, -145}},
    {{-288, -50, -40}},
    {{-148, -50, -40}},
    {{-148, -50, -145}},
    {{-418, 326, 722}},
    {{-418, -50, 722}},
    {{344, 326, 1301}},
    {{344, -50, 1301}},
    {{-884, -50, 1563}},
    {{-884, 326, 1563}},
    {{620, -50, 146}},
    {{620, 326, 146}},
};


int lvl1SlopeCount = 132;
Surface* lvl1Slope;

int lvl1FloorCount = 259;
Surface* lvl1Floor;

int lvl1WallCount = 183;
Surface* lvl1Wall;

int lvl1SurfacesCount = 0;
Surface* lvl1Surfaces;

void lvl1_init(void){
    lvl1Slope = malloc(lvl1SlopeCount * sizeof(Surface));
    lvl1Floor = malloc(lvl1FloorCount * sizeof(Surface));
    lvl1Wall = malloc(lvl1WallCount * sizeof(Surface));
    lvl1Surfaces = malloc((lvl1WallCount + lvl1SlopeCount + lvl1FloorCount) * sizeof(Surface));

    lvl1Slope[0].posA = lvl1Verts[0]; lvl1Slope[0].posB = lvl1Verts[1]; lvl1Slope[0].posC = lvl1Verts[2];
    lvl1Slope[1].posA = lvl1Verts[0]; lvl1Slope[1].posB = lvl1Verts[2]; lvl1Slope[1].posC = lvl1Verts[3];
    lvl1Slope[2].posA = lvl1Verts[4]; lvl1Slope[2].posB = lvl1Verts[5]; lvl1Slope[2].posC = lvl1Verts[6];
    lvl1Slope[3].posA = lvl1Verts[7]; lvl1Slope[3].posB = lvl1Verts[8]; lvl1Slope[3].posC = lvl1Verts[9];
    lvl1Slope[4].posA = lvl1Verts[7]; lvl1Slope[4].posB = lvl1Verts[9]; lvl1Slope[4].posC = lvl1Verts[10];
    lvl1Slope[5].posA = lvl1Verts[11]; lvl1Slope[5].posB = lvl1Verts[12]; lvl1Slope[5].posC = lvl1Verts[13];
    lvl1Slope[6].posA = lvl1Verts[14]; lvl1Slope[6].posB = lvl1Verts[15]; lvl1Slope[6].posC = lvl1Verts[16];
    lvl1Slope[7].posA = lvl1Verts[17]; lvl1Slope[7].posB = lvl1Verts[18]; lvl1Slope[7].posC = lvl1Verts[19];
    lvl1Slope[8].posA = lvl1Verts[17]; lvl1Slope[8].posB = lvl1Verts[19]; lvl1Slope[8].posC = lvl1Verts[20];
    lvl1Slope[9].posA = lvl1Verts[21]; lvl1Slope[9].posB = lvl1Verts[22]; lvl1Slope[9].posC = lvl1Verts[23];
    lvl1Slope[10].posA = lvl1Verts[21]; lvl1Slope[10].posB = lvl1Verts[23]; lvl1Slope[10].posC = lvl1Verts[24];
    lvl1Slope[11].posA = lvl1Verts[25]; lvl1Slope[11].posB = lvl1Verts[26]; lvl1Slope[11].posC = lvl1Verts[27];
    lvl1Slope[12].posA = lvl1Verts[25]; lvl1Slope[12].posB = lvl1Verts[27]; lvl1Slope[12].posC = lvl1Verts[28];
    lvl1Slope[13].posA = lvl1Verts[26]; lvl1Slope[13].posB = lvl1Verts[21]; lvl1Slope[13].posC = lvl1Verts[24];
    lvl1Slope[14].posA = lvl1Verts[26]; lvl1Slope[14].posB = lvl1Verts[24]; lvl1Slope[14].posC = lvl1Verts[27];
    lvl1Slope[15].posA = lvl1Verts[29]; lvl1Slope[15].posB = lvl1Verts[30]; lvl1Slope[15].posC = lvl1Verts[31];
    lvl1Slope[16].posA = lvl1Verts[32]; lvl1Slope[16].posB = lvl1Verts[33]; lvl1Slope[16].posC = lvl1Verts[34];
    lvl1Slope[17].posA = lvl1Verts[32]; lvl1Slope[17].posB = lvl1Verts[34]; lvl1Slope[17].posC = lvl1Verts[35];
    lvl1Slope[18].posA = lvl1Verts[30]; lvl1Slope[18].posB = lvl1Verts[36]; lvl1Slope[18].posC = lvl1Verts[37];
    lvl1Slope[19].posA = lvl1Verts[30]; lvl1Slope[19].posB = lvl1Verts[37]; lvl1Slope[19].posC = lvl1Verts[31];
    lvl1Slope[20].posA = lvl1Verts[33]; lvl1Slope[20].posB = lvl1Verts[38]; lvl1Slope[20].posC = lvl1Verts[39];
    lvl1Slope[21].posA = lvl1Verts[33]; lvl1Slope[21].posB = lvl1Verts[39]; lvl1Slope[21].posC = lvl1Verts[34];
    lvl1Slope[22].posA = lvl1Verts[36]; lvl1Slope[22].posB = lvl1Verts[40]; lvl1Slope[22].posC = lvl1Verts[41];
    lvl1Slope[23].posA = lvl1Verts[36]; lvl1Slope[23].posB = lvl1Verts[41]; lvl1Slope[23].posC = lvl1Verts[37];
    lvl1Slope[24].posA = lvl1Verts[38]; lvl1Slope[24].posB = lvl1Verts[42]; lvl1Slope[24].posC = lvl1Verts[43];
    lvl1Slope[25].posA = lvl1Verts[38]; lvl1Slope[25].posB = lvl1Verts[43]; lvl1Slope[25].posC = lvl1Verts[39];
    lvl1Slope[26].posA = lvl1Verts[44]; lvl1Slope[26].posB = lvl1Verts[45]; lvl1Slope[26].posC = lvl1Verts[46];
    lvl1Slope[27].posA = lvl1Verts[44]; lvl1Slope[27].posB = lvl1Verts[46]; lvl1Slope[27].posC = lvl1Verts[18];
    lvl1Slope[28].posA = lvl1Verts[47]; lvl1Slope[28].posB = lvl1Verts[48]; lvl1Slope[28].posC = lvl1Verts[44];
    lvl1Slope[29].posA = lvl1Verts[47]; lvl1Slope[29].posB = lvl1Verts[44]; lvl1Slope[29].posC = lvl1Verts[49];
    lvl1Slope[30].posA = lvl1Verts[48]; lvl1Slope[30].posB = lvl1Verts[6]; lvl1Slope[30].posC = lvl1Verts[45];
    lvl1Slope[31].posA = lvl1Verts[48]; lvl1Slope[31].posB = lvl1Verts[45]; lvl1Slope[31].posC = lvl1Verts[44];
    lvl1Slope[32].posA = lvl1Verts[50]; lvl1Slope[32].posB = lvl1Verts[19]; lvl1Slope[32].posC = lvl1Verts[18];
    lvl1Slope[33].posA = lvl1Verts[50]; lvl1Slope[33].posB = lvl1Verts[18]; lvl1Slope[33].posC = lvl1Verts[46];
    lvl1Slope[34].posA = lvl1Verts[5]; lvl1Slope[34].posB = lvl1Verts[51]; lvl1Slope[34].posC = lvl1Verts[45];
    lvl1Slope[35].posA = lvl1Verts[5]; lvl1Slope[35].posB = lvl1Verts[45]; lvl1Slope[35].posC = lvl1Verts[6];
    lvl1Slope[36].posA = lvl1Verts[52]; lvl1Slope[36].posB = lvl1Verts[49]; lvl1Slope[36].posC = lvl1Verts[17];
    lvl1Slope[37].posA = lvl1Verts[52]; lvl1Slope[37].posB = lvl1Verts[17]; lvl1Slope[37].posC = lvl1Verts[16];
    lvl1Slope[38].posA = lvl1Verts[53]; lvl1Slope[38].posB = lvl1Verts[47]; lvl1Slope[38].posC = lvl1Verts[49];
    lvl1Slope[39].posA = lvl1Verts[53]; lvl1Slope[39].posB = lvl1Verts[49]; lvl1Slope[39].posC = lvl1Verts[52];
    lvl1Slope[40].posA = lvl1Verts[18]; lvl1Slope[40].posB = lvl1Verts[17]; lvl1Slope[40].posC = lvl1Verts[49];
    lvl1Slope[41].posA = lvl1Verts[18]; lvl1Slope[41].posB = lvl1Verts[49]; lvl1Slope[41].posC = lvl1Verts[44];
    lvl1Slope[42].posA = lvl1Verts[54]; lvl1Slope[42].posB = lvl1Verts[55]; lvl1Slope[42].posC = lvl1Verts[0];
    lvl1Slope[43].posA = lvl1Verts[54]; lvl1Slope[43].posB = lvl1Verts[0]; lvl1Slope[43].posC = lvl1Verts[3];
    lvl1Slope[44].posA = lvl1Verts[55]; lvl1Slope[44].posB = lvl1Verts[56]; lvl1Slope[44].posC = lvl1Verts[0];
    lvl1Slope[45].posA = lvl1Verts[3]; lvl1Slope[45].posB = lvl1Verts[2]; lvl1Slope[45].posC = lvl1Verts[41];
    lvl1Slope[46].posA = lvl1Verts[3]; lvl1Slope[46].posB = lvl1Verts[41]; lvl1Slope[46].posC = lvl1Verts[40];
    lvl1Slope[47].posA = lvl1Verts[57]; lvl1Slope[47].posB = lvl1Verts[58]; lvl1Slope[47].posC = lvl1Verts[55];
    lvl1Slope[48].posA = lvl1Verts[57]; lvl1Slope[48].posB = lvl1Verts[55]; lvl1Slope[48].posC = lvl1Verts[54];
    lvl1Slope[49].posA = lvl1Verts[16]; lvl1Slope[49].posB = lvl1Verts[17]; lvl1Slope[49].posC = lvl1Verts[20];
    lvl1Slope[50].posA = lvl1Verts[16]; lvl1Slope[50].posB = lvl1Verts[20]; lvl1Slope[50].posC = lvl1Verts[14];
    lvl1Slope[51].posA = lvl1Verts[16]; lvl1Slope[51].posB = lvl1Verts[15]; lvl1Slope[51].posC = lvl1Verts[57];
    lvl1Slope[52].posA = lvl1Verts[16]; lvl1Slope[52].posB = lvl1Verts[57]; lvl1Slope[52].posC = lvl1Verts[52];
    lvl1Slope[53].posA = lvl1Verts[15]; lvl1Slope[53].posB = lvl1Verts[58]; lvl1Slope[53].posC = lvl1Verts[57];
    lvl1Slope[54].posA = lvl1Verts[58]; lvl1Slope[54].posB = lvl1Verts[56]; lvl1Slope[54].posC = lvl1Verts[55];
    lvl1Slope[55].posA = lvl1Verts[13]; lvl1Slope[55].posB = lvl1Verts[12]; lvl1Slope[55].posC = lvl1Verts[51];
    lvl1Slope[56].posA = lvl1Verts[13]; lvl1Slope[56].posB = lvl1Verts[51]; lvl1Slope[56].posC = lvl1Verts[5];
    lvl1Slope[57].posA = lvl1Verts[51]; lvl1Slope[57].posB = lvl1Verts[59]; lvl1Slope[57].posC = lvl1Verts[46];
    lvl1Slope[58].posA = lvl1Verts[51]; lvl1Slope[58].posB = lvl1Verts[46]; lvl1Slope[58].posC = lvl1Verts[45];
    lvl1Slope[59].posA = lvl1Verts[12]; lvl1Slope[59].posB = lvl1Verts[59]; lvl1Slope[59].posC = lvl1Verts[51];
    lvl1Slope[60].posA = lvl1Verts[59]; lvl1Slope[60].posB = lvl1Verts[50]; lvl1Slope[60].posC = lvl1Verts[46];
    lvl1Slope[61].posA = lvl1Verts[9]; lvl1Slope[61].posB = lvl1Verts[8]; lvl1Slope[61].posC = lvl1Verts[60];
    lvl1Slope[62].posA = lvl1Verts[25]; lvl1Slope[62].posB = lvl1Verts[61]; lvl1Slope[62].posC = lvl1Verts[7];
    lvl1Slope[63].posA = lvl1Verts[25]; lvl1Slope[63].posB = lvl1Verts[7]; lvl1Slope[63].posC = lvl1Verts[35];
    lvl1Slope[64].posA = lvl1Verts[7]; lvl1Slope[64].posB = lvl1Verts[61]; lvl1Slope[64].posC = lvl1Verts[8];
    lvl1Slope[65].posA = lvl1Verts[25]; lvl1Slope[65].posB = lvl1Verts[28]; lvl1Slope[65].posC = lvl1Verts[61];
    lvl1Slope[66].posA = lvl1Verts[10]; lvl1Slope[66].posB = lvl1Verts[62]; lvl1Slope[66].posC = lvl1Verts[29];
    lvl1Slope[67].posA = lvl1Verts[62]; lvl1Slope[67].posB = lvl1Verts[4]; lvl1Slope[67].posC = lvl1Verts[6];
    lvl1Slope[68].posA = lvl1Verts[62]; lvl1Slope[68].posB = lvl1Verts[6]; lvl1Slope[68].posC = lvl1Verts[29];
    lvl1Slope[69].posA = lvl1Verts[60]; lvl1Slope[69].posB = lvl1Verts[63]; lvl1Slope[69].posC = lvl1Verts[64];
    lvl1Slope[70].posA = lvl1Verts[60]; lvl1Slope[70].posB = lvl1Verts[64]; lvl1Slope[70].posC = lvl1Verts[9];
    lvl1Slope[71].posA = lvl1Verts[9]; lvl1Slope[71].posB = lvl1Verts[64]; lvl1Slope[71].posC = lvl1Verts[62];
    lvl1Slope[72].posA = lvl1Verts[9]; lvl1Slope[72].posB = lvl1Verts[62]; lvl1Slope[72].posC = lvl1Verts[10];
    lvl1Slope[73].posA = lvl1Verts[63]; lvl1Slope[73].posB = lvl1Verts[65]; lvl1Slope[73].posC = lvl1Verts[66];
    lvl1Slope[74].posA = lvl1Verts[63]; lvl1Slope[74].posB = lvl1Verts[66]; lvl1Slope[74].posC = lvl1Verts[64];
    lvl1Slope[75].posA = lvl1Verts[64]; lvl1Slope[75].posB = lvl1Verts[66]; lvl1Slope[75].posC = lvl1Verts[4];
    lvl1Slope[76].posA = lvl1Verts[64]; lvl1Slope[76].posB = lvl1Verts[4]; lvl1Slope[76].posC = lvl1Verts[62];
    lvl1Slope[77].posA = lvl1Verts[65]; lvl1Slope[77].posB = lvl1Verts[11]; lvl1Slope[77].posC = lvl1Verts[13];
    lvl1Slope[78].posA = lvl1Verts[65]; lvl1Slope[78].posB = lvl1Verts[13]; lvl1Slope[78].posC = lvl1Verts[66];
    lvl1Slope[79].posA = lvl1Verts[66]; lvl1Slope[79].posB = lvl1Verts[13]; lvl1Slope[79].posC = lvl1Verts[5];
    lvl1Slope[80].posA = lvl1Verts[66]; lvl1Slope[80].posB = lvl1Verts[5]; lvl1Slope[80].posC = lvl1Verts[4];
    lvl1Slope[81].posA = lvl1Verts[22]; lvl1Slope[81].posB = lvl1Verts[67]; lvl1Slope[81].posC = lvl1Verts[68];
    lvl1Slope[82].posA = lvl1Verts[22]; lvl1Slope[82].posB = lvl1Verts[68]; lvl1Slope[82].posC = lvl1Verts[23];
    lvl1Slope[83].posA = lvl1Verts[52]; lvl1Slope[83].posB = lvl1Verts[57]; lvl1Slope[83].posC = lvl1Verts[54];
    lvl1Slope[84].posA = lvl1Verts[52]; lvl1Slope[84].posB = lvl1Verts[54]; lvl1Slope[84].posC = lvl1Verts[53];
    lvl1Slope[85].posA = lvl1Verts[69]; lvl1Slope[85].posB = lvl1Verts[70]; lvl1Slope[85].posC = lvl1Verts[71];
    lvl1Slope[86].posA = lvl1Verts[69]; lvl1Slope[86].posB = lvl1Verts[71]; lvl1Slope[86].posC = lvl1Verts[72];
    lvl1Slope[87].posA = lvl1Verts[69]; lvl1Slope[87].posB = lvl1Verts[72]; lvl1Slope[87].posC = lvl1Verts[43];
    lvl1Slope[88].posA = lvl1Verts[69]; lvl1Slope[88].posB = lvl1Verts[43]; lvl1Slope[88].posC = lvl1Verts[42];
    lvl1Slope[89].posA = lvl1Verts[0]; lvl1Slope[89].posB = lvl1Verts[56]; lvl1Slope[89].posC = lvl1Verts[73];
    lvl1Slope[90].posA = lvl1Verts[0]; lvl1Slope[90].posB = lvl1Verts[73]; lvl1Slope[90].posC = lvl1Verts[1];
    lvl1Slope[91].posA = lvl1Verts[32]; lvl1Slope[91].posB = lvl1Verts[7]; lvl1Slope[91].posC = lvl1Verts[10];
    lvl1Slope[92].posA = lvl1Verts[32]; lvl1Slope[92].posB = lvl1Verts[10]; lvl1Slope[92].posC = lvl1Verts[29];
    lvl1Slope[93].posA = lvl1Verts[53]; lvl1Slope[93].posB = lvl1Verts[54]; lvl1Slope[93].posC = lvl1Verts[3];
    lvl1Slope[94].posA = lvl1Verts[53]; lvl1Slope[94].posB = lvl1Verts[3]; lvl1Slope[94].posC = lvl1Verts[40];
    lvl1Slope[95].posA = lvl1Verts[35]; lvl1Slope[95].posB = lvl1Verts[34]; lvl1Slope[95].posC = lvl1Verts[26];
    lvl1Slope[96].posA = lvl1Verts[35]; lvl1Slope[96].posB = lvl1Verts[26]; lvl1Slope[96].posC = lvl1Verts[25];
    lvl1Slope[97].posA = lvl1Verts[39]; lvl1Slope[97].posB = lvl1Verts[43]; lvl1Slope[97].posC = lvl1Verts[22];
    lvl1Slope[98].posA = lvl1Verts[39]; lvl1Slope[98].posB = lvl1Verts[22]; lvl1Slope[98].posC = lvl1Verts[21];
    lvl1Slope[99].posA = lvl1Verts[72]; lvl1Slope[99].posB = lvl1Verts[71]; lvl1Slope[99].posC = lvl1Verts[67];
    lvl1Slope[100].posA = lvl1Verts[43]; lvl1Slope[100].posB = lvl1Verts[72]; lvl1Slope[100].posC = lvl1Verts[67];
    lvl1Slope[101].posA = lvl1Verts[43]; lvl1Slope[101].posB = lvl1Verts[67]; lvl1Slope[101].posC = lvl1Verts[22];
    lvl1Slope[102].posA = lvl1Verts[34]; lvl1Slope[102].posB = lvl1Verts[39]; lvl1Slope[102].posC = lvl1Verts[21];
    lvl1Slope[103].posA = lvl1Verts[34]; lvl1Slope[103].posB = lvl1Verts[21]; lvl1Slope[103].posC = lvl1Verts[26];
    lvl1Slope[104].posA = lvl1Verts[35]; lvl1Slope[104].posB = lvl1Verts[7]; lvl1Slope[104].posC = lvl1Verts[32];
    lvl1Slope[105].posA = lvl1Verts[28]; lvl1Slope[105].posB = lvl1Verts[27]; lvl1Slope[105].posC = lvl1Verts[74];
    lvl1Slope[106].posA = lvl1Verts[28]; lvl1Slope[106].posB = lvl1Verts[74]; lvl1Slope[106].posC = lvl1Verts[75];
    lvl1Slope[107].posA = lvl1Verts[61]; lvl1Slope[107].posB = lvl1Verts[28]; lvl1Slope[107].posC = lvl1Verts[75];
    lvl1Slope[108].posA = lvl1Verts[27]; lvl1Slope[108].posB = lvl1Verts[24]; lvl1Slope[108].posC = lvl1Verts[76];
    lvl1Slope[109].posA = lvl1Verts[27]; lvl1Slope[109].posB = lvl1Verts[76]; lvl1Slope[109].posC = lvl1Verts[74];
    lvl1Slope[110].posA = lvl1Verts[23]; lvl1Slope[110].posB = lvl1Verts[68]; lvl1Slope[110].posC = lvl1Verts[77];
    lvl1Slope[111].posA = lvl1Verts[24]; lvl1Slope[111].posB = lvl1Verts[23]; lvl1Slope[111].posC = lvl1Verts[77];
    lvl1Slope[112].posA = lvl1Verts[24]; lvl1Slope[112].posB = lvl1Verts[77]; lvl1Slope[112].posC = lvl1Verts[76];
    lvl1Slope[113].posA = lvl1Verts[1]; lvl1Slope[113].posB = lvl1Verts[73]; lvl1Slope[113].posC = lvl1Verts[70];
    lvl1Slope[114].posA = lvl1Verts[31]; lvl1Slope[114].posB = lvl1Verts[37]; lvl1Slope[114].posC = lvl1Verts[38];
    lvl1Slope[115].posA = lvl1Verts[31]; lvl1Slope[115].posB = lvl1Verts[38]; lvl1Slope[115].posC = lvl1Verts[33];
    lvl1Slope[116].posA = lvl1Verts[41]; lvl1Slope[116].posB = lvl1Verts[2]; lvl1Slope[116].posC = lvl1Verts[69];
    lvl1Slope[117].posA = lvl1Verts[41]; lvl1Slope[117].posB = lvl1Verts[69]; lvl1Slope[117].posC = lvl1Verts[42];
    lvl1Slope[118].posA = lvl1Verts[31]; lvl1Slope[118].posB = lvl1Verts[33]; lvl1Slope[118].posC = lvl1Verts[32];
    lvl1Slope[119].posA = lvl1Verts[31]; lvl1Slope[119].posB = lvl1Verts[32]; lvl1Slope[119].posC = lvl1Verts[29];
    lvl1Slope[120].posA = lvl1Verts[2]; lvl1Slope[120].posB = lvl1Verts[1]; lvl1Slope[120].posC = lvl1Verts[70];
    lvl1Slope[121].posA = lvl1Verts[2]; lvl1Slope[121].posB = lvl1Verts[70]; lvl1Slope[121].posC = lvl1Verts[69];
    lvl1Slope[122].posA = lvl1Verts[37]; lvl1Slope[122].posB = lvl1Verts[41]; lvl1Slope[122].posC = lvl1Verts[42];
    lvl1Slope[123].posA = lvl1Verts[37]; lvl1Slope[123].posB = lvl1Verts[42]; lvl1Slope[123].posC = lvl1Verts[38];
    lvl1Slope[124].posA = lvl1Verts[78]; lvl1Slope[124].posB = lvl1Verts[79]; lvl1Slope[124].posC = lvl1Verts[80];
    lvl1Slope[125].posA = lvl1Verts[78]; lvl1Slope[125].posB = lvl1Verts[80]; lvl1Slope[125].posC = lvl1Verts[81];
    lvl1Slope[126].posA = lvl1Verts[82]; lvl1Slope[126].posB = lvl1Verts[83]; lvl1Slope[126].posC = lvl1Verts[81];
    lvl1Slope[127].posA = lvl1Verts[82]; lvl1Slope[127].posB = lvl1Verts[81]; lvl1Slope[127].posC = lvl1Verts[84];
    lvl1Slope[128].posA = lvl1Verts[81]; lvl1Slope[128].posB = lvl1Verts[83]; lvl1Slope[128].posC = lvl1Verts[85];
    lvl1Slope[129].posA = lvl1Verts[81]; lvl1Slope[129].posB = lvl1Verts[85]; lvl1Slope[129].posC = lvl1Verts[78];
    lvl1Slope[130].posA = lvl1Verts[81]; lvl1Slope[130].posB = lvl1Verts[80]; lvl1Slope[130].posC = lvl1Verts[86];
    lvl1Slope[131].posA = lvl1Verts[81]; lvl1Slope[131].posB = lvl1Verts[86]; lvl1Slope[131].posC = lvl1Verts[84];
    lvl1Floor[0].posA = lvl1Verts[56]; lvl1Floor[0].posB = lvl1Verts[87]; lvl1Floor[0].posC = lvl1Verts[73];
    lvl1Floor[1].posA = lvl1Verts[87]; lvl1Floor[1].posB = lvl1Verts[88]; lvl1Floor[1].posC = lvl1Verts[89];
    lvl1Floor[2].posA = lvl1Verts[87]; lvl1Floor[2].posB = lvl1Verts[89]; lvl1Floor[2].posC = lvl1Verts[70];
    lvl1Floor[3].posA = lvl1Verts[67]; lvl1Floor[3].posB = lvl1Verts[90]; lvl1Floor[3].posC = lvl1Verts[68];
    lvl1Floor[4].posA = lvl1Verts[70]; lvl1Floor[4].posB = lvl1Verts[89]; lvl1Floor[4].posC = lvl1Verts[71];
    lvl1Floor[5].posA = lvl1Verts[91]; lvl1Floor[5].posB = lvl1Verts[92]; lvl1Floor[5].posC = lvl1Verts[93];
    lvl1Floor[6].posA = lvl1Verts[91]; lvl1Floor[6].posB = lvl1Verts[93]; lvl1Floor[6].posC = lvl1Verts[94];
    lvl1Floor[7].posA = lvl1Verts[36]; lvl1Floor[7].posB = lvl1Verts[47]; lvl1Floor[7].posC = lvl1Verts[53];
    lvl1Floor[8].posA = lvl1Verts[36]; lvl1Floor[8].posB = lvl1Verts[53]; lvl1Floor[8].posC = lvl1Verts[40];
    lvl1Floor[9].posA = lvl1Verts[95]; lvl1Floor[9].posB = lvl1Verts[96]; lvl1Floor[9].posC = lvl1Verts[97];
    lvl1Floor[10].posA = lvl1Verts[95]; lvl1Floor[10].posB = lvl1Verts[97]; lvl1Floor[10].posC = lvl1Verts[98];
    lvl1Floor[11].posA = lvl1Verts[99]; lvl1Floor[11].posB = lvl1Verts[100]; lvl1Floor[11].posC = lvl1Verts[101];
    lvl1Floor[12].posA = lvl1Verts[99]; lvl1Floor[12].posB = lvl1Verts[101]; lvl1Floor[12].posC = lvl1Verts[102];
    lvl1Floor[13].posA = lvl1Verts[103]; lvl1Floor[13].posB = lvl1Verts[104]; lvl1Floor[13].posC = lvl1Verts[105];
    lvl1Floor[14].posA = lvl1Verts[106]; lvl1Floor[14].posB = lvl1Verts[107]; lvl1Floor[14].posC = lvl1Verts[108];
    lvl1Floor[15].posA = lvl1Verts[106]; lvl1Floor[15].posB = lvl1Verts[108]; lvl1Floor[15].posC = lvl1Verts[109];
    lvl1Floor[16].posA = lvl1Verts[110]; lvl1Floor[16].posB = lvl1Verts[111]; lvl1Floor[16].posC = lvl1Verts[112];
    lvl1Floor[17].posA = lvl1Verts[110]; lvl1Floor[17].posB = lvl1Verts[112]; lvl1Floor[17].posC = lvl1Verts[113];
    lvl1Floor[18].posA = lvl1Verts[114]; lvl1Floor[18].posB = lvl1Verts[115]; lvl1Floor[18].posC = lvl1Verts[116];
    lvl1Floor[19].posA = lvl1Verts[114]; lvl1Floor[19].posB = lvl1Verts[116]; lvl1Floor[19].posC = lvl1Verts[117];
    lvl1Floor[20].posA = lvl1Verts[118]; lvl1Floor[20].posB = lvl1Verts[119]; lvl1Floor[20].posC = lvl1Verts[120];
    lvl1Floor[21].posA = lvl1Verts[118]; lvl1Floor[21].posB = lvl1Verts[120]; lvl1Floor[21].posC = lvl1Verts[121];
    lvl1Floor[22].posA = lvl1Verts[122]; lvl1Floor[22].posB = lvl1Verts[123]; lvl1Floor[22].posC = lvl1Verts[124];
    lvl1Floor[23].posA = lvl1Verts[122]; lvl1Floor[23].posB = lvl1Verts[124]; lvl1Floor[23].posC = lvl1Verts[125];
    lvl1Floor[24].posA = lvl1Verts[126]; lvl1Floor[24].posB = lvl1Verts[127]; lvl1Floor[24].posC = lvl1Verts[128];
    lvl1Floor[25].posA = lvl1Verts[126]; lvl1Floor[25].posB = lvl1Verts[128]; lvl1Floor[25].posC = lvl1Verts[129];
    lvl1Floor[26].posA = lvl1Verts[130]; lvl1Floor[26].posB = lvl1Verts[131]; lvl1Floor[26].posC = lvl1Verts[132];
    lvl1Floor[27].posA = lvl1Verts[130]; lvl1Floor[27].posB = lvl1Verts[132]; lvl1Floor[27].posC = lvl1Verts[133];
    lvl1Floor[28].posA = lvl1Verts[134]; lvl1Floor[28].posB = lvl1Verts[135]; lvl1Floor[28].posC = lvl1Verts[136];
    lvl1Floor[29].posA = lvl1Verts[134]; lvl1Floor[29].posB = lvl1Verts[136]; lvl1Floor[29].posC = lvl1Verts[137];
    lvl1Floor[30].posA = lvl1Verts[138]; lvl1Floor[30].posB = lvl1Verts[139]; lvl1Floor[30].posC = lvl1Verts[140];
    lvl1Floor[31].posA = lvl1Verts[138]; lvl1Floor[31].posB = lvl1Verts[140]; lvl1Floor[31].posC = lvl1Verts[141];
    lvl1Floor[32].posA = lvl1Verts[142]; lvl1Floor[32].posB = lvl1Verts[143]; lvl1Floor[32].posC = lvl1Verts[144];
    lvl1Floor[33].posA = lvl1Verts[142]; lvl1Floor[33].posB = lvl1Verts[144]; lvl1Floor[33].posC = lvl1Verts[145];
    lvl1Floor[34].posA = lvl1Verts[146]; lvl1Floor[34].posB = lvl1Verts[147]; lvl1Floor[34].posC = lvl1Verts[148];
    lvl1Floor[35].posA = lvl1Verts[146]; lvl1Floor[35].posB = lvl1Verts[148]; lvl1Floor[35].posC = lvl1Verts[149];
    lvl1Floor[36].posA = lvl1Verts[150]; lvl1Floor[36].posB = lvl1Verts[151]; lvl1Floor[36].posC = lvl1Verts[152];
    lvl1Floor[37].posA = lvl1Verts[150]; lvl1Floor[37].posB = lvl1Verts[152]; lvl1Floor[37].posC = lvl1Verts[153];
    lvl1Floor[38].posA = lvl1Verts[154]; lvl1Floor[38].posB = lvl1Verts[155]; lvl1Floor[38].posC = lvl1Verts[156];
    lvl1Floor[39].posA = lvl1Verts[154]; lvl1Floor[39].posB = lvl1Verts[156]; lvl1Floor[39].posC = lvl1Verts[157];
    lvl1Floor[40].posA = lvl1Verts[158]; lvl1Floor[40].posB = lvl1Verts[159]; lvl1Floor[40].posC = lvl1Verts[160];
    lvl1Floor[41].posA = lvl1Verts[158]; lvl1Floor[41].posB = lvl1Verts[160]; lvl1Floor[41].posC = lvl1Verts[161];
    lvl1Floor[42].posA = lvl1Verts[162]; lvl1Floor[42].posB = lvl1Verts[163]; lvl1Floor[42].posC = lvl1Verts[164];
    lvl1Floor[43].posA = lvl1Verts[162]; lvl1Floor[43].posB = lvl1Verts[164]; lvl1Floor[43].posC = lvl1Verts[165];
    lvl1Floor[44].posA = lvl1Verts[166]; lvl1Floor[44].posB = lvl1Verts[167]; lvl1Floor[44].posC = lvl1Verts[168];
    lvl1Floor[45].posA = lvl1Verts[166]; lvl1Floor[45].posB = lvl1Verts[168]; lvl1Floor[45].posC = lvl1Verts[169];
    lvl1Floor[46].posA = lvl1Verts[170]; lvl1Floor[46].posB = lvl1Verts[171]; lvl1Floor[46].posC = lvl1Verts[172];
    lvl1Floor[47].posA = lvl1Verts[170]; lvl1Floor[47].posB = lvl1Verts[172]; lvl1Floor[47].posC = lvl1Verts[173];
    lvl1Floor[48].posA = lvl1Verts[174]; lvl1Floor[48].posB = lvl1Verts[175]; lvl1Floor[48].posC = lvl1Verts[176];
    lvl1Floor[49].posA = lvl1Verts[174]; lvl1Floor[49].posB = lvl1Verts[176]; lvl1Floor[49].posC = lvl1Verts[177];
    lvl1Floor[50].posA = lvl1Verts[178]; lvl1Floor[50].posB = lvl1Verts[179]; lvl1Floor[50].posC = lvl1Verts[180];
    lvl1Floor[51].posA = lvl1Verts[178]; lvl1Floor[51].posB = lvl1Verts[180]; lvl1Floor[51].posC = lvl1Verts[181];
    lvl1Floor[52].posA = lvl1Verts[182]; lvl1Floor[52].posB = lvl1Verts[183]; lvl1Floor[52].posC = lvl1Verts[184];
    lvl1Floor[53].posA = lvl1Verts[182]; lvl1Floor[53].posB = lvl1Verts[184]; lvl1Floor[53].posC = lvl1Verts[185];
    lvl1Floor[54].posA = lvl1Verts[186]; lvl1Floor[54].posB = lvl1Verts[187]; lvl1Floor[54].posC = lvl1Verts[188];
    lvl1Floor[55].posA = lvl1Verts[189]; lvl1Floor[55].posB = lvl1Verts[190]; lvl1Floor[55].posC = lvl1Verts[191];
    lvl1Floor[56].posA = lvl1Verts[189]; lvl1Floor[56].posB = lvl1Verts[191]; lvl1Floor[56].posC = lvl1Verts[192];
    lvl1Floor[57].posA = lvl1Verts[193]; lvl1Floor[57].posB = lvl1Verts[194]; lvl1Floor[57].posC = lvl1Verts[195];
    lvl1Floor[58].posA = lvl1Verts[193]; lvl1Floor[58].posB = lvl1Verts[195]; lvl1Floor[58].posC = lvl1Verts[196];
    lvl1Floor[59].posA = lvl1Verts[197]; lvl1Floor[59].posB = lvl1Verts[198]; lvl1Floor[59].posC = lvl1Verts[199];
    lvl1Floor[60].posA = lvl1Verts[197]; lvl1Floor[60].posB = lvl1Verts[199]; lvl1Floor[60].posC = lvl1Verts[58];
    lvl1Floor[61].posA = lvl1Verts[200]; lvl1Floor[61].posB = lvl1Verts[201]; lvl1Floor[61].posC = lvl1Verts[202];
    lvl1Floor[62].posA = lvl1Verts[200]; lvl1Floor[62].posB = lvl1Verts[202]; lvl1Floor[62].posC = lvl1Verts[203];
    lvl1Floor[63].posA = lvl1Verts[186]; lvl1Floor[63].posB = lvl1Verts[188]; lvl1Floor[63].posC = lvl1Verts[204];
    lvl1Floor[64].posA = lvl1Verts[186]; lvl1Floor[64].posB = lvl1Verts[204]; lvl1Floor[64].posC = lvl1Verts[205];
    lvl1Floor[65].posA = lvl1Verts[30]; lvl1Floor[65].posB = lvl1Verts[29]; lvl1Floor[65].posC = lvl1Verts[6];
    lvl1Floor[66].posA = lvl1Verts[30]; lvl1Floor[66].posB = lvl1Verts[6]; lvl1Floor[66].posC = lvl1Verts[48];
    lvl1Floor[67].posA = lvl1Verts[48]; lvl1Floor[67].posB = lvl1Verts[47]; lvl1Floor[67].posC = lvl1Verts[36];
    lvl1Floor[68].posA = lvl1Verts[48]; lvl1Floor[68].posB = lvl1Verts[36]; lvl1Floor[68].posC = lvl1Verts[30];
    lvl1Floor[69].posA = lvl1Verts[206]; lvl1Floor[69].posB = lvl1Verts[186]; lvl1Floor[69].posC = lvl1Verts[205];
    lvl1Floor[70].posA = lvl1Verts[206]; lvl1Floor[70].posB = lvl1Verts[205]; lvl1Floor[70].posC = lvl1Verts[207];
    lvl1Floor[71].posA = lvl1Verts[188]; lvl1Floor[71].posB = lvl1Verts[200]; lvl1Floor[71].posC = lvl1Verts[203];
    lvl1Floor[72].posA = lvl1Verts[188]; lvl1Floor[72].posB = lvl1Verts[203]; lvl1Floor[72].posC = lvl1Verts[204];
    lvl1Floor[73].posA = lvl1Verts[187]; lvl1Floor[73].posB = lvl1Verts[208]; lvl1Floor[73].posC = lvl1Verts[200];
    lvl1Floor[74].posA = lvl1Verts[187]; lvl1Floor[74].posB = lvl1Verts[200]; lvl1Floor[74].posC = lvl1Verts[188];
    lvl1Floor[75].posA = lvl1Verts[208]; lvl1Floor[75].posB = lvl1Verts[209]; lvl1Floor[75].posC = lvl1Verts[201];
    lvl1Floor[76].posA = lvl1Verts[208]; lvl1Floor[76].posB = lvl1Verts[201]; lvl1Floor[76].posC = lvl1Verts[200];
    lvl1Floor[77].posA = lvl1Verts[201]; lvl1Floor[77].posB = lvl1Verts[210]; lvl1Floor[77].posC = lvl1Verts[211];
    lvl1Floor[78].posA = lvl1Verts[201]; lvl1Floor[78].posB = lvl1Verts[211]; lvl1Floor[78].posC = lvl1Verts[202];
    lvl1Floor[79].posA = lvl1Verts[209]; lvl1Floor[79].posB = lvl1Verts[210]; lvl1Floor[79].posC = lvl1Verts[201];
    lvl1Floor[80].posA = lvl1Verts[15]; lvl1Floor[80].posB = lvl1Verts[197]; lvl1Floor[80].posC = lvl1Verts[58];
    lvl1Floor[81].posA = lvl1Verts[207]; lvl1Floor[81].posB = lvl1Verts[205]; lvl1Floor[81].posC = lvl1Verts[197];
    lvl1Floor[82].posA = lvl1Verts[207]; lvl1Floor[82].posB = lvl1Verts[197]; lvl1Floor[82].posC = lvl1Verts[15];
    lvl1Floor[83].posA = lvl1Verts[205]; lvl1Floor[83].posB = lvl1Verts[204]; lvl1Floor[83].posC = lvl1Verts[198];
    lvl1Floor[84].posA = lvl1Verts[205]; lvl1Floor[84].posB = lvl1Verts[198]; lvl1Floor[84].posC = lvl1Verts[197];
    lvl1Floor[85].posA = lvl1Verts[198]; lvl1Floor[85].posB = lvl1Verts[193]; lvl1Floor[85].posC = lvl1Verts[196];
    lvl1Floor[86].posA = lvl1Verts[198]; lvl1Floor[86].posB = lvl1Verts[196]; lvl1Floor[86].posC = lvl1Verts[199];
    lvl1Floor[87].posA = lvl1Verts[204]; lvl1Floor[87].posB = lvl1Verts[203]; lvl1Floor[87].posC = lvl1Verts[193];
    lvl1Floor[88].posA = lvl1Verts[204]; lvl1Floor[88].posB = lvl1Verts[193]; lvl1Floor[88].posC = lvl1Verts[198];
    lvl1Floor[89].posA = lvl1Verts[203]; lvl1Floor[89].posB = lvl1Verts[202]; lvl1Floor[89].posC = lvl1Verts[194];
    lvl1Floor[90].posA = lvl1Verts[203]; lvl1Floor[90].posB = lvl1Verts[194]; lvl1Floor[90].posC = lvl1Verts[193];
    lvl1Floor[91].posA = lvl1Verts[194]; lvl1Floor[91].posB = lvl1Verts[189]; lvl1Floor[91].posC = lvl1Verts[192];
    lvl1Floor[92].posA = lvl1Verts[194]; lvl1Floor[92].posB = lvl1Verts[192]; lvl1Floor[92].posC = lvl1Verts[195];
    lvl1Floor[93].posA = lvl1Verts[202]; lvl1Floor[93].posB = lvl1Verts[211]; lvl1Floor[93].posC = lvl1Verts[189];
    lvl1Floor[94].posA = lvl1Verts[202]; lvl1Floor[94].posB = lvl1Verts[189]; lvl1Floor[94].posC = lvl1Verts[194];
    lvl1Floor[95].posA = lvl1Verts[211]; lvl1Floor[95].posB = lvl1Verts[212]; lvl1Floor[95].posC = lvl1Verts[190];
    lvl1Floor[96].posA = lvl1Verts[211]; lvl1Floor[96].posB = lvl1Verts[190]; lvl1Floor[96].posC = lvl1Verts[189];
    lvl1Floor[97].posA = lvl1Verts[190]; lvl1Floor[97].posB = lvl1Verts[213]; lvl1Floor[97].posC = lvl1Verts[214];
    lvl1Floor[98].posA = lvl1Verts[190]; lvl1Floor[98].posB = lvl1Verts[214]; lvl1Floor[98].posC = lvl1Verts[191];
    lvl1Floor[99].posA = lvl1Verts[212]; lvl1Floor[99].posB = lvl1Verts[213]; lvl1Floor[99].posC = lvl1Verts[190];
    lvl1Floor[100].posA = lvl1Verts[58]; lvl1Floor[100].posB = lvl1Verts[199]; lvl1Floor[100].posC = lvl1Verts[56];
    lvl1Floor[101].posA = lvl1Verts[56]; lvl1Floor[101].posB = lvl1Verts[182]; lvl1Floor[101].posC = lvl1Verts[185];
    lvl1Floor[102].posA = lvl1Verts[56]; lvl1Floor[102].posB = lvl1Verts[185]; lvl1Floor[102].posC = lvl1Verts[87];
    lvl1Floor[103].posA = lvl1Verts[199]; lvl1Floor[103].posB = lvl1Verts[196]; lvl1Floor[103].posC = lvl1Verts[182];
    lvl1Floor[104].posA = lvl1Verts[199]; lvl1Floor[104].posB = lvl1Verts[182]; lvl1Floor[104].posC = lvl1Verts[56];
    lvl1Floor[105].posA = lvl1Verts[196]; lvl1Floor[105].posB = lvl1Verts[195]; lvl1Floor[105].posC = lvl1Verts[183];
    lvl1Floor[106].posA = lvl1Verts[196]; lvl1Floor[106].posB = lvl1Verts[183]; lvl1Floor[106].posC = lvl1Verts[182];
    lvl1Floor[107].posA = lvl1Verts[183]; lvl1Floor[107].posB = lvl1Verts[178]; lvl1Floor[107].posC = lvl1Verts[181];
    lvl1Floor[108].posA = lvl1Verts[183]; lvl1Floor[108].posB = lvl1Verts[181]; lvl1Floor[108].posC = lvl1Verts[184];
    lvl1Floor[109].posA = lvl1Verts[195]; lvl1Floor[109].posB = lvl1Verts[192]; lvl1Floor[109].posC = lvl1Verts[178];
    lvl1Floor[110].posA = lvl1Verts[195]; lvl1Floor[110].posB = lvl1Verts[178]; lvl1Floor[110].posC = lvl1Verts[183];
    lvl1Floor[111].posA = lvl1Verts[192]; lvl1Floor[111].posB = lvl1Verts[191]; lvl1Floor[111].posC = lvl1Verts[179];
    lvl1Floor[112].posA = lvl1Verts[192]; lvl1Floor[112].posB = lvl1Verts[179]; lvl1Floor[112].posC = lvl1Verts[178];
    lvl1Floor[113].posA = lvl1Verts[179]; lvl1Floor[113].posB = lvl1Verts[174]; lvl1Floor[113].posC = lvl1Verts[177];
    lvl1Floor[114].posA = lvl1Verts[179]; lvl1Floor[114].posB = lvl1Verts[177]; lvl1Floor[114].posC = lvl1Verts[180];
    lvl1Floor[115].posA = lvl1Verts[191]; lvl1Floor[115].posB = lvl1Verts[214]; lvl1Floor[115].posC = lvl1Verts[174];
    lvl1Floor[116].posA = lvl1Verts[191]; lvl1Floor[116].posB = lvl1Verts[174]; lvl1Floor[116].posC = lvl1Verts[179];
    lvl1Floor[117].posA = lvl1Verts[214]; lvl1Floor[117].posB = lvl1Verts[215]; lvl1Floor[117].posC = lvl1Verts[175];
    lvl1Floor[118].posA = lvl1Verts[214]; lvl1Floor[118].posB = lvl1Verts[175]; lvl1Floor[118].posC = lvl1Verts[174];
    lvl1Floor[119].posA = lvl1Verts[175]; lvl1Floor[119].posB = lvl1Verts[170]; lvl1Floor[119].posC = lvl1Verts[173];
    lvl1Floor[120].posA = lvl1Verts[175]; lvl1Floor[120].posB = lvl1Verts[173]; lvl1Floor[120].posC = lvl1Verts[176];
    lvl1Floor[121].posA = lvl1Verts[215]; lvl1Floor[121].posB = lvl1Verts[170]; lvl1Floor[121].posC = lvl1Verts[175];
    lvl1Floor[122].posA = lvl1Verts[88]; lvl1Floor[122].posB = lvl1Verts[166]; lvl1Floor[122].posC = lvl1Verts[169];
    lvl1Floor[123].posA = lvl1Verts[88]; lvl1Floor[123].posB = lvl1Verts[169]; lvl1Floor[123].posC = lvl1Verts[91];
    lvl1Floor[124].posA = lvl1Verts[87]; lvl1Floor[124].posB = lvl1Verts[185]; lvl1Floor[124].posC = lvl1Verts[166];
    lvl1Floor[125].posA = lvl1Verts[87]; lvl1Floor[125].posB = lvl1Verts[166]; lvl1Floor[125].posC = lvl1Verts[88];
    lvl1Floor[126].posA = lvl1Verts[185]; lvl1Floor[126].posB = lvl1Verts[184]; lvl1Floor[126].posC = lvl1Verts[167];
    lvl1Floor[127].posA = lvl1Verts[185]; lvl1Floor[127].posB = lvl1Verts[167]; lvl1Floor[127].posC = lvl1Verts[166];
    lvl1Floor[128].posA = lvl1Verts[167]; lvl1Floor[128].posB = lvl1Verts[162]; lvl1Floor[128].posC = lvl1Verts[165];
    lvl1Floor[129].posA = lvl1Verts[167]; lvl1Floor[129].posB = lvl1Verts[165]; lvl1Floor[129].posC = lvl1Verts[168];
    lvl1Floor[130].posA = lvl1Verts[184]; lvl1Floor[130].posB = lvl1Verts[181]; lvl1Floor[130].posC = lvl1Verts[162];
    lvl1Floor[131].posA = lvl1Verts[184]; lvl1Floor[131].posB = lvl1Verts[162]; lvl1Floor[131].posC = lvl1Verts[167];
    lvl1Floor[132].posA = lvl1Verts[181]; lvl1Floor[132].posB = lvl1Verts[180]; lvl1Floor[132].posC = lvl1Verts[163];
    lvl1Floor[133].posA = lvl1Verts[181]; lvl1Floor[133].posB = lvl1Verts[163]; lvl1Floor[133].posC = lvl1Verts[162];
    lvl1Floor[134].posA = lvl1Verts[180]; lvl1Floor[134].posB = lvl1Verts[177]; lvl1Floor[134].posC = lvl1Verts[216];
    lvl1Floor[135].posA = lvl1Verts[180]; lvl1Floor[135].posB = lvl1Verts[216]; lvl1Floor[135].posC = lvl1Verts[163];
    lvl1Floor[136].posA = lvl1Verts[177]; lvl1Floor[136].posB = lvl1Verts[176]; lvl1Floor[136].posC = lvl1Verts[217];
    lvl1Floor[137].posA = lvl1Verts[177]; lvl1Floor[137].posB = lvl1Verts[217]; lvl1Floor[137].posC = lvl1Verts[216];
    lvl1Floor[138].posA = lvl1Verts[217]; lvl1Floor[138].posB = lvl1Verts[158]; lvl1Floor[138].posC = lvl1Verts[161];
    lvl1Floor[139].posA = lvl1Verts[176]; lvl1Floor[139].posB = lvl1Verts[173]; lvl1Floor[139].posC = lvl1Verts[158];
    lvl1Floor[140].posA = lvl1Verts[176]; lvl1Floor[140].posB = lvl1Verts[158]; lvl1Floor[140].posC = lvl1Verts[217];
    lvl1Floor[141].posA = lvl1Verts[173]; lvl1Floor[141].posB = lvl1Verts[172]; lvl1Floor[141].posC = lvl1Verts[159];
    lvl1Floor[142].posA = lvl1Verts[173]; lvl1Floor[142].posB = lvl1Verts[159]; lvl1Floor[142].posC = lvl1Verts[158];
    lvl1Floor[143].posA = lvl1Verts[159]; lvl1Floor[143].posB = lvl1Verts[154]; lvl1Floor[143].posC = lvl1Verts[157];
    lvl1Floor[144].posA = lvl1Verts[159]; lvl1Floor[144].posB = lvl1Verts[157]; lvl1Floor[144].posC = lvl1Verts[160];
    lvl1Floor[145].posA = lvl1Verts[172]; lvl1Floor[145].posB = lvl1Verts[218]; lvl1Floor[145].posC = lvl1Verts[154];
    lvl1Floor[146].posA = lvl1Verts[172]; lvl1Floor[146].posB = lvl1Verts[154]; lvl1Floor[146].posC = lvl1Verts[159];
    lvl1Floor[147].posA = lvl1Verts[218]; lvl1Floor[147].posB = lvl1Verts[219]; lvl1Floor[147].posC = lvl1Verts[155];
    lvl1Floor[148].posA = lvl1Verts[218]; lvl1Floor[148].posB = lvl1Verts[155]; lvl1Floor[148].posC = lvl1Verts[154];
    lvl1Floor[149].posA = lvl1Verts[155]; lvl1Floor[149].posB = lvl1Verts[150]; lvl1Floor[149].posC = lvl1Verts[153];
    lvl1Floor[150].posA = lvl1Verts[155]; lvl1Floor[150].posB = lvl1Verts[153]; lvl1Floor[150].posC = lvl1Verts[156];
    lvl1Floor[151].posA = lvl1Verts[219]; lvl1Floor[151].posB = lvl1Verts[220]; lvl1Floor[151].posC = lvl1Verts[150];
    lvl1Floor[152].posA = lvl1Verts[219]; lvl1Floor[152].posB = lvl1Verts[150]; lvl1Floor[152].posC = lvl1Verts[155];
    lvl1Floor[153].posA = lvl1Verts[220]; lvl1Floor[153].posB = lvl1Verts[151]; lvl1Floor[153].posC = lvl1Verts[150];
    lvl1Floor[154].posA = lvl1Verts[91]; lvl1Floor[154].posB = lvl1Verts[169]; lvl1Floor[154].posC = lvl1Verts[221];
    lvl1Floor[155].posA = lvl1Verts[91]; lvl1Floor[155].posB = lvl1Verts[221]; lvl1Floor[155].posC = lvl1Verts[92];
    lvl1Floor[156].posA = lvl1Verts[169]; lvl1Floor[156].posB = lvl1Verts[168]; lvl1Floor[156].posC = lvl1Verts[222];
    lvl1Floor[157].posA = lvl1Verts[169]; lvl1Floor[157].posB = lvl1Verts[222]; lvl1Floor[157].posC = lvl1Verts[221];
    lvl1Floor[158].posA = lvl1Verts[168]; lvl1Floor[158].posB = lvl1Verts[165]; lvl1Floor[158].posC = lvl1Verts[223];
    lvl1Floor[159].posA = lvl1Verts[168]; lvl1Floor[159].posB = lvl1Verts[223]; lvl1Floor[159].posC = lvl1Verts[222];
    lvl1Floor[160].posA = lvl1Verts[165]; lvl1Floor[160].posB = lvl1Verts[164]; lvl1Floor[160].posC = lvl1Verts[223];
    lvl1Floor[161].posA = lvl1Verts[218]; lvl1Floor[161].posB = lvl1Verts[172]; lvl1Floor[161].posC = lvl1Verts[171];
    lvl1Floor[162].posA = lvl1Verts[147]; lvl1Floor[162].posB = lvl1Verts[142]; lvl1Floor[162].posC = lvl1Verts[145];
    lvl1Floor[163].posA = lvl1Verts[147]; lvl1Floor[163].posB = lvl1Verts[145]; lvl1Floor[163].posC = lvl1Verts[148];
    lvl1Floor[164].posA = lvl1Verts[212]; lvl1Floor[164].posB = lvl1Verts[211]; lvl1Floor[164].posC = lvl1Verts[210];
    lvl1Floor[165].posA = lvl1Verts[161]; lvl1Floor[165].posB = lvl1Verts[160]; lvl1Floor[165].posC = lvl1Verts[143];
    lvl1Floor[166].posA = lvl1Verts[161]; lvl1Floor[166].posB = lvl1Verts[143]; lvl1Floor[166].posC = lvl1Verts[142];
    lvl1Floor[167].posA = lvl1Verts[143]; lvl1Floor[167].posB = lvl1Verts[138]; lvl1Floor[167].posC = lvl1Verts[141];
    lvl1Floor[168].posA = lvl1Verts[143]; lvl1Floor[168].posB = lvl1Verts[141]; lvl1Floor[168].posC = lvl1Verts[144];
    lvl1Floor[169].posA = lvl1Verts[160]; lvl1Floor[169].posB = lvl1Verts[157]; lvl1Floor[169].posC = lvl1Verts[138];
    lvl1Floor[170].posA = lvl1Verts[160]; lvl1Floor[170].posB = lvl1Verts[138]; lvl1Floor[170].posC = lvl1Verts[143];
    lvl1Floor[171].posA = lvl1Verts[157]; lvl1Floor[171].posB = lvl1Verts[156]; lvl1Floor[171].posC = lvl1Verts[139];
    lvl1Floor[172].posA = lvl1Verts[157]; lvl1Floor[172].posB = lvl1Verts[139]; lvl1Floor[172].posC = lvl1Verts[138];
    lvl1Floor[173].posA = lvl1Verts[139]; lvl1Floor[173].posB = lvl1Verts[134]; lvl1Floor[173].posC = lvl1Verts[137];
    lvl1Floor[174].posA = lvl1Verts[139]; lvl1Floor[174].posB = lvl1Verts[137]; lvl1Floor[174].posC = lvl1Verts[140];
    lvl1Floor[175].posA = lvl1Verts[156]; lvl1Floor[175].posB = lvl1Verts[153]; lvl1Floor[175].posC = lvl1Verts[134];
    lvl1Floor[176].posA = lvl1Verts[156]; lvl1Floor[176].posB = lvl1Verts[134]; lvl1Floor[176].posC = lvl1Verts[139];
    lvl1Floor[177].posA = lvl1Verts[153]; lvl1Floor[177].posB = lvl1Verts[152]; lvl1Floor[177].posC = lvl1Verts[135];
    lvl1Floor[178].posA = lvl1Verts[153]; lvl1Floor[178].posB = lvl1Verts[135]; lvl1Floor[178].posC = lvl1Verts[134];
    lvl1Floor[179].posA = lvl1Verts[224]; lvl1Floor[179].posB = lvl1Verts[130]; lvl1Floor[179].posC = lvl1Verts[133];
    lvl1Floor[180].posA = lvl1Verts[225]; lvl1Floor[180].posB = lvl1Verts[149]; lvl1Floor[180].posC = lvl1Verts[130];
    lvl1Floor[181].posA = lvl1Verts[225]; lvl1Floor[181].posB = lvl1Verts[130]; lvl1Floor[181].posC = lvl1Verts[224];
    lvl1Floor[182].posA = lvl1Verts[149]; lvl1Floor[182].posB = lvl1Verts[148]; lvl1Floor[182].posC = lvl1Verts[131];
    lvl1Floor[183].posA = lvl1Verts[149]; lvl1Floor[183].posB = lvl1Verts[131]; lvl1Floor[183].posC = lvl1Verts[130];
    lvl1Floor[184].posA = lvl1Verts[131]; lvl1Floor[184].posB = lvl1Verts[126]; lvl1Floor[184].posC = lvl1Verts[129];
    lvl1Floor[185].posA = lvl1Verts[131]; lvl1Floor[185].posB = lvl1Verts[129]; lvl1Floor[185].posC = lvl1Verts[132];
    lvl1Floor[186].posA = lvl1Verts[148]; lvl1Floor[186].posB = lvl1Verts[145]; lvl1Floor[186].posC = lvl1Verts[126];
    lvl1Floor[187].posA = lvl1Verts[148]; lvl1Floor[187].posB = lvl1Verts[126]; lvl1Floor[187].posC = lvl1Verts[131];
    lvl1Floor[188].posA = lvl1Verts[145]; lvl1Floor[188].posB = lvl1Verts[144]; lvl1Floor[188].posC = lvl1Verts[127];
    lvl1Floor[189].posA = lvl1Verts[145]; lvl1Floor[189].posB = lvl1Verts[127]; lvl1Floor[189].posC = lvl1Verts[126];
    lvl1Floor[190].posA = lvl1Verts[127]; lvl1Floor[190].posB = lvl1Verts[122]; lvl1Floor[190].posC = lvl1Verts[125];
    lvl1Floor[191].posA = lvl1Verts[127]; lvl1Floor[191].posB = lvl1Verts[125]; lvl1Floor[191].posC = lvl1Verts[128];
    lvl1Floor[192].posA = lvl1Verts[144]; lvl1Floor[192].posB = lvl1Verts[141]; lvl1Floor[192].posC = lvl1Verts[122];
    lvl1Floor[193].posA = lvl1Verts[144]; lvl1Floor[193].posB = lvl1Verts[122]; lvl1Floor[193].posC = lvl1Verts[127];
    lvl1Floor[194].posA = lvl1Verts[141]; lvl1Floor[194].posB = lvl1Verts[140]; lvl1Floor[194].posC = lvl1Verts[123];
    lvl1Floor[195].posA = lvl1Verts[141]; lvl1Floor[195].posB = lvl1Verts[123]; lvl1Floor[195].posC = lvl1Verts[122];
    lvl1Floor[196].posA = lvl1Verts[123]; lvl1Floor[196].posB = lvl1Verts[118]; lvl1Floor[196].posC = lvl1Verts[121];
    lvl1Floor[197].posA = lvl1Verts[123]; lvl1Floor[197].posB = lvl1Verts[121]; lvl1Floor[197].posC = lvl1Verts[124];
    lvl1Floor[198].posA = lvl1Verts[140]; lvl1Floor[198].posB = lvl1Verts[137]; lvl1Floor[198].posC = lvl1Verts[118];
    lvl1Floor[199].posA = lvl1Verts[140]; lvl1Floor[199].posB = lvl1Verts[118]; lvl1Floor[199].posC = lvl1Verts[123];
    lvl1Floor[200].posA = lvl1Verts[137]; lvl1Floor[200].posB = lvl1Verts[136]; lvl1Floor[200].posC = lvl1Verts[119];
    lvl1Floor[201].posA = lvl1Verts[137]; lvl1Floor[201].posB = lvl1Verts[119]; lvl1Floor[201].posC = lvl1Verts[118];
    lvl1Floor[202].posA = lvl1Verts[119]; lvl1Floor[202].posB = lvl1Verts[226]; lvl1Floor[202].posC = lvl1Verts[227];
    lvl1Floor[203].posA = lvl1Verts[119]; lvl1Floor[203].posB = lvl1Verts[227]; lvl1Floor[203].posC = lvl1Verts[120];
    lvl1Floor[204].posA = lvl1Verts[136]; lvl1Floor[204].posB = lvl1Verts[228]; lvl1Floor[204].posC = lvl1Verts[226];
    lvl1Floor[205].posA = lvl1Verts[136]; lvl1Floor[205].posB = lvl1Verts[226]; lvl1Floor[205].posC = lvl1Verts[119];
    lvl1Floor[206].posA = lvl1Verts[133]; lvl1Floor[206].posB = lvl1Verts[132]; lvl1Floor[206].posC = lvl1Verts[115];
    lvl1Floor[207].posA = lvl1Verts[133]; lvl1Floor[207].posB = lvl1Verts[115]; lvl1Floor[207].posC = lvl1Verts[114];
    lvl1Floor[208].posA = lvl1Verts[115]; lvl1Floor[208].posB = lvl1Verts[110]; lvl1Floor[208].posC = lvl1Verts[113];
    lvl1Floor[209].posA = lvl1Verts[115]; lvl1Floor[209].posB = lvl1Verts[113]; lvl1Floor[209].posC = lvl1Verts[116];
    lvl1Floor[210].posA = lvl1Verts[132]; lvl1Floor[210].posB = lvl1Verts[129]; lvl1Floor[210].posC = lvl1Verts[110];
    lvl1Floor[211].posA = lvl1Verts[132]; lvl1Floor[211].posB = lvl1Verts[110]; lvl1Floor[211].posC = lvl1Verts[115];
    lvl1Floor[212].posA = lvl1Verts[129]; lvl1Floor[212].posB = lvl1Verts[128]; lvl1Floor[212].posC = lvl1Verts[111];
    lvl1Floor[213].posA = lvl1Verts[129]; lvl1Floor[213].posB = lvl1Verts[111]; lvl1Floor[213].posC = lvl1Verts[110];
    lvl1Floor[214].posA = lvl1Verts[111]; lvl1Floor[214].posB = lvl1Verts[106]; lvl1Floor[214].posC = lvl1Verts[109];
    lvl1Floor[215].posA = lvl1Verts[111]; lvl1Floor[215].posB = lvl1Verts[109]; lvl1Floor[215].posC = lvl1Verts[112];
    lvl1Floor[216].posA = lvl1Verts[128]; lvl1Floor[216].posB = lvl1Verts[125]; lvl1Floor[216].posC = lvl1Verts[106];
    lvl1Floor[217].posA = lvl1Verts[128]; lvl1Floor[217].posB = lvl1Verts[106]; lvl1Floor[217].posC = lvl1Verts[111];
    lvl1Floor[218].posA = lvl1Verts[125]; lvl1Floor[218].posB = lvl1Verts[124]; lvl1Floor[218].posC = lvl1Verts[107];
    lvl1Floor[219].posA = lvl1Verts[125]; lvl1Floor[219].posB = lvl1Verts[107]; lvl1Floor[219].posC = lvl1Verts[106];
    lvl1Floor[220].posA = lvl1Verts[107]; lvl1Floor[220].posB = lvl1Verts[103]; lvl1Floor[220].posC = lvl1Verts[105];
    lvl1Floor[221].posA = lvl1Verts[107]; lvl1Floor[221].posB = lvl1Verts[105]; lvl1Floor[221].posC = lvl1Verts[108];
    lvl1Floor[222].posA = lvl1Verts[124]; lvl1Floor[222].posB = lvl1Verts[121]; lvl1Floor[222].posC = lvl1Verts[103];
    lvl1Floor[223].posA = lvl1Verts[124]; lvl1Floor[223].posB = lvl1Verts[103]; lvl1Floor[223].posC = lvl1Verts[107];
    lvl1Floor[224].posA = lvl1Verts[121]; lvl1Floor[224].posB = lvl1Verts[120]; lvl1Floor[224].posC = lvl1Verts[104];
    lvl1Floor[225].posA = lvl1Verts[121]; lvl1Floor[225].posB = lvl1Verts[104]; lvl1Floor[225].posC = lvl1Verts[103];
    lvl1Floor[226].posA = lvl1Verts[120]; lvl1Floor[226].posB = lvl1Verts[227]; lvl1Floor[226].posC = lvl1Verts[104];
    lvl1Floor[227].posA = lvl1Verts[229]; lvl1Floor[227].posB = lvl1Verts[99]; lvl1Floor[227].posC = lvl1Verts[102];
    lvl1Floor[228].posA = lvl1Verts[116]; lvl1Floor[228].posB = lvl1Verts[113]; lvl1Floor[228].posC = lvl1Verts[99];
    lvl1Floor[229].posA = lvl1Verts[116]; lvl1Floor[229].posB = lvl1Verts[99]; lvl1Floor[229].posC = lvl1Verts[229];
    lvl1Floor[230].posA = lvl1Verts[113]; lvl1Floor[230].posB = lvl1Verts[112]; lvl1Floor[230].posC = lvl1Verts[100];
    lvl1Floor[231].posA = lvl1Verts[113]; lvl1Floor[231].posB = lvl1Verts[100]; lvl1Floor[231].posC = lvl1Verts[99];
    lvl1Floor[232].posA = lvl1Verts[100]; lvl1Floor[232].posB = lvl1Verts[95]; lvl1Floor[232].posC = lvl1Verts[98];
    lvl1Floor[233].posA = lvl1Verts[100]; lvl1Floor[233].posB = lvl1Verts[98]; lvl1Floor[233].posC = lvl1Verts[101];
    lvl1Floor[234].posA = lvl1Verts[112]; lvl1Floor[234].posB = lvl1Verts[109]; lvl1Floor[234].posC = lvl1Verts[95];
    lvl1Floor[235].posA = lvl1Verts[112]; lvl1Floor[235].posB = lvl1Verts[95]; lvl1Floor[235].posC = lvl1Verts[100];
    lvl1Floor[236].posA = lvl1Verts[109]; lvl1Floor[236].posB = lvl1Verts[108]; lvl1Floor[236].posC = lvl1Verts[96];
    lvl1Floor[237].posA = lvl1Verts[109]; lvl1Floor[237].posB = lvl1Verts[96]; lvl1Floor[237].posC = lvl1Verts[95];
    lvl1Floor[238].posA = lvl1Verts[98]; lvl1Floor[238].posB = lvl1Verts[97]; lvl1Floor[238].posC = lvl1Verts[230];
    lvl1Floor[239].posA = lvl1Verts[207]; lvl1Floor[239].posB = lvl1Verts[15]; lvl1Floor[239].posC = lvl1Verts[14];
    lvl1Floor[240].posA = lvl1Verts[207]; lvl1Floor[240].posB = lvl1Verts[14]; lvl1Floor[240].posC = lvl1Verts[231];
    lvl1Floor[241].posA = lvl1Verts[206]; lvl1Floor[241].posB = lvl1Verts[207]; lvl1Floor[241].posC = lvl1Verts[231];
    lvl1Floor[242].posA = lvl1Verts[163]; lvl1Floor[242].posB = lvl1Verts[216]; lvl1Floor[242].posC = lvl1Verts[164];
    lvl1Floor[243].posA = lvl1Verts[225]; lvl1Floor[243].posB = lvl1Verts[146]; lvl1Floor[243].posC = lvl1Verts[149];
    lvl1Floor[244].posA = lvl1Verts[228]; lvl1Floor[244].posB = lvl1Verts[136]; lvl1Floor[244].posC = lvl1Verts[135];
    lvl1Floor[245].posA = lvl1Verts[215]; lvl1Floor[245].posB = lvl1Verts[214]; lvl1Floor[245].posC = lvl1Verts[213];
    lvl1Floor[246].posA = lvl1Verts[147]; lvl1Floor[246].posB = lvl1Verts[161]; lvl1Floor[246].posC = lvl1Verts[142];
    lvl1Floor[247].posA = lvl1Verts[232]; lvl1Floor[247].posB = lvl1Verts[94]; lvl1Floor[247].posC = lvl1Verts[90];
    lvl1Floor[248].posA = lvl1Verts[232]; lvl1Floor[248].posB = lvl1Verts[90]; lvl1Floor[248].posC = lvl1Verts[67];
    lvl1Floor[249].posA = lvl1Verts[71]; lvl1Floor[249].posB = lvl1Verts[89]; lvl1Floor[249].posC = lvl1Verts[232];
    lvl1Floor[250].posA = lvl1Verts[71]; lvl1Floor[250].posB = lvl1Verts[232]; lvl1Floor[250].posC = lvl1Verts[67];
    lvl1Floor[251].posA = lvl1Verts[68]; lvl1Floor[251].posB = lvl1Verts[90]; lvl1Floor[251].posC = lvl1Verts[233];
    lvl1Floor[252].posA = lvl1Verts[68]; lvl1Floor[252].posB = lvl1Verts[233]; lvl1Floor[252].posC = lvl1Verts[77];
    lvl1Floor[253].posA = lvl1Verts[94]; lvl1Floor[253].posB = lvl1Verts[232]; lvl1Floor[253].posC = lvl1Verts[91];
    lvl1Floor[254].posA = lvl1Verts[90]; lvl1Floor[254].posB = lvl1Verts[94]; lvl1Floor[254].posC = lvl1Verts[93];
    lvl1Floor[255].posA = lvl1Verts[90]; lvl1Floor[255].posB = lvl1Verts[93]; lvl1Floor[255].posC = lvl1Verts[233];
    lvl1Floor[256].posA = lvl1Verts[89]; lvl1Floor[256].posB = lvl1Verts[88]; lvl1Floor[256].posC = lvl1Verts[91];
    lvl1Floor[257].posA = lvl1Verts[89]; lvl1Floor[257].posB = lvl1Verts[91]; lvl1Floor[257].posC = lvl1Verts[232];
    lvl1Floor[258].posA = lvl1Verts[73]; lvl1Floor[258].posB = lvl1Verts[87]; lvl1Floor[258].posC = lvl1Verts[70];
    lvl1Wall[0].posA = lvl1Verts[234]; lvl1Wall[0].posB = lvl1Verts[235]; lvl1Wall[0].posC = lvl1Verts[236];
    lvl1Wall[1].posA = lvl1Verts[234]; lvl1Wall[1].posB = lvl1Verts[236]; lvl1Wall[1].posC = lvl1Verts[237];
    lvl1Wall[2].posA = lvl1Verts[238]; lvl1Wall[2].posB = lvl1Verts[239]; lvl1Wall[2].posC = lvl1Verts[240];
    lvl1Wall[3].posA = lvl1Verts[240]; lvl1Wall[3].posB = lvl1Verts[241]; lvl1Wall[3].posC = lvl1Verts[242];
    lvl1Wall[4].posA = lvl1Verts[240]; lvl1Wall[4].posB = lvl1Verts[242]; lvl1Wall[4].posC = lvl1Verts[238];
    lvl1Wall[5].posA = lvl1Verts[243]; lvl1Wall[5].posB = lvl1Verts[244]; lvl1Wall[5].posC = lvl1Verts[245];
    lvl1Wall[6].posA = lvl1Verts[243]; lvl1Wall[6].posB = lvl1Verts[245]; lvl1Wall[6].posC = lvl1Verts[246];
    lvl1Wall[7].posA = lvl1Verts[247]; lvl1Wall[7].posB = lvl1Verts[248]; lvl1Wall[7].posC = lvl1Verts[249];
    lvl1Wall[8].posA = lvl1Verts[247]; lvl1Wall[8].posB = lvl1Verts[249]; lvl1Wall[8].posC = lvl1Verts[250];
    lvl1Wall[9].posA = lvl1Verts[251]; lvl1Wall[9].posB = lvl1Verts[252]; lvl1Wall[9].posC = lvl1Verts[253];
    lvl1Wall[10].posA = lvl1Verts[251]; lvl1Wall[10].posB = lvl1Verts[253]; lvl1Wall[10].posC = lvl1Verts[254];
    lvl1Wall[11].posA = lvl1Verts[255]; lvl1Wall[11].posB = lvl1Verts[256]; lvl1Wall[11].posC = lvl1Verts[257];
    lvl1Wall[12].posA = lvl1Verts[255]; lvl1Wall[12].posB = lvl1Verts[257]; lvl1Wall[12].posC = lvl1Verts[258];
    lvl1Wall[13].posA = lvl1Verts[259]; lvl1Wall[13].posB = lvl1Verts[260]; lvl1Wall[13].posC = lvl1Verts[261];
    lvl1Wall[14].posA = lvl1Verts[259]; lvl1Wall[14].posB = lvl1Verts[261]; lvl1Wall[14].posC = lvl1Verts[262];
    lvl1Wall[15].posA = lvl1Verts[263]; lvl1Wall[15].posB = lvl1Verts[264]; lvl1Wall[15].posC = lvl1Verts[265];
    lvl1Wall[16].posA = lvl1Verts[263]; lvl1Wall[16].posB = lvl1Verts[265]; lvl1Wall[16].posC = lvl1Verts[266];
    lvl1Wall[17].posA = lvl1Verts[250]; lvl1Wall[17].posB = lvl1Verts[249]; lvl1Wall[17].posC = lvl1Verts[267];
    lvl1Wall[18].posA = lvl1Verts[250]; lvl1Wall[18].posB = lvl1Verts[267]; lvl1Wall[18].posC = lvl1Verts[268];
    lvl1Wall[19].posA = lvl1Verts[269]; lvl1Wall[19].posB = lvl1Verts[270]; lvl1Wall[19].posC = lvl1Verts[271];
    lvl1Wall[20].posA = lvl1Verts[269]; lvl1Wall[20].posB = lvl1Verts[271]; lvl1Wall[20].posC = lvl1Verts[272];
    lvl1Wall[21].posA = lvl1Verts[273]; lvl1Wall[21].posB = lvl1Verts[274]; lvl1Wall[21].posC = lvl1Verts[275];
    lvl1Wall[22].posA = lvl1Verts[273]; lvl1Wall[22].posB = lvl1Verts[275]; lvl1Wall[22].posC = lvl1Verts[276];
    lvl1Wall[23].posA = lvl1Verts[277]; lvl1Wall[23].posB = lvl1Verts[278]; lvl1Wall[23].posC = lvl1Verts[279];
    lvl1Wall[24].posA = lvl1Verts[277]; lvl1Wall[24].posB = lvl1Verts[279]; lvl1Wall[24].posC = lvl1Verts[280];
    lvl1Wall[25].posA = lvl1Verts[281]; lvl1Wall[25].posB = lvl1Verts[282]; lvl1Wall[25].posC = lvl1Verts[283];
    lvl1Wall[26].posA = lvl1Verts[281]; lvl1Wall[26].posB = lvl1Verts[283]; lvl1Wall[26].posC = lvl1Verts[284];
    lvl1Wall[27].posA = lvl1Verts[285]; lvl1Wall[27].posB = lvl1Verts[286]; lvl1Wall[27].posC = lvl1Verts[248];
    lvl1Wall[28].posA = lvl1Verts[285]; lvl1Wall[28].posB = lvl1Verts[248]; lvl1Wall[28].posC = lvl1Verts[247];
    lvl1Wall[29].posA = lvl1Verts[287]; lvl1Wall[29].posB = lvl1Verts[288]; lvl1Wall[29].posC = lvl1Verts[289];
    lvl1Wall[30].posA = lvl1Verts[287]; lvl1Wall[30].posB = lvl1Verts[289]; lvl1Wall[30].posC = lvl1Verts[290];
    lvl1Wall[31].posA = lvl1Verts[291]; lvl1Wall[31].posB = lvl1Verts[292]; lvl1Wall[31].posC = lvl1Verts[293];
    lvl1Wall[32].posA = lvl1Verts[291]; lvl1Wall[32].posB = lvl1Verts[293]; lvl1Wall[32].posC = lvl1Verts[294];
    lvl1Wall[33].posA = lvl1Verts[295]; lvl1Wall[33].posB = lvl1Verts[296]; lvl1Wall[33].posC = lvl1Verts[278];
    lvl1Wall[34].posA = lvl1Verts[295]; lvl1Wall[34].posB = lvl1Verts[278]; lvl1Wall[34].posC = lvl1Verts[277];
    lvl1Wall[35].posA = lvl1Verts[297]; lvl1Wall[35].posB = lvl1Verts[298]; lvl1Wall[35].posC = lvl1Verts[299];
    lvl1Wall[36].posA = lvl1Verts[297]; lvl1Wall[36].posB = lvl1Verts[299]; lvl1Wall[36].posC = lvl1Verts[300];
    lvl1Wall[37].posA = lvl1Verts[301]; lvl1Wall[37].posB = lvl1Verts[302]; lvl1Wall[37].posC = lvl1Verts[303];
    lvl1Wall[38].posA = lvl1Verts[301]; lvl1Wall[38].posB = lvl1Verts[303]; lvl1Wall[38].posC = lvl1Verts[304];
    lvl1Wall[39].posA = lvl1Verts[290]; lvl1Wall[39].posB = lvl1Verts[289]; lvl1Wall[39].posC = lvl1Verts[305];
    lvl1Wall[40].posA = lvl1Verts[290]; lvl1Wall[40].posB = lvl1Verts[305]; lvl1Wall[40].posC = lvl1Verts[306];
    lvl1Wall[41].posA = lvl1Verts[280]; lvl1Wall[41].posB = lvl1Verts[279]; lvl1Wall[41].posC = lvl1Verts[307];
    lvl1Wall[42].posA = lvl1Verts[280]; lvl1Wall[42].posB = lvl1Verts[307]; lvl1Wall[42].posC = lvl1Verts[308];
    lvl1Wall[43].posA = lvl1Verts[300]; lvl1Wall[43].posB = lvl1Verts[299]; lvl1Wall[43].posC = lvl1Verts[309];
    lvl1Wall[44].posA = lvl1Verts[300]; lvl1Wall[44].posB = lvl1Verts[309]; lvl1Wall[44].posC = lvl1Verts[310];
    lvl1Wall[45].posA = lvl1Verts[241]; lvl1Wall[45].posB = lvl1Verts[240]; lvl1Wall[45].posC = lvl1Verts[302];
    lvl1Wall[46].posA = lvl1Verts[241]; lvl1Wall[46].posB = lvl1Verts[302]; lvl1Wall[46].posC = lvl1Verts[301];
    lvl1Wall[47].posA = lvl1Verts[311]; lvl1Wall[47].posB = lvl1Verts[312]; lvl1Wall[47].posC = lvl1Verts[313];
    lvl1Wall[48].posA = lvl1Verts[311]; lvl1Wall[48].posB = lvl1Verts[313]; lvl1Wall[48].posC = lvl1Verts[314];
    lvl1Wall[49].posA = lvl1Verts[315]; lvl1Wall[49].posB = lvl1Verts[316]; lvl1Wall[49].posC = lvl1Verts[317];
    lvl1Wall[50].posA = lvl1Verts[315]; lvl1Wall[50].posB = lvl1Verts[317]; lvl1Wall[50].posC = lvl1Verts[318];
    lvl1Wall[51].posA = lvl1Verts[319]; lvl1Wall[51].posB = lvl1Verts[320]; lvl1Wall[51].posC = lvl1Verts[321];
    lvl1Wall[52].posA = lvl1Verts[319]; lvl1Wall[52].posB = lvl1Verts[321]; lvl1Wall[52].posC = lvl1Verts[322];
    lvl1Wall[53].posA = lvl1Verts[323]; lvl1Wall[53].posB = lvl1Verts[324]; lvl1Wall[53].posC = lvl1Verts[325];
    lvl1Wall[54].posA = lvl1Verts[323]; lvl1Wall[54].posB = lvl1Verts[325]; lvl1Wall[54].posC = lvl1Verts[326];
    lvl1Wall[55].posA = lvl1Verts[327]; lvl1Wall[55].posB = lvl1Verts[328]; lvl1Wall[55].posC = lvl1Verts[329];
    lvl1Wall[56].posA = lvl1Verts[327]; lvl1Wall[56].posB = lvl1Verts[329]; lvl1Wall[56].posC = lvl1Verts[330];
    lvl1Wall[57].posA = lvl1Verts[331]; lvl1Wall[57].posB = lvl1Verts[332]; lvl1Wall[57].posC = lvl1Verts[333];
    lvl1Wall[58].posA = lvl1Verts[331]; lvl1Wall[58].posB = lvl1Verts[333]; lvl1Wall[58].posC = lvl1Verts[334];
    lvl1Wall[59].posA = lvl1Verts[306]; lvl1Wall[59].posB = lvl1Verts[305]; lvl1Wall[59].posC = lvl1Verts[335];
    lvl1Wall[60].posA = lvl1Verts[306]; lvl1Wall[60].posB = lvl1Verts[335]; lvl1Wall[60].posC = lvl1Verts[336];
    lvl1Wall[61].posA = lvl1Verts[308]; lvl1Wall[61].posB = lvl1Verts[307]; lvl1Wall[61].posC = lvl1Verts[312];
    lvl1Wall[62].posA = lvl1Verts[308]; lvl1Wall[62].posB = lvl1Verts[312]; lvl1Wall[62].posC = lvl1Verts[311];
    lvl1Wall[63].posA = lvl1Verts[337]; lvl1Wall[63].posB = lvl1Verts[264]; lvl1Wall[63].posC = lvl1Verts[263];
    lvl1Wall[64].posA = lvl1Verts[337]; lvl1Wall[64].posB = lvl1Verts[263]; lvl1Wall[64].posC = lvl1Verts[338];
    lvl1Wall[65].posA = lvl1Verts[297]; lvl1Wall[65].posB = lvl1Verts[339]; lvl1Wall[65].posC = lvl1Verts[340];
    lvl1Wall[66].posA = lvl1Verts[297]; lvl1Wall[66].posB = lvl1Verts[340]; lvl1Wall[66].posC = lvl1Verts[298];
    lvl1Wall[67].posA = lvl1Verts[341]; lvl1Wall[67].posB = lvl1Verts[342]; lvl1Wall[67].posC = lvl1Verts[296];
    lvl1Wall[68].posA = lvl1Verts[341]; lvl1Wall[68].posB = lvl1Verts[296]; lvl1Wall[68].posC = lvl1Verts[295];
    lvl1Wall[69].posA = lvl1Verts[262]; lvl1Wall[69].posB = lvl1Verts[261]; lvl1Wall[69].posC = lvl1Verts[343];
    lvl1Wall[70].posA = lvl1Verts[262]; lvl1Wall[70].posB = lvl1Verts[343]; lvl1Wall[70].posC = lvl1Verts[344];
    lvl1Wall[71].posA = lvl1Verts[345]; lvl1Wall[71].posB = lvl1Verts[346]; lvl1Wall[71].posC = lvl1Verts[347];
    lvl1Wall[72].posA = lvl1Verts[345]; lvl1Wall[72].posB = lvl1Verts[347]; lvl1Wall[72].posC = lvl1Verts[348];
    lvl1Wall[73].posA = lvl1Verts[349]; lvl1Wall[73].posB = lvl1Verts[350]; lvl1Wall[73].posC = lvl1Verts[351];
    lvl1Wall[74].posA = lvl1Verts[349]; lvl1Wall[74].posB = lvl1Verts[351]; lvl1Wall[74].posC = lvl1Verts[352];
    lvl1Wall[75].posA = lvl1Verts[353]; lvl1Wall[75].posB = lvl1Verts[354]; lvl1Wall[75].posC = lvl1Verts[320];
    lvl1Wall[76].posA = lvl1Verts[353]; lvl1Wall[76].posB = lvl1Verts[320]; lvl1Wall[76].posC = lvl1Verts[319];
    lvl1Wall[77].posA = lvl1Verts[355]; lvl1Wall[77].posB = lvl1Verts[356]; lvl1Wall[77].posC = lvl1Verts[357];
    lvl1Wall[78].posA = lvl1Verts[355]; lvl1Wall[78].posB = lvl1Verts[357]; lvl1Wall[78].posC = lvl1Verts[358];
    lvl1Wall[79].posA = lvl1Verts[359]; lvl1Wall[79].posB = lvl1Verts[360]; lvl1Wall[79].posC = lvl1Verts[361];
    lvl1Wall[80].posA = lvl1Verts[359]; lvl1Wall[80].posB = lvl1Verts[361]; lvl1Wall[80].posC = lvl1Verts[362];
    lvl1Wall[81].posA = lvl1Verts[363]; lvl1Wall[81].posB = lvl1Verts[364]; lvl1Wall[81].posC = lvl1Verts[362];
    lvl1Wall[82].posA = lvl1Verts[363]; lvl1Wall[82].posB = lvl1Verts[362]; lvl1Wall[82].posC = lvl1Verts[361];
    lvl1Wall[83].posA = lvl1Verts[365]; lvl1Wall[83].posB = lvl1Verts[366]; lvl1Wall[83].posC = lvl1Verts[367];
    lvl1Wall[84].posA = lvl1Verts[365]; lvl1Wall[84].posB = lvl1Verts[367]; lvl1Wall[84].posC = lvl1Verts[368];
    lvl1Wall[85].posA = lvl1Verts[369]; lvl1Wall[85].posB = lvl1Verts[370]; lvl1Wall[85].posC = lvl1Verts[255];
    lvl1Wall[86].posA = lvl1Verts[369]; lvl1Wall[86].posB = lvl1Verts[255]; lvl1Wall[86].posC = lvl1Verts[258];
    lvl1Wall[87].posA = lvl1Verts[371]; lvl1Wall[87].posB = lvl1Verts[372]; lvl1Wall[87].posC = lvl1Verts[373];
    lvl1Wall[88].posA = lvl1Verts[371]; lvl1Wall[88].posB = lvl1Verts[373]; lvl1Wall[88].posC = lvl1Verts[374];
    lvl1Wall[89].posA = lvl1Verts[375]; lvl1Wall[89].posB = lvl1Verts[376]; lvl1Wall[89].posC = lvl1Verts[377];
    lvl1Wall[90].posA = lvl1Verts[375]; lvl1Wall[90].posB = lvl1Verts[377]; lvl1Wall[90].posC = lvl1Verts[378];
    lvl1Wall[91].posA = lvl1Verts[379]; lvl1Wall[91].posB = lvl1Verts[380]; lvl1Wall[91].posC = lvl1Verts[381];
    lvl1Wall[92].posA = lvl1Verts[379]; lvl1Wall[92].posB = lvl1Verts[381]; lvl1Wall[92].posC = lvl1Verts[382];
    lvl1Wall[93].posA = lvl1Verts[383]; lvl1Wall[93].posB = lvl1Verts[384]; lvl1Wall[93].posC = lvl1Verts[382];
    lvl1Wall[94].posA = lvl1Verts[383]; lvl1Wall[94].posB = lvl1Verts[382]; lvl1Wall[94].posC = lvl1Verts[381];
    lvl1Wall[95].posA = lvl1Verts[385]; lvl1Wall[95].posB = lvl1Verts[386]; lvl1Wall[95].posC = lvl1Verts[387];
    lvl1Wall[96].posA = lvl1Verts[385]; lvl1Wall[96].posB = lvl1Verts[387]; lvl1Wall[96].posC = lvl1Verts[388];
    lvl1Wall[97].posA = lvl1Verts[294]; lvl1Wall[97].posB = lvl1Verts[293]; lvl1Wall[97].posC = lvl1Verts[286];
    lvl1Wall[98].posA = lvl1Verts[294]; lvl1Wall[98].posB = lvl1Verts[286]; lvl1Wall[98].posC = lvl1Verts[285];
    lvl1Wall[99].posA = lvl1Verts[344]; lvl1Wall[99].posB = lvl1Verts[343]; lvl1Wall[99].posC = lvl1Verts[342];
    lvl1Wall[100].posA = lvl1Verts[344]; lvl1Wall[100].posB = lvl1Verts[342]; lvl1Wall[100].posC = lvl1Verts[341];
    lvl1Wall[101].posA = lvl1Verts[260]; lvl1Wall[101].posB = lvl1Verts[259]; lvl1Wall[101].posC = lvl1Verts[389];
    lvl1Wall[102].posA = lvl1Verts[260]; lvl1Wall[102].posB = lvl1Verts[389]; lvl1Wall[102].posC = lvl1Verts[390];
    lvl1Wall[103].posA = lvl1Verts[336]; lvl1Wall[103].posB = lvl1Verts[335]; lvl1Wall[103].posC = lvl1Verts[390];
    lvl1Wall[104].posA = lvl1Verts[336]; lvl1Wall[104].posB = lvl1Verts[390]; lvl1Wall[104].posC = lvl1Verts[389];
    lvl1Wall[105].posA = lvl1Verts[304]; lvl1Wall[105].posB = lvl1Verts[303]; lvl1Wall[105].posC = lvl1Verts[288];
    lvl1Wall[106].posA = lvl1Verts[304]; lvl1Wall[106].posB = lvl1Verts[288]; lvl1Wall[106].posC = lvl1Verts[287];
    lvl1Wall[107].posA = lvl1Verts[388]; lvl1Wall[107].posB = lvl1Verts[387]; lvl1Wall[107].posC = lvl1Verts[337];
    lvl1Wall[108].posA = lvl1Verts[388]; lvl1Wall[108].posB = lvl1Verts[337]; lvl1Wall[108].posC = lvl1Verts[338];
    lvl1Wall[109].posA = lvl1Verts[268]; lvl1Wall[109].posB = lvl1Verts[267]; lvl1Wall[109].posC = lvl1Verts[386];
    lvl1Wall[110].posA = lvl1Verts[268]; lvl1Wall[110].posB = lvl1Verts[386]; lvl1Wall[110].posC = lvl1Verts[385];
    lvl1Wall[111].posA = lvl1Verts[253]; lvl1Wall[111].posB = lvl1Verts[252]; lvl1Wall[111].posC = lvl1Verts[391];
    lvl1Wall[112].posA = lvl1Verts[253]; lvl1Wall[112].posB = lvl1Verts[391]; lvl1Wall[112].posC = lvl1Verts[392];
    lvl1Wall[113].posA = lvl1Verts[340]; lvl1Wall[113].posB = lvl1Verts[339]; lvl1Wall[113].posC = lvl1Verts[251];
    lvl1Wall[114].posA = lvl1Verts[340]; lvl1Wall[114].posB = lvl1Verts[251]; lvl1Wall[114].posC = lvl1Verts[254];
    lvl1Wall[115].posA = lvl1Verts[257]; lvl1Wall[115].posB = lvl1Verts[256]; lvl1Wall[115].posC = lvl1Verts[266];
    lvl1Wall[116].posA = lvl1Verts[257]; lvl1Wall[116].posB = lvl1Verts[266]; lvl1Wall[116].posC = lvl1Verts[265];
    lvl1Wall[117].posA = lvl1Verts[313]; lvl1Wall[117].posB = lvl1Verts[292]; lvl1Wall[117].posC = lvl1Verts[291];
    lvl1Wall[118].posA = lvl1Verts[313]; lvl1Wall[118].posB = lvl1Verts[291]; lvl1Wall[118].posC = lvl1Verts[314];
    lvl1Wall[119].posA = lvl1Verts[80]; lvl1Wall[119].posB = lvl1Verts[79]; lvl1Wall[119].posC = lvl1Verts[393];
    lvl1Wall[120].posA = lvl1Verts[80]; lvl1Wall[120].posB = lvl1Verts[393]; lvl1Wall[120].posC = lvl1Verts[394];
    lvl1Wall[121].posA = lvl1Verts[84]; lvl1Wall[121].posB = lvl1Verts[86]; lvl1Wall[121].posC = lvl1Verts[395];
    lvl1Wall[122].posA = lvl1Verts[84]; lvl1Wall[122].posB = lvl1Verts[395]; lvl1Wall[122].posC = lvl1Verts[396];
    lvl1Wall[123].posA = lvl1Verts[82]; lvl1Wall[123].posB = lvl1Verts[84]; lvl1Wall[123].posC = lvl1Verts[396];
    lvl1Wall[124].posA = lvl1Verts[82]; lvl1Wall[124].posB = lvl1Verts[396]; lvl1Wall[124].posC = lvl1Verts[397];
    lvl1Wall[125].posA = lvl1Verts[83]; lvl1Wall[125].posB = lvl1Verts[82]; lvl1Wall[125].posC = lvl1Verts[397];
    lvl1Wall[126].posA = lvl1Verts[83]; lvl1Wall[126].posB = lvl1Verts[397]; lvl1Wall[126].posC = lvl1Verts[291];
    lvl1Wall[127].posA = lvl1Verts[85]; lvl1Wall[127].posB = lvl1Verts[83]; lvl1Wall[127].posC = lvl1Verts[291];
    lvl1Wall[128].posA = lvl1Verts[85]; lvl1Wall[128].posB = lvl1Verts[291]; lvl1Wall[128].posC = lvl1Verts[398];
    lvl1Wall[129].posA = lvl1Verts[86]; lvl1Wall[129].posB = lvl1Verts[80]; lvl1Wall[129].posC = lvl1Verts[394];
    lvl1Wall[130].posA = lvl1Verts[86]; lvl1Wall[130].posB = lvl1Verts[394]; lvl1Wall[130].posC = lvl1Verts[395];
    lvl1Wall[131].posA = lvl1Verts[78]; lvl1Wall[131].posB = lvl1Verts[85]; lvl1Wall[131].posC = lvl1Verts[398];
    lvl1Wall[132].posA = lvl1Verts[78]; lvl1Wall[132].posB = lvl1Verts[398]; lvl1Wall[132].posC = lvl1Verts[399];
    lvl1Wall[133].posA = lvl1Verts[79]; lvl1Wall[133].posB = lvl1Verts[78]; lvl1Wall[133].posC = lvl1Verts[399];
    lvl1Wall[134].posA = lvl1Verts[79]; lvl1Wall[134].posB = lvl1Verts[399]; lvl1Wall[134].posC = lvl1Verts[393];
    lvl1Wall[135].posA = lvl1Verts[283]; lvl1Wall[135].posB = lvl1Verts[282]; lvl1Wall[135].posC = lvl1Verts[380];
    lvl1Wall[136].posA = lvl1Verts[283]; lvl1Wall[136].posB = lvl1Verts[380]; lvl1Wall[136].posC = lvl1Verts[379];
    lvl1Wall[137].posA = lvl1Verts[330]; lvl1Wall[137].posB = lvl1Verts[329]; lvl1Wall[137].posC = lvl1Verts[376];
    lvl1Wall[138].posA = lvl1Verts[330]; lvl1Wall[138].posB = lvl1Verts[376]; lvl1Wall[138].posC = lvl1Verts[375];
    lvl1Wall[139].posA = lvl1Verts[348]; lvl1Wall[139].posB = lvl1Verts[347]; lvl1Wall[139].posC = lvl1Verts[372];
    lvl1Wall[140].posA = lvl1Verts[348]; lvl1Wall[140].posB = lvl1Verts[372]; lvl1Wall[140].posC = lvl1Verts[371];
    lvl1Wall[141].posA = lvl1Verts[236]; lvl1Wall[141].posB = lvl1Verts[235]; lvl1Wall[141].posC = lvl1Verts[370];
    lvl1Wall[142].posA = lvl1Verts[236]; lvl1Wall[142].posB = lvl1Verts[370]; lvl1Wall[142].posC = lvl1Verts[369];
    lvl1Wall[143].posA = lvl1Verts[334]; lvl1Wall[143].posB = lvl1Verts[333]; lvl1Wall[143].posC = lvl1Verts[364];
    lvl1Wall[144].posA = lvl1Verts[334]; lvl1Wall[144].posB = lvl1Verts[364]; lvl1Wall[144].posC = lvl1Verts[363];
    lvl1Wall[145].posA = lvl1Verts[400]; lvl1Wall[145].posB = lvl1Verts[401]; lvl1Wall[145].posC = lvl1Verts[346];
    lvl1Wall[146].posA = lvl1Verts[400]; lvl1Wall[146].posB = lvl1Verts[346]; lvl1Wall[146].posC = lvl1Verts[345];
    lvl1Wall[147].posA = lvl1Verts[368]; lvl1Wall[147].posB = lvl1Verts[367]; lvl1Wall[147].posC = lvl1Verts[332];
    lvl1Wall[148].posA = lvl1Verts[368]; lvl1Wall[148].posB = lvl1Verts[332]; lvl1Wall[148].posC = lvl1Verts[331];
    lvl1Wall[149].posA = lvl1Verts[402]; lvl1Wall[149].posB = lvl1Verts[403]; lvl1Wall[149].posC = lvl1Verts[328];
    lvl1Wall[150].posA = lvl1Verts[402]; lvl1Wall[150].posB = lvl1Verts[328]; lvl1Wall[150].posC = lvl1Verts[327];
    lvl1Wall[151].posA = lvl1Verts[402]; lvl1Wall[151].posB = lvl1Verts[281]; lvl1Wall[151].posC = lvl1Verts[284];
    lvl1Wall[152].posA = lvl1Verts[402]; lvl1Wall[152].posB = lvl1Verts[284]; lvl1Wall[152].posC = lvl1Verts[403];
    lvl1Wall[153].posA = lvl1Verts[373]; lvl1Wall[153].posB = lvl1Verts[234]; lvl1Wall[153].posC = lvl1Verts[237];
    lvl1Wall[154].posA = lvl1Verts[373]; lvl1Wall[154].posB = lvl1Verts[237]; lvl1Wall[154].posC = lvl1Verts[374];
    lvl1Wall[155].posA = lvl1Verts[245]; lvl1Wall[155].posB = lvl1Verts[244]; lvl1Wall[155].posC = lvl1Verts[384];
    lvl1Wall[156].posA = lvl1Verts[245]; lvl1Wall[156].posB = lvl1Verts[384]; lvl1Wall[156].posC = lvl1Verts[383];
    lvl1Wall[157].posA = lvl1Verts[322]; lvl1Wall[157].posB = lvl1Verts[321]; lvl1Wall[157].posC = lvl1Verts[350];
    lvl1Wall[158].posA = lvl1Verts[322]; lvl1Wall[158].posB = lvl1Verts[350]; lvl1Wall[158].posC = lvl1Verts[349];
    lvl1Wall[159].posA = lvl1Verts[352]; lvl1Wall[159].posB = lvl1Verts[351]; lvl1Wall[159].posC = lvl1Verts[378];
    lvl1Wall[160].posA = lvl1Verts[352]; lvl1Wall[160].posB = lvl1Verts[378]; lvl1Wall[160].posC = lvl1Verts[377];
    lvl1Wall[161].posA = lvl1Verts[275]; lvl1Wall[161].posB = lvl1Verts[274]; lvl1Wall[161].posC = lvl1Verts[360];
    lvl1Wall[162].posA = lvl1Verts[275]; lvl1Wall[162].posB = lvl1Verts[360]; lvl1Wall[162].posC = lvl1Verts[359];
    lvl1Wall[163].posA = lvl1Verts[272]; lvl1Wall[163].posB = lvl1Verts[271]; lvl1Wall[163].posC = lvl1Verts[356];
    lvl1Wall[164].posA = lvl1Verts[272]; lvl1Wall[164].posB = lvl1Verts[356]; lvl1Wall[164].posC = lvl1Verts[355];
    lvl1Wall[165].posA = lvl1Verts[404]; lvl1Wall[165].posB = lvl1Verts[273]; lvl1Wall[165].posC = lvl1Verts[276];
    lvl1Wall[166].posA = lvl1Verts[404]; lvl1Wall[166].posB = lvl1Verts[276]; lvl1Wall[166].posC = lvl1Verts[405];
    lvl1Wall[167].posA = lvl1Verts[404]; lvl1Wall[167].posB = lvl1Verts[405]; lvl1Wall[167].posC = lvl1Verts[270];
    lvl1Wall[168].posA = lvl1Verts[404]; lvl1Wall[168].posB = lvl1Verts[270]; lvl1Wall[168].posC = lvl1Verts[269];
    lvl1Wall[169].posA = lvl1Verts[391]; lvl1Wall[169].posB = lvl1Verts[243]; lvl1Wall[169].posC = lvl1Verts[246];
    lvl1Wall[170].posA = lvl1Verts[391]; lvl1Wall[170].posB = lvl1Verts[246]; lvl1Wall[170].posC = lvl1Verts[392];
    lvl1Wall[171].posA = lvl1Verts[326]; lvl1Wall[171].posB = lvl1Verts[325]; lvl1Wall[171].posC = lvl1Verts[366];
    lvl1Wall[172].posA = lvl1Verts[326]; lvl1Wall[172].posB = lvl1Verts[366]; lvl1Wall[172].posC = lvl1Verts[365];
    lvl1Wall[173].posA = lvl1Verts[318]; lvl1Wall[173].posB = lvl1Verts[317]; lvl1Wall[173].posC = lvl1Verts[354];
    lvl1Wall[174].posA = lvl1Verts[318]; lvl1Wall[174].posB = lvl1Verts[354]; lvl1Wall[174].posC = lvl1Verts[353];
    lvl1Wall[175].posA = lvl1Verts[401]; lvl1Wall[175].posB = lvl1Verts[400]; lvl1Wall[175].posC = lvl1Verts[324];
    lvl1Wall[176].posA = lvl1Verts[401]; lvl1Wall[176].posB = lvl1Verts[324]; lvl1Wall[176].posC = lvl1Verts[323];
    lvl1Wall[177].posA = lvl1Verts[358]; lvl1Wall[177].posB = lvl1Verts[357]; lvl1Wall[177].posC = lvl1Verts[316];
    lvl1Wall[178].posA = lvl1Verts[358]; lvl1Wall[178].posB = lvl1Verts[316]; lvl1Wall[178].posC = lvl1Verts[315];
    lvl1Wall[179].posA = lvl1Verts[239]; lvl1Wall[179].posB = lvl1Verts[238]; lvl1Wall[179].posC = lvl1Verts[406];
    lvl1Wall[180].posA = lvl1Verts[239]; lvl1Wall[180].posB = lvl1Verts[406]; lvl1Wall[180].posC = lvl1Verts[407];
    lvl1Wall[181].posA = lvl1Verts[406]; lvl1Wall[181].posB = lvl1Verts[310]; lvl1Wall[181].posC = lvl1Verts[309];
    lvl1Wall[182].posA = lvl1Verts[406]; lvl1Wall[182].posB = lvl1Verts[309]; lvl1Wall[182].posC = lvl1Verts[407];

    for (int i = 0; i < lvl1SlopeCount; i++) {
        lvl1Slope[i].type = SURFACE_SLOPE;
        lvl1Slope[i].center = center;
        lvl1Slope[i].normal = norm;
        lvl1Slope[i].center = calc_surface_center(lvl1Slope[i]);
        lvl1Slope[i].normal = calc_surface_norm(lvl1Slope[i]);
    }

    for (int i = 0; i < lvl1FloorCount; i++) {
        lvl1Floor[i].type = SURFACE_FLOOR;
        lvl1Floor[i].center = center;
        lvl1Floor[i].normal = norm;
        lvl1Floor[i].center = calc_surface_center(lvl1Floor[i]);
        lvl1Floor[i].normal = calc_surface_norm(lvl1Floor[i]);
    }

    for (int i = 0; i < lvl1WallCount; i++) {
        lvl1Wall[i].type = SURFACE_WALL;
        lvl1Wall[i].center = center;
        lvl1Wall[i].normal = norm;
        lvl1Wall[i].center = calc_surface_center(lvl1Wall[i]);
        lvl1Wall[i].normal = calc_surface_norm(lvl1Wall[i]);
    }

    // Combine the surfaces for collision detection
    combine_surfaces(
       lvl1Surfaces, &lvl1SurfacesCount,
       lvl1Slope, lvl1SlopeCount,
       lvl1Floor, lvl1FloorCount,
       lvl1Wall, lvl1WallCount
    );

    // Allocate map's matrix and construct
    lvl1MatFP = malloc_uncached(sizeof(T3DMat4FP));
    t3d_mat4fp_from_srt_euler(lvl1MatFP, (float[3]){1.0f, 1.0f, 1.0f}, (float[3]){0, 0, 0}, (float[3]){0, 0, 0});

    // Load model
    modelLvl1 = t3d_model_load("rom:/models/lvl1.t3dm");

    // Create map's RSPQ block
    rspq_block_begin();
        t3d_matrix_push(lvl1MatFP);
        matCount++;
        rdpq_set_prim_color(WHITE);
        t3d_model_draw(modelLvl1);
        t3d_matrix_pop(1);
    dplLvl1 = rspq_block_end();
}
