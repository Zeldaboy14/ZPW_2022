#include <uLib.h>
#include "code/z_player_lib.h"
#include "z64player.h"
#include "../system/kaleido/0x01-Player/playas_adult.h"
#include "../system/kaleido/0x01-Player/playas_child.h"

// z64ram = 0x8009214C
// z64rom = 0xB092EC
// z64next = 0x80092320

Vec3s gLinkPauseChildBgsJointTable[] = {
    {    -37,   2346,     93 },
    {      0,   7927,      0 },
    { -18104,    728, -17116 },
    {      0,      0,      0 },
    {   5584,   2893,   -779 },
    {      0,      0,   2813 },
    {   2710,   1166, -16888 },
    {  -2057,  -3191,  -2192 },
    {      0,      0,   4577 },
    {  -2215,  -1317, -18974 },
    {  22897,   -947,  17702 },
    {   1386,   9779,  19889 },
    {      0,      0,  19902 },
    {      0,      0,      0 },
    {  11423,  -1937,  26391 },
    {      0,      0, -15854 },
    { -16991, -26137,  13708 },
    {  -6976,  -2831,  26031 },
    {      0,      0,  -4798 },
    {   4441,    221, -18986 },
    { -19499,  27753,   -227 },
    {      0,      0,      0 },
    {      0,      0,      0 },
    {      0,      0,      0 }
};

Vec3s gLinkPauseChild2JointTable[] = {
    {    -37,   2346,     93 },
    {      0,      0,      0 },
    { -18104,    728, -17116 },
    {      0,      0,      0 },
    {   3114,   1725,  -1243 },
    {      0,      0,   2607 },
    {   2184,   1320, -17823 },
    {  -2001,  -2988,  -3620 },
    {      0,      0,   5024 },
    {  -1665,  -1220, -18352 },
    {  23087,   -313,  16384 },
    {   -474,   5888,  18054 },
    {      0,      0,  19902 },
    {      0,      0,      0 },
    {  -2318,  -1154,  30091 },
    {      0,      0,  -5945 },
    {    124,   -489, -19513 },
    {   5893,   3955, -26617 },
    {      0,      0,  -5319 },
    {   5865,   3517, -16725 },
    { -15534,  27097,   2355 },
    {   -104,      0,      0 },
    {      0,      0,      0 },
    {      0,      0,      0 }
};

Vec3s gLinkPauseChildShieldJointTable[] = {
    {    -37,   2346,     93 },
    {      0,      0,      0 },
    { -18104,    728, -17116 },
    {      0,      0,      0 },
    {   3114,   1725,  -1243 },
    {      0,      0,   2607 },
    {   2184,   1320, -17823 },
    {  -2001,  -2988,  -3620 },
    {      0,      0,   5024 },
    {  -1665,  -1220, -18352 },
    {  23087,   -313,  16384 },
    {   -474,   5888,  18054 },
    {      0,      0,  19902 },
    {      0,      0,      0 },
    {  -2318,  -1154,  30091 },
    {      0,      0,  -5945 },
    {    124,   -489, -19513 },
    {   5893,   3955, -26617 },
    {      0,      0, -19192 },
    {   5865,   3517, -16725 },
    { -15534,  27097,   2355 },
    {   -104,      0,      0 },
    {      0,      0,      0 },
    {      0,      0,      0 }
};

Asm_VanillaHook(Player_DrawPause);
void Player_DrawPause(PlayState* play, u8* segment, SkelAnime* skelAnime, Vec3f* pos, Vec3s* rot, f32 scale, s32 sword,
                      s32 tunic, s32 shield, s32 boots) {
    static Vec3f eye = { 0.0f, 0.0f, -430.0f };
    static Vec3f at = { 0.0f, 0.0f, 0.0f };
    Vec3s* destTable;
    Vec3s* srcTable;
    s32 i;

    gSegments[4] = VIRTUAL_TO_PHYSICAL(segment + PAUSE_EQUIP_BUFFER_SIZE);
    gSegments[6] = VIRTUAL_TO_PHYSICAL(segment + PAUSE_EQUIP_BUFFER_SIZE + PAUSE_PLAYER_SEGMENT_GAMEPLAY_KEEP_BUFFER_SIZE);

    // Changed to facilitate no turtle shield for child on pause menu
    if (!LINK_IS_ADULT) {
        if (sword == PLAYER_SWORD_BGS) {
            srcTable = gLinkPauseChildBgsJointTable;
        } else if (shield != PLAYER_SHIELD_NONE) {
            srcTable = gLinkPauseChildShieldJointTable;
        } else {
            srcTable = gLinkPauseChild2JointTable;
        }
    } else {
        if (sword == PLAYER_SWORD_BGS) {
            srcTable = gLinkPauseAdultBgsJointTable;
        } else if (shield != PLAYER_SHIELD_NONE) {
            srcTable = gLinkPauseAdultShieldJointTable;
        } else {
            srcTable = gLinkPauseAdultJointTable;
        }
    }
	

    srcTable = SEGMENTED_TO_VIRTUAL(srcTable);
    destTable = skelAnime->jointTable;
    for (i = 0; i < skelAnime->limbCount; i++) {
        *destTable++ = *srcTable++;
    }

    Player_DrawPauseImpl(play, segment + PAUSE_EQUIP_BUFFER_SIZE,
                         segment + PAUSE_EQUIP_BUFFER_SIZE + PAUSE_PLAYER_SEGMENT_GAMEPLAY_KEEP_BUFFER_SIZE, skelAnime,
                         pos, rot, scale, sword, tunic, shield, boots, PAUSE_EQUIP_PLAYER_WIDTH,
                         PAUSE_EQUIP_PLAYER_HEIGHT, &eye, &at, 60.0f, play->state.gfxCtx->curFrameBuffer,
                         play->state.gfxCtx->curFrameBuffer + (PAUSE_EQUIP_PLAYER_WIDTH * PAUSE_EQUIP_PLAYER_HEIGHT));
}